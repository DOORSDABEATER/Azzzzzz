#!/usr/bin/env python3
"""
VAELZARION voice production kit.   Needs: python3, numpy, scipy (selftest only), ffmpeg with libvorbis + rubberband.

  python3 tools/voice_kit.py script                      # writes voice_kit/voice_script.csv  (what to record + delivery notes for a voice actor)
  python3 tools/voice_kit.py process --raw voice_raw     # raw dry takes  ->  processed mono OGG (primary + Eidolon layers) inside the resource pack
  python3 tools/voice_kit.py selftest                    # proves the DSP chain works on a synthetic signal (it does NOT make speech)

HONEST SCOPE: this kit does not create a performance. It needs real dry recordings (a voice actor, or a TTS/voice service whose licence you have checked).
It then makes that performance DEEPER and LARGER (formant-shifting pitch drop), gives each Eidolon its own texture, builds layer files, normalises loudness,
and encodes the exact file names/paths the plugin expects. Quality of the final voice is bounded by the quality of the raw takes.
"""
import argparse, csv, json, os, re, subprocess, sys, shutil, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
VOICE_TXT = os.path.join(ROOT, "src", "main", "resources", "azrathiel", "voice", "vaelzarion_voice.txt")
DEFAULT_OUT = os.path.join(ROOT, "resourcepack", "assets", "azrathiel", "sounds", "voice")
EIDOLONS = ["vigor", "abyss", "fate", "ruin", "aegis", "evolution", "wraith", "dominion"]
EXTS = (".wav", ".flac", ".mp3", ".ogg", ".m4a", ".aiff", ".aif")

# ------------------------------------------------------------------------------------------------ line parsing (mirrors core/VoiceLibrary.java numbering)
def parse_lines(path=VOICE_TXT):
    counters = {}; out = []; cur = None
    for raw in open(path, encoding="utf-8").read().splitlines():
        s = raw.strip()
        if not s or s.startswith("#"): continue
        if s.startswith("@"): cur = s[1:].strip().lower(); continue
        tags = []
        while s.startswith("["):
            j = s.index("]"); tags.append(s[1:j].strip()); s = s[j + 1:].lstrip()
        counters[cur] = counters.get(cur, 0) + 1; n = counters[cur]
        eid = next((t.lower() for t in tags if t.lower() in EIDOLONS), None)
        sub = next((t[1:].lower() for t in tags if t.startswith("#")), None)
        forms = [t for t in tags if t in ("D", "R", "A")]
        out.append({"cat": cur, "n": n, "id": "%s.%03d" % (cur, n), "sound": "%s_%03d" % (cur, n), "text": s, "tags": tags, "eidolon": eid, "sub": sub, "forms": forms})
    return out

# ------------------------------------------------------------------------------------------------ DSP profiles (ffmpeg)
PRE = ("silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.05,areverse,silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.25,areverse,"
       "highpass=f=60,afftdn=nf=-35")
def rb(p): return "rubberband=pitch=%.3f:formant=shifted:transients=smooth:detector=soft" % p
COMP = "acompressor=threshold=-22dB:ratio=3.5:attack=8:release=140:makeup=3"
# name -> dict(pitch, post, sub)   pitch<1 = lower. sub = optional octave-down blend (dB) for the 'terrifying' registers.
PROFILES = {
 "calm":     dict(pitch=0.82, post="bass=g=6:f=150,equalizer=f=300:width_type=q:w=1:g=-2,treble=g=-2:f=5000,aecho=0.8:0.85:70|130:0.22|0.12"),
 "stern":    dict(pitch=0.77, post="bass=g=6:f=140,equalizer=f=2200:width_type=q:w=1:g=2.5,treble=g=-4:f=4500,asoftclip=type=tanh,aecho=0.8:0.8:50|100:0.2|0.1"),
 "wrath":    dict(pitch=0.72, sub=(0.5, -9), post="bass=g=7:f=130,equalizer=f=2000:width_type=q:w=1:g=3,treble=g=-5:f=4200,asoftclip=type=tanh,aecho=0.8:0.85:60|120|200:0.25|0.15|0.08"),
 "released": dict(pitch=0.76, post="bass=g=6:f=140,equalizer=f=250:width_type=q:w=1:g=-2,aecho=0.8:0.88:90|180|300:0.3|0.2|0.1"),
 "ultimate": dict(pitch=0.68, sub=(0.5, -6), post="bass=g=8:f=120,chorus=0.7:0.9:40|57:0.35|0.3:0.25|0.4:2|1.3,aecho=0.8:0.9:120|260|420|600:0.35|0.25|0.15|0.1"),
 # --- the eight Eidolon voices ---
 "vigor":    dict(pitch=0.86, post="asoftclip=type=tanh,bass=g=4:f=180,equalizer=f=900:width_type=q:w=1:g=3"),
 "abyss":    dict(pitch=0.78, post="equalizer=f=1200:width_type=q:w=0.8:g=-6,chorus=0.6:0.9:55:0.4:0.25:2,aecho=0.8:0.9:180|360|540:0.35|0.25|0.15"),
 "fate":     dict(pitch=0.95, post="highpass=f=140,compand=attacks=0:points=-80/-80|-30/-12|0/-6,treble=g=-1:f=6000"),
 "ruin":     dict(pitch=0.80, post="acrusher=bits=9:mode=log:mix=0.3:aa=1,asoftclip=type=hard,equalizer=f=2000:width_type=q:w=1:g=3"),
 "aegis":    dict(pitch=0.88, post="bass=g=5:f=200,acompressor=threshold=-24dB:ratio=4,aecho=0.8:0.8:50:0.2"),
 "evolution": dict(pitch=1.00, post="tremolo=f=5:d=0.18,equalizer=f=2500:width_type=q:w=1:g=3,highpass=f=100"),
 "wraith":   dict(pitch=1.10, post="highpass=f=350,aphaser=in_gain=0.6:out_gain=0.8:delay=3:decay=0.4:speed=0.5,aecho=0.8:0.9:120|240:0.4|0.3,volume=-3dB"),
 "dominion": dict(pitch=0.82, post="chorus=0.7:0.9:45|60:0.4|0.32:0.25|0.4:2|1.3,bass=g=3:f=160,aecho=0.8:0.88:90|200:0.3|0.2"),
}

def profile_for(line):
    """Primary-voice register for a line (spec: calm by default; colder/lower when angry; terrifying when the master is threatened; Eidolon lines in that Eidolon's voice)."""
    if line["eidolon"]: return line["eidolon"]
    c = line["cat"]; crit = any(t.upper() in ("LOW", "CRIT") for t in line["tags"])
    if c == "apocalypse": return "ultimate"
    if c == "last_guardian": return "wrath"
    if c == "protect": return "wrath" if crit or True else "stern"
    if c == "injury": return "wrath" if any(t.upper() == "CRIT" for t in line["tags"]) else "stern"
    if c == "death_respawn": return "stern" if line["sub"] == "death" else "calm"
    if c == "released": return "released"
    if c in ("combat_start", "combat_react", "ability", "boss", "detect"): return "stern"
    return "calm"

def filter_for(name, lufs):
    p = PROFILES[name]; post = p["post"]; tail = "loudnorm=I=%d:TP=-2:LRA=7,alimiter=limit=0.89" % lufs
    base = "%s,%s" % (PRE, rb(p["pitch"]))
    if "sub" in p:
        pitch, db = p["sub"]
        return ("-filter_complex", "[0:a]%s,asplit=2[a][b];[b]%s,volume=%ddB[c];[a][c]amix=inputs=2:normalize=0,%s,%s,%s" % (base, rb(pitch * p["pitch"]), db, post, COMP, tail))
    return ("-af", "%s,%s,%s,%s" % (base, post, COMP, tail))

def encode(src, dst, profile, lufs, sr, q, dry=False):
    flag, fl = filter_for(profile, lufs); os.makedirs(os.path.dirname(dst), exist_ok=True)
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, flag, fl, "-ac", "1", "-ar", str(sr), "-c:a", "libvorbis", "-q:a", str(q), dst]
    if dry: print(" ".join(cmd)); return True, ""
    r = subprocess.run(cmd, capture_output=True, text=True); return r.returncode == 0 and os.path.exists(dst), r.stderr[-400:]

def find_raw(raw_dir, sound):
    for e in EXTS:
        p = os.path.join(raw_dir, sound + e)
        if os.path.exists(p): return p
    return None

KEY_LAYER_CATS = {"apocalypse", "released", "last_guardian", "boss", "ability", "combat_start", "protect"}
def wants_layers(line, mode):
    if mode == "none" or line["forms"] == ["D"]: return False
    return mode == "all" or line["cat"] in KEY_LAYER_CATS

def cmd_process(a):
    lines = parse_lines(); todo = [l for l in lines if (not a.only or l["id"] in a.only.split(",") or l["sound"] in a.only.split(","))]
    if a.tier: todo = [l for l in todo if tier(l) <= a.tier]
    done = missing = failed = layers = 0; report = {"processed": [], "missing_raw": [], "failed": []}
    for l in todo:
        src = find_raw(a.raw, l["sound"])
        if not src: missing += 1; report["missing_raw"].append(l["sound"]); continue
        ok, err = encode(src, os.path.join(a.out, l["sound"] + ".ogg"), profile_for(l), -18, 44100, 4, a.dry_run)
        if not ok: failed += 1; report["failed"].append({"sound": l["sound"], "error": err}); print("FAILED", l["sound"], err); continue
        done += 1; report["processed"].append(l["sound"])
        if wants_layers(l, a.layers):
            for e in EIDOLONS:
                real = find_raw(os.path.join(a.raw, "layers", e), l["sound"])       # a real in-character take overrides the synthesised layer
                ok, err = encode(real or src, os.path.join(a.out, "layers", e, l["sound"] + ".ogg"), e, -26, 22050, 1, a.dry_run)
                layers += ok
                if not ok: failed += 1; report["failed"].append({"sound": l["sound"] + "/" + e, "error": err})
    print("processed %d lines, %d layer files, %d missing raw takes, %d failures" % (done, layers, missing, failed))
    if not a.dry_run:
        json.dump(report, open(os.path.join(ROOT, "voice_kit", "voice_build_report.json"), "w"), indent=2)
        if a.register: subprocess.run([sys.executable, os.path.join(ROOT, "tools", "gen_resourcepack.py"), "--scan-voice"])
        else: print("next: python3 tools/gen_resourcepack.py --scan-voice   then set voice.recordings-installed: true")
    return 0 if failed == 0 else 1

# ------------------------------------------------------------------------------------------------ recording script
DIRECTION = {
 "summon_dismiss": "Warm gravity, unhurried. A sovereign acknowledging its master. Summon: rising certainty. Dismiss: quiet, settling.",
 "idle": "Murmured to itself; contemplative, slow (about 70% pace). Long pause after the first clause. Never theatrical.",
 "follow": "Calm and close, almost conversational but still deep. Light, steady.",
 "command": "Short, crisp acknowledgement. Obedient but never servile. Low and certain.",
 "detect": "Cold alertness. Quiet first, a half-breath of tension. Not shouted.",
 "combat_start": "Controlled menace. Lower and slower than normal, then one hard consonant on the key word.",
 "combat_react": "Dry, contemptuous, minimal. Short bursts. Cold, not loud.",
 "ability": "The authority speaks the technique name clearly. Use the Eidolon texture below. Deliberate, weighty.",
 "boss": "Respectful of a worthy enemy; calm confidence over real power. Slow and grave.",
 "protect": "TERRIFYINGLY PROTECTIVE. Lower and colder, not louder. Each word placed like a blow. Intelligible above all.",
 "injury": "Controlled alarm. LOW lines: tight, quiet urgency. CRIT lines: strained control about to break, still clear.",
 "released": "Awe-inspiring unfolding. Slow build, broad and resonant. Full chest.",
 "apocalypse": "OVERWHELMING but intelligible. Slow, each phrase separated by a beat. CAPS = stress with weight, never screaming. Also record 8 in-character layer takes if possible.",
 "last_guardian": "Grief hardening into resolve. Raw, low, restrained. 'hold' lines steady; 'exhaust' lines fading, breath showing; 'shock' lines all-out but clear.",
 "death_respawn": "death: disbelief, hushed. respawn: relief held under control, warm.",
 "eidolon": "The Eidolon speaks in its own voice (texture below). Reflective, self-contained.",
 "secret": "Intimate, rare, knowing. Softer than normal speech; a private remark.",
}
TEXTURE = {"vigor": "aggressive, powerful, confident", "abyss": "hollow, echoing, unnaturally calm", "fate": "prophetic, flat, precise, almost emotionless", "ruin": "harsh, merciless, threatening",
           "aegis": "deep, protective, commanding, reassuring", "evolution": "analytical, controlled, observant", "wraith": "spectral, distant, ghostly, hushed", "dominion": "royal, authoritative, intimidating"}
def tier(l):
    return 1 if l["cat"] in ("summon_dismiss", "command", "apocalypse", "released", "last_guardian", "protect", "death_respawn", "ability") else 2 if l["cat"] in ("combat_start", "combat_react", "detect", "boss", "injury", "eidolon") else 3

def cmd_script(a):
    os.makedirs(os.path.join(ROOT, "voice_kit"), exist_ok=True); p = os.path.join(ROOT, "voice_kit", "voice_script.csv"); rows = 0; counts = {1: 0, 2: 0, 3: 0}
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["tier", "file_name", "id", "category", "speaker", "form_when_spoken", "text", "delivery_direction", "needs_layer_takes", "deliver_as"])
        for l in sorted(parse_lines(), key=lambda x: (tier(x), x["cat"], x["n"])):
            spk = l["eidolon"].upper() if l["eidolon"] else "VAELZARION"; d = DIRECTION.get(l["cat"], "")
            if l["eidolon"]: d += " Texture: " + TEXTURE[l["eidolon"]] + "."
            if any(t.upper() == "CRIT" for t in l["tags"]): d += " (Master near death.)"
            elif any(t.upper() == "LOW" for t in l["tags"]): d += " (Master badly hurt.)"
            if l["sub"]: d += " Subtype: " + l["sub"] + "."
            form = {"D": "Dormant", "R": "Released", "A": "Apocalypse"}
            forms = "/".join(form[x] for x in l["forms"]) or "any"
            w.writerow([tier(l), l["sound"] + ".wav", l["id"], l["cat"], spk, forms, l["text"], d.strip(), "yes - 8 optional" if l["cat"] == "apocalypse" else "optional", "dry mono WAV 48kHz 24-bit"])
            rows += 1; counts[tier(l)] += 1
    print("wrote %s: %d lines (tier1 %d / tier2 %d / tier3 %d)" % (p, rows, counts[1], counts[2], counts[3]))

# ------------------------------------------------------------------------------------------------ selftest (DSP verification only)
def decode(path, sr=22050):
    import numpy as np
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", str(sr), "-"], capture_output=True)
    return np.frombuffer(r.stdout, dtype="float32"), sr

def lufs(path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af", "ebur128=framelog=quiet", "-f", "null", "-"], capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?\d+\.\d+) LUFS", r.stderr); return float(m[-1]) if m else None

def f0(x, sr):
    import numpy as np
    n = int(0.06 * sr); best = []
    for start in range(int(0.4 * sr), max(int(0.45 * sr), len(x) - n - int(0.3 * sr)), int(0.12 * sr)):
        w = x[start:start + n].astype("float64"); w = w - w.mean()
        if np.sqrt((w ** 2).mean()) < 0.01: continue
        ac = np.correlate(w, w, "full")[n - 1:]; lo, hi = int(sr / 400), int(sr / 50); k = lo + int(np.argmax(ac[lo:hi]))
        best.append(sr / k)
    return float(np.median(best)) if best else None

def centroid(x, sr):
    import numpy as np
    sp = np.abs(np.fft.rfft(x * np.hanning(len(x)))); fr = np.fft.rfftfreq(len(x), 1 / sr); return float((sp * fr).sum() / (sp.sum() + 1e-9))

def band_shape(x, sr):
    """Relative 1/3-octave spectral shape in dB (80 Hz - 8 kHz), mean removed so only the SHAPE (timbre) is compared, not the level."""
    import numpy as np
    sp = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2; fr = np.fft.rfftfreq(len(x), 1 / sr); edges = 80 * 2 ** (np.arange(0, 21) / 3.0); edges = edges[edges < min(8000, sr / 2)]
    bands = np.array([10 * np.log10(sp[(fr >= lo) & (fr < hi)].sum() + 1e-12) for lo, hi in zip(edges[:-1], edges[1:])]); return bands - bands.mean()

def lowband(x, sr):
    import numpy as np
    sp = np.abs(np.fft.rfft(x)) ** 2; fr = np.fft.rfftfreq(len(x), 1 / sr); return float(sp[fr < 120].sum() / (sp.sum() + 1e-9))

def synth(path, dur=2.8, f0v=130.0, sr=48000):
    import numpy as np
    from scipy.signal import lfilter
    from scipy.io import wavfile
    t = np.arange(int(dur * sr)) / sr; f = f0v * (1 + 0.05 * np.sin(2 * np.pi * 0.7 * t)); ph = 2 * np.pi * np.cumsum(f) / sr
    src = sum(np.sin(k * ph) / k for k in range(1, 40)); env = (0.5 + 0.5 * np.sin(2 * np.pi * 3.2 * t - 1.2)) ** 1.4 * np.clip(np.minimum(t, dur - t) * 8, 0, 1)
    out = np.zeros_like(src)
    for fc, bw, g in ((700, 110, 1.0), (1220, 120, 0.7), (2600, 160, 0.4)):          # three formant resonators = vowel-like (NOT speech)
        r = np.exp(-np.pi * bw / sr); th = 2 * np.pi * fc / sr; out += g * lfilter([1 - r], [1, -2 * r * np.cos(th), r * r], src)
    out = out * env + 0.002 * np.random.RandomState(1).randn(len(out)); out = out / np.abs(out).max() * 0.35
    wavfile.write(path, sr, (out * 32767).astype("int16"))

def cmd_selftest(a):
    import numpy as np
    for tool in ("ffmpeg",):
        if not shutil.which(tool): print("FAIL: ffmpeg not found"); return 1
    tmp = os.path.join(ROOT, "build", "voice_selftest"); shutil.rmtree(tmp, ignore_errors=True); raw = os.path.join(tmp, "raw"); out = os.path.join(tmp, "out"); os.makedirs(raw)
    lines = {l["sound"]: l for l in parse_lines()}; picks = ["summon_dismiss_001", "apocalypse_001", "ability_001", "protect_001"]
    for s in picks: assert s in lines, s; synth(os.path.join(raw, s + ".wav"))
    ns = argparse.Namespace(raw=raw, out=out, layers="all", tier=0, only=",".join(picks), dry_run=False, register=False)
    shutil.copy  # noqa
    rc = cmd_process(ns); ok_all = rc == 0; res = []
    def check(c, msg): nonlocal ok_all; ok_all &= bool(c); print("  %s  %s" % ("PASS" if c else "FAIL", msg))
    check(rc == 0, "pipeline ran every profile without an ffmpeg error")
    rawx, sr0 = decode(os.path.join(raw, "summon_dismiss_001.wav"), 48000); f_raw = f0(rawx, sr0)
    for s in picks:
        p = os.path.join(out, s + ".ogg"); check(os.path.exists(p), "%s.ogg written" % s)
        pr = json_probe(p); check(pr.get("codec_name") == "vorbis" and pr.get("channels") == 1 and pr.get("sample_rate") == "44100", "%s is mono 44.1 kHz Vorbis" % s)
        L = lufs(p); check(L is not None and abs(L + 18) < 2.5, "%s loudness %.1f LUFS (target -18)" % (s, L if L is not None else 0))
    calm, _ = decode(os.path.join(out, "summon_dismiss_001.ogg"), 48000); f_out = f0(calm, 48000)
    check(f_raw and f_out and f_out < f_raw * 0.9, "calm register is deeper than the raw take (f0 %.0f Hz -> %.0f Hz)" % (f_raw or 0, f_out or 0))
    dr = len(calm) / 48000.0; check(abs(dr - len(rawx) / 48000.0) < 0.6, "duration preserved by the pitch shift (%.2fs vs %.2fs raw)" % (dr, len(rawx) / 48000.0))
    ult, _ = decode(os.path.join(out, "apocalypse_001.ogg"), 48000); check(lowband(ult, 48000) > lowband(calm, 48000), "ultimate register carries more sub-octave energy than calm (%.3f vs %.3f)" % (lowband(ult, 48000), lowband(calm, 48000)))
    spec = {}
    for e in EIDOLONS:
        lp = os.path.join(out, "layers", e, "apocalypse_001.ogg"); check(os.path.exists(lp), "layer %s written" % e)
        if os.path.exists(lp): x, sr = decode(lp, 22050); spec[e] = band_shape(x, sr)
    dists = sorted((float(np.sqrt(((spec[a_] - spec[b_]) ** 2).mean())), a_, b_) for i, a_ in enumerate(EIDOLONS) for b_ in EIDOLONS[i + 1:] if a_ in spec and b_ in spec)
    check(len(spec) == 8 and dists and dists[0][0] > 2.0, "every pair of the eight Eidolon layers differs in spectral shape (closest pair %s/%s = %.1f dB RMS, need > 2.0)" % (dists[0][1], dists[0][2], dists[0][0]) if dists else "layers missing")
    print("\nvoice kit selftest:", "ALL PASS" if ok_all else "FAILURES"); print("NOTE: this validates the processing chain on a synthetic vowel-like signal. It says nothing about how real speech will sound.")
    return 0 if ok_all else 1

def json_probe(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name,channels,sample_rate", "-of", "json", p], capture_output=True, text=True)
    try: return json.loads(r.stdout)["streams"][0]
    except Exception: return {}

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("script"); sub.add_parser("selftest")
    p = sub.add_parser("process"); p.add_argument("--raw", default=os.path.join(ROOT, "voice_raw")); p.add_argument("--out", default=DEFAULT_OUT)
    p.add_argument("--layers", choices=["none", "key", "all"], default="key"); p.add_argument("--tier", type=int, default=0); p.add_argument("--only", default="")
    p.add_argument("--dry-run", action="store_true"); p.add_argument("--register", action="store_true", help="also run gen_resourcepack.py --scan-voice")
    a = ap.parse_args(); sys.exit({"script": lambda: (cmd_script(a) or 0), "process": lambda: cmd_process(a), "selftest": lambda: cmd_selftest(a)}[a.cmd]())

if __name__ == "__main__": main()
