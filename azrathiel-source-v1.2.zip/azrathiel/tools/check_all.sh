#!/usr/bin/env bash
# Runs every offline check. Needs only a JDK 21+ and python3.   Usage: tools/check_all.sh
set -u
cd "$(dirname "$0")/.."
fail=0
run() { echo "== $1"; shift; "$@" || fail=1; echo; }
run "core unit tests (pure logic)" bash tools/run_core_tests.sh
run "syntax parse of every source file" java tools/ParseCheck.java src/main/java
run "resource pack integrity" python3 tools/verify_pack.py
run "unresolved type names" python3 tools/check_imports.py
run "cross-class member check" python3 tools/member_check.py
run "stub-based consistency compile" python3 tools/stub_check.py
if command -v ffmpeg >/dev/null 2>&1 && python3 -c "import numpy, scipy" 2>/dev/null; then run "voice kit DSP selftest" python3 tools/voice_kit.py selftest; else echo "== voice kit selftest skipped (needs ffmpeg + numpy + scipy)"; fi
[ $fail -eq 0 ] && echo "ALL OFFLINE CHECKS PASSED (this is NOT a substitute for compiling against Paper and running the in-game self-test)" || echo "SOME CHECKS FAILED"
exit $fail
