#!/usr/bin/env python3
"""Software preview of the assembled rig (no Minecraft needed): reads the REAL generated model JSON + texture colours and the same bone layout/pose
maths as RigModel.java, then draws front / 3-quarter / side views with flat shading. Needs Pillow + numpy. Output: build/preview_<form>.png"""
import json, math, os, sys
import numpy as np
from PIL import Image, ImageDraw
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
AS = os.path.join(ROOT, "resourcepack", "assets", "azrathiel")
EID = ["vigor", "abyss", "fate", "ruin", "aegis", "evolution", "wraith", "dominion"]
RGB = {"vigor": 0xFF6A1F, "abyss": 0x6A1BFF, "fate": 0x7FDBFF, "ruin": 0xB31217, "aegis": 0x2E6FFF, "evolution": 0x39E06B, "wraith": 0xC9F4F0, "dominion": 0xFFC83D}
THEME = (255, 200, 61)
D = math.pi / 180

def rx(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]], float)
def ry(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]], float)
def rz(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], float)
def tr(x, y, z): m = np.eye(4); m[:3, 3] = (x, y, z); return m
def sc(s): m = np.eye(4); m[0, 0] = m[1, 1] = m[2, 2] = s; return m

def avg_color(tex):
    p = os.path.join(AS, "textures", tex.split(":")[1] + ".png")
    im = Image.open(p).convert("RGBA"); a = np.array(im).reshape(-1, 4).astype(float); a = a[a[:, 3] > 0]
    return tuple(int(v) for v in a[:, :3].mean(axis=0))

_cache = {}
def model(key):
    if key not in _cache:
        m = json.load(open(os.path.join(AS, "models", key + ".json"))); cols = {k: avg_color(v) for k, v in m["textures"].items() if k != "particle"}
        items = json.load(open(os.path.join(AS, "items", key + ".json"))); _cache[key] = (m, cols, "tints" in items["model"])
    return _cache[key]

def faces_of(key, M, glow_tint=None, force_glow=False):
    """yield (quad world coords 4x3, normal, color, glow) for one bone placed with 4x4 matrix M (blocks)."""
    m, cols, tinted = model(key); out = []
    for e in m["elements"]:
        f, t = np.array(e["from"], float), np.array(e["to"], float)
        P = {(i, j, k): np.array([[f, t][i][0], [f, t][j][1], [f, t][k][2]]) for i in (0, 1) for j in (0, 1) for k in (0, 1)}
        R = np.eye(4)
        if "rotation" in e:
            o = np.array(e["rotation"]["origin"], float); a = e["rotation"]["angle"] * D; ax = e["rotation"]["axis"]
            R = tr(*o) @ {"x": rx, "y": ry, "z": rz}[ax](a) @ tr(*-o)
        def W(p): v = (R @ np.append(p, 1))[:3]; v = (v - 8) / 16.0; return (M @ np.append(v, 1))[:3]
        quads = {"north": [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)], "south": [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)], "west": [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)],
                 "east": [(1, 0, 0), (1, 0, 1), (1, 1, 1), (1, 1, 0)], "down": [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)], "up": [(0, 1, 0), (1, 1, 0), (1, 1, 1), (0, 1, 1)]}
        for name, idx in quads.items():
            if name not in e["faces"]: continue
            q = np.array([W(P[i]) for i in idx]); n = np.cross(q[1] - q[0], q[3] - q[0]); nl = np.linalg.norm(n)
            if nl < 1e-9: continue
            col = cols.get(e["faces"][name]["texture"][1:], (120, 120, 120))
            glow = force_glow or tinted and e["faces"][name].get("tintindex") is not None
            if glow: col = glow_tint or THEME
            out.append((q, n / nl, col, glow))
    return out

def rig(form):
    s = {"dormant": 1.0, "released": 1.75, "apoc": 2.6}[form]; root = sc(s); bones = []
    if form == "dormant":
        bones.append(("dormant/body", root, None))
        for i in range(3):
            a = 0.6 * (30 + 25 * i) * (1 if i % 2 == 0 else -1) * D; bones.append(("dormant/ring", root @ ry(a) @ rx((35 + 50 * i) * D) @ rz(a * 0.4) @ sc(1.35 + 0.3 * i), None))
        bones.append(("dormant/body_glow", root, None)); bones.append(("core", root @ tr(0, 0.02, 0.16) @ sc(0.30), None))
        for i in range(6):
            p = (0.6 * 40 + i * 45) * D; r = 1.5; bones.append(("frag_" + "abc"[i % 3], root @ tr(r * math.cos(p), ((i % 3) - 1) * 0.28, r * math.sin(p)) @ ry(i) @ rx(0.5 * i) @ sc(0.28), None))
        return bones
    p = "apoc/" if form == "apoc" else "released/"
    torso = root; bones += [(p + "torso", torso, None), (p + "torso_glow", torso, None)]
    head = torso @ tr(0, 0.92, 0.03); bones += [(p + "head", head, None), (p + "head_glow", head, None)]
    bones.append(("core_apoc" if form == "apoc" else "core", torso @ tr(0, 0.12, 0.33) @ sc(0.62 if form == "apoc" else 0.44), None))
    sh = [(-0.58, 0.50, 0), (0.58, 0.50, 0), (-0.50, -0.22, 0.12), (0.50, -0.22, 0.12)]
    RA = [(14, 16, 26), (14, 16, 26), (26, 34, 38), (26, 34, 38)] if form == "released" else [(35, 60, 30)] * 4
    for a in range(4):
        raise_, spread, bend = RA[a]; sign = -1 if a % 2 == 0 else 1; up = torso @ tr(*sh[a]) @ rz(sign * spread * D) @ rx(-raise_ * D)
        bones.append((p.replace("apoc/", "released/") + "arm_upper", up, None)); lo = up @ tr(0, -0.58, 0) @ rx(-bend * D); bones.append(("released/arm_lower", lo, None))
    hs = 0.85 * (1.4 if form == "apoc" else 1.0)
    for i in range(8):
        th = (30 + i * 45) * D; m = root @ tr(0, 1.0, -0.42) @ rz(th) @ tr(hs, 0, 0) @ sc(1.3 if form == "apoc" else 1.0)
        bones.append((("apoc/halo_" + EID[i]) if form == "apoc" else "released/halo_seg", m, RGB[EID[i]]))
    for i in range(8):
        ph = (50 + i * 45 * 1.0) * D; r = 1.6 * (1 + 0.08 * ((i * 7) % 5)); bones.append(("frag_" + "abc"[i % 3], root @ tr(r * math.cos(ph), ((i % 3) - 1) * 0.28 + 0.1, r * math.sin(ph)) @ ry(i) @ rx(i * 0.5) @ sc(0.36), None))
    for i in range(8):
        psi = (i * 45 + 22.5) * D; bones.append(("mark/" + EID[i], torso @ tr(0.34 * math.cos(psi), 0.12 + 0.34 * math.sin(psi), 0.37) @ sc(0.16), None))
    return bones

def render(form, yaw_deg, size=520, supers=2):
    bones = rig(form); quads = []
    for key, M, tint in bones:
        iv = RGB.get(key.split("_")[-1]) if key.startswith("mark/") or key.startswith("apoc/halo_") else None
        quads += faces_of(key, M, glow_tint=(tuple((tint >> s) & 255 for s in (16, 8, 0)) if tint else None) if not key.startswith("mark/") else tuple((RGB[key.split("/")[1]] >> s) & 255 for s in (16, 8, 0)),
                          force_glow=key.startswith("mark/") or key.endswith("_glow") or key.startswith("core"))
    a = yaw_deg * D; Rm = ry(a)[:3, :3]; light = np.array([0.35, 0.8, 0.6]); light /= np.linalg.norm(light)
    pts = np.concatenate([q[0] for q in quads]); c = pts.mean(axis=0); ext = max(np.ptp(pts[:, 0]), np.ptp(pts[:, 1])) * 1.08
    S = size * supers; img = Image.new("RGB", (S, S), (24, 24, 30)); dr = ImageDraw.Draw(img)
    items = []
    for q, n, col, glow in quads:
        qv = (q - c) @ Rm.T; nv = Rm @ n
        if nv[2] < -0.0 and not glow: pass
        depth = qv[:, 2].mean(); items.append((depth, qv, nv, col, glow))
    items.sort(key=lambda t: t[0])           # painter: far (negative z toward camera is +z) first
    for depth, qv, nv, col, glow in items:
        if nv[2] < 0 and not glow: continue   # back-face cull
        k = 1.0 if glow else 0.45 + 0.55 * max(0, float(nv @ light)); k = min(1.15, k)
        colr = tuple(min(255, int(v * k)) for v in col)
        poly = [(S / 2 + p[0] / ext * S, S / 2 - p[1] / ext * S) for p in qv]
        dr.polygon(poly, fill=colr, outline=tuple(int(v * 0.5) for v in colr))
    return img.resize((size, size), Image.LANCZOS)

if __name__ == "__main__":
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    for form in ("released", "apoc", "dormant"):
        views = [render(form, a) for a in (0, 35, 90)]; W = Image.new("RGB", (520 * 3, 520)); [W.paste(v, (i * 520, 0)) for i, v in enumerate(views)]
        out = os.path.join(ROOT, "build", "preview_%s.png" % form); W.save(out); print("wrote", out)
