#!/usr/bin/env python3
"""Verifies the resource pack against the plugin: valid JSON, textures exist, model bounds legal, every model key used by ModelDefs.java exists."""
import json, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
AS = os.path.join(ROOT, "resourcepack", "assets", "azrathiel"); bad = 0
def err(m):
    global bad; bad += 1; print("  FAIL", m)
models = {}; items = set()
for dp, _, fs in os.walk(AS):
    for f in fs:
        p = os.path.join(dp, f)
        if f.endswith(".json"):
            try: j = json.load(open(p))
            except Exception as e: err("invalid JSON %s: %s" % (p, e)); continue
            rel = os.path.relpath(p, AS).replace("\\", "/")
            if rel.startswith("models/"): models[rel[7:-5]] = j
            if rel.startswith("items/"): items.add(rel[6:-5])
        if f.endswith(".png"):
            d = open(p, "rb").read(32)
            if d[:8] != b"\x89PNG\r\n\x1a\n": err("not a PNG: " + p)
for key, m in models.items():
    for t in m.get("textures", {}).values():
        if t.startswith("azrathiel:") and not os.path.exists(os.path.join(AS, "textures", t[10:] + ".png")): err("%s references missing texture %s" % (key, t))
    for e in m.get("elements", []):
        for a, b in zip(e["from"], e["to"]):
            if not (-16 <= a <= 32 and -16 <= b <= 32): err("%s element out of bounds %s" % (key, e["from"]))
            if a > b: err("%s element from > to %s" % (key, e["from"]))
        if "rotation" in e and e["rotation"]["angle"] not in (-45, -22.5, 0, 22.5, 45): err("%s element rotation %s is not a vanilla-legal angle" % (key, e["rotation"]["angle"]))
        for fc in e["faces"].values():
            if any(v < 0 or v > 16 for v in fc["uv"]): err("%s has a uv outside 0..16: %s" % (key, fc["uv"]))
            ref = fc["texture"]
            if ref.startswith("#") and ref[1:] not in m["textures"]: err("%s face uses undefined texture variable %s" % (key, ref))
src = open(os.path.join(ROOT, "src/main/java/com/des/weapons/azrathiel/model/ModelDefs.java")).read()
needed = set(re.findall(r'"((?:dormant|released|apoc|mark)/[a-z_]+|core|core_apoc|frag_[abc])"', src))
needed |= {"fx/" + n for n in ["ring", "glow", "beam", "slash", "rune", "spark", "crack", "void", "eye", "crown", "soul", "hex"]}
needed |= {"dormant/body_glow", "released/head_glow", "released/torso_glow", "apoc/head_glow", "apoc/torso_glow"}
needed |= {"apoc/halo_" + n for n in ["vigor", "abyss", "fate", "ruin", "aegis", "evolution", "wraith", "dominion"]}   # built dynamically in ModelDefs
needed |= {"mark/%s%s" % (n, s) for n in ["vigor", "abyss", "fate", "ruin", "aegis", "evolution", "wraith", "dominion"] for s in ("", "_dim")}
for k in sorted(x for x in needed if not x.endswith("_")):
    if k not in items: err("item definition missing for model key " + k)
    if k not in models: err("model file missing for model key " + k)
if "weapon" not in items: err("weapon item definition missing")
print("pack check: %d models, %d item definitions, %d keys required by ModelDefs -> %s" % (len(models), len(items), len(needed), "OK" if not bad else "%d PROBLEM(S)" % bad))
sys.exit(1 if bad else 0)
