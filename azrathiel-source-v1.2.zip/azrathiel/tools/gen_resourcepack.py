#!/usr/bin/env python3
"""
Generates the AZRATHIEL resource pack (assets/azrathiel/...) with NO third-party dependencies.

  python3 tools/gen_resourcepack.py              # (re)generate models, textures, item definitions, sounds.json, voice manifest
  python3 tools/gen_resourcepack.py --scan-voice # also register any .ogg voice recordings found under assets/azrathiel/sounds/voice/

IMPORTANT / HONEST NOTE: the geometry here is procedural blocky art (cuboids) and the textures are procedurally drawn
16x16 / 32x32 pixel art. They make every bone of the rig render correctly and look intentional, but they are PLACEHOLDER-GRADE
art. For a showcase look, replace the files in assets/azrathiel/models and textures with Blockbench exports using the SAME file
names - nothing in the plugin needs to change.
"""
import json, os, random, re, struct, sys, zlib

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
PACK = os.path.join(ROOT, "resourcepack")
AS = os.path.join(PACK, "assets", "azrathiel")
EIDOLONS = [("vigor", 0xFF6A1F), ("abyss", 0x6A1BFF), ("fate", 0x7FDBFF), ("ruin", 0xB31217),
            ("aegis", 0x2E6FFF), ("evolution", 0x39E06B), ("wraith", 0xC9F4F0), ("dominion", 0xFFC83D)]

def w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w" if isinstance(data, str) else "wb") as f: f.write(data)
def wjson(path, obj): w(path, json.dumps(obj, indent=2) + "\n")
def rgb(c): return ((c >> 16) & 255, (c >> 8) & 255, c & 255)

# ------------------------------------------------------------------------------------------------ PNG writer
class Img:
    def __init__(self, wd, ht, fill=(0, 0, 0, 0)): self.w, self.h = wd, ht; self.px = [[fill] * wd for _ in range(ht)]
    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            cl = lambda v: max(0, min(255, int(v)))
            self.px[y][x] = (cl(c[0]), cl(c[1]), cl(c[2]), cl(c[3]) if len(c) == 4 else 255)
    def rect(self, x1, y1, x2, y2, c):
        for y in range(y1, y2 + 1):
            for x in range(x1, x2 + 1): self.put(x, y, c)
    def save(self, path):
        raw = b"".join(b"\x00" + bytes(v for p in row for v in p) for row in self.px)
        def ch(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
        data = b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b"")
        w(path, data)

def shade(c, k): return (max(0, min(255, int(c[0] * k))), max(0, min(255, int(c[1] * k))), max(0, min(255, int(c[2] * k))), 255)

def tex_bone(seed, base=(52, 46, 58)):
    """64x64 painted bone-armour: panelled plates, bevelled seams, rivets, engraved grooves, wear and faint violet cracks."""
    r = random.Random(seed); im = Img(64, 64)
    for y in range(64):
        for x in range(64):
            n = r.randint(-6, 6) + (4 if ((x // 16 + y // 16) % 2) else 0); im.put(x, y, (base[0] + n, base[1] + n, base[2] + n))
    for k in range(0, 64, 16):
        for i in range(64):
            im.put(i, k, shade(base, 0.45)); im.put(k, i, shade(base, 0.45))
            if k + 1 < 64: im.put(i, k + 1, shade(base, 1.55)); im.put(k + 1, i, shade(base, 1.35))
    for ky in range(0, 64, 16):
        for kx in range(0, 64, 16):
            for dx, dy in ((4, 4), (11, 4), (4, 11), (11, 11)):
                im.rect(kx + dx, ky + dy, kx + dx + 1, ky + dy + 1, shade(base, 1.9)); im.put(kx + dx + 2, ky + dy + 2, shade(base, 0.4))
            for i in range(5, 12): im.put(kx + 8, ky + i, shade(base, 0.5)); im.put(kx + 9, ky + i, shade(base, 1.3))
    for _ in range(9):                                                   # glowing violet fissures: random walks
        x, y = r.randint(2, 61), r.randint(2, 61)
        for _ in range(r.randint(6, 16)):
            im.put(x, y, (122, 27, 255)); im.put(x + 1, y, (70, 15, 150)); x += r.choice((-1, 0, 1)); y += r.choice((0, 1))
    for _ in range(60): im.put(r.randint(0, 63), r.randint(0, 63), shade(base, 1.8))     # edge wear
    return im

def tex_gold(seed):
    r = random.Random(seed); im = Img(64, 64)
    for y in range(64):
        for x in range(64): n = r.randint(-9, 9); im.put(x, y, (230 + n // 2, 178 + n, 50 + n // 2))
    for k in range(0, 64, 16):
        for i in range(64): im.put(i, k, (150, 105, 25)); im.put(k, i, (150, 105, 25)); im.put(i, k + 1, (255, 232, 150)); im.put(k + 1, i, (255, 222, 120))
    for ky in range(0, 64, 16):
        for kx in range(0, 64, 16):
            for i in range(4, 12):                                     # engraved diamond
                d = min(i - 4, 11 - i); im.put(kx + 8 - d - 1, ky + i, (120, 80, 15)); im.put(kx + 8 + d, ky + i, (120, 80, 15))
    return im

def tex_face():
    """64x64 skull face (mapped to the WHOLE texture on the front face): glowing gold eyes, brow ridge, nasal cavity, teeth, cracks, forehead sigil."""
    small = Img(16, 16, (190, 184, 172, 255)); r = random.Random(7)
    for y in range(16):
        for x in range(16): n = r.randint(-6, 6); small.put(x, y, (190 + n, 184 + n, 172 + n))
    for (x0, x1) in ((2, 6), (9, 13)):
        small.rect(x0, 4, x1, 8, (12, 10, 16)); small.rect(x0 + 1, 5, x1 - 1, 7, (255, 200, 61)); small.put(x0 + 2, 6, (255, 255, 225))
    small.rect(7, 9, 8, 11, (15, 12, 18)); small.rect(3, 12, 12, 14, (20, 16, 24))
    for x in range(3, 13, 2): small.rect(x, 12, x, 14, (205, 200, 188))
    small.rect(7, 1, 8, 3, (122, 27, 255))
    im = Img(64, 64)
    for y in range(64):
        for x in range(64): im.put(x, y, small.px[y // 4][x // 4])
    for y in range(64):
        for x in range(64):
            c = im.px[y][x]; n = r.randint(-5, 5); im.put(x, y, (c[0] + n, c[1] + n, c[2] + n) if c[3] else c)
    for i in range(64): im.put(i, 0, (80, 74, 88)); im.put(i, 63, (60, 54, 68)); im.put(0, i, (80, 74, 88)); im.put(63, i, (80, 74, 88))
    for _ in range(4):
        x, y = r.randint(8, 55), r.randint(36, 50)
        for _ in range(r.randint(5, 10)): im.put(x, y, (70, 64, 70)); x += r.choice((-1, 0, 1)); y += r.choice((-1, 0))
    return im

def tex_glow():
    im = Img(16, 16)
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5)) / 7.5; v = int(255 - 70 * d * d); im.put(x, y, (v, v, v))
    return im

def tex_shard():
    r = random.Random(11); im = Img(16, 16)
    for y in range(16):
        for x in range(16): n = r.randint(-8, 8); im.put(x, y, (58 + n, 48 + n, 84 + n))
    for i in range(16): im.put(i, i, (150, 120, 255)); im.put(15 - i, i, (110, 90, 200))
    for x in range(16): im.put(x, 0, (190, 170, 255)); im.put(x, 15, (35, 28, 55))
    return im

def tex_halo(c):
    im = Img(16, 16); base = rgb(c)
    for y in range(16):
        k = 1.25 - 0.55 * abs(y - 7.5) / 7.5
        for x in range(16): im.put(x, y, shade(base, k))
    for x in range(16): im.put(x, 0, (255, 255, 255)); im.put(x, 15, shade(base, 0.45))
    return im

GLYPHS = {
 "vigor": ["..####..", ".######.", "########", "..####..", "...##...", "...##...", "...##...", "..####.."],
 "abyss": ["..####..", ".#....#.", "#..##..#", "#.####.#", "#.####.#", "#..##..#", ".#....#.", "..####.."],
 "fate": ["........", "..####..", ".#....#.", "#..##..#", "#.####.#", ".#.##.#.", "..####..", "........"],
 "ruin": ["##....##", ".##..##.", "..####..", "...##...", "...##...", "..####..", ".##..##.", "##....##"],
 "aegis": ["########", "#......#", "#.####.#", "#.####.#", ".#.##.#.", ".#.##.#.", "..#..#..", "...##..."],
 "evolution": [".......#", "......##", ".....###", "....####", "...#####", "..######", ".#######", "########"],
 "wraith": ["..####..", ".#....#.", ".....##.", "....##..", "...##...", "...#....", "........", "...##..."],
 "dominion": ["#..##..#", "#.####.#", "########", "########", "#.#..#.#", "########", "########", "........"],
}
def tex_mark(name, c, lit):
    im = Img(16, 16, (14, 12, 20, 255)); col = rgb(c) if lit else (rgb(c)[0] // 5 + 30, rgb(c)[1] // 5 + 30, rgb(c)[2] // 5 + 30)
    for y, row in enumerate(GLYPHS[name]):
        for x, ch in enumerate(row):
            if ch == "#": im.rect(x * 2, y * 2, x * 2 + 1, y * 2 + 1, col)
    edge = rgb(c) if lit else (60, 58, 66)
    for i in range(16): im.put(i, 0, edge); im.put(i, 15, edge); im.put(0, i, edge); im.put(15, i, edge)
    return im

def tex_weapon():
    im = Img(32, 32)
    def line(x0, y0, x1, y1, c, t=1):
        n = max(abs(x1 - x0), abs(y1 - y0)) or 1
        for i in range(n + 1):
            x = round(x0 + (x1 - x0) * i / n); y = round(y0 + (y1 - y0) * i / n)
            for dx in range(-t, t + 1): im.put(x + dx, y, c); im.put(x, y + dx, c)
    for k in range(3, 0, -1): line(8, 24, 28, 4, (122, 27, 255, 70 * (4 - k)), k + 1)       # violet aura
    line(8, 24, 28, 4, (48, 44, 62), 1); line(9, 23, 29, 3, (150, 140, 175), 0)             # dark-steel blade with bright edge
    for i, (n, c) in enumerate(EIDOLONS):                                                   # eight inset gems along the blade
        t = (i + 1) / 9.0; x = round(8 + 20 * t); y = round(24 - 20 * t); im.rect(x - 1, y - 1, x, y, rgb(c))
    line(4, 20, 14, 28, (255, 200, 61), 0); line(5, 20, 15, 28, (200, 150, 30), 0)          # gold cross-guard
    line(7, 25, 3, 29, (38, 30, 44), 1); im.rect(2, 29, 3, 30, (255, 200, 61))              # grip and pommel
    return im

# ------------------------------------------------------------------------------------------------ models
FACES = ["north", "east", "south", "west", "up", "down"]
def C(x1, y1, z1, x2, y2, z2): return [8 + x1, 8 + y1, 8 + z1], [8 + x2, 8 + y2, 8 + z2]

def el(box, tex="#0", tint=False, rot=None, face_tex=None, faces=None, full=()):
    """Cuboid element. Faces listed in `full` (or given a face_tex) map the ENTIRE texture; all others sample a varied window so plates differ."""
    frm, to = box; wd, ht, dp = to[0] - frm[0], to[1] - frm[1], to[2] - frm[2]
    dims = {"north": (wd, ht), "south": (wd, ht), "east": (dp, ht), "west": (dp, ht), "up": (wd, dp), "down": (wd, dp)}
    f = {}
    for idx, k in enumerate(faces or FACES):
        a, b = dims[k]; aw, bh = min(16, max(1, a)), min(16, max(1, b))
        if k in full or (face_tex and k in face_tex): uv = [0, 0, 16, 16]
        else:
            h = int((frm[0] * 31 + frm[1] * 17 + frm[2] * 13 + idx * 7) * 100) & 0xFFFF
            ox = ((h % (int((16 - aw) * 2) + 1)) * 0.5); oy = (((h >> 3) % (int((16 - bh) * 2) + 1)) * 0.5)
            uv = [round(ox, 2), round(oy, 2), round(ox + aw, 2), round(oy + bh, 2)]
        fc = {"uv": uv, "texture": (face_tex or {}).get(k, tex)}
        if tint: fc["tintindex"] = 0
        f[k] = fc
    e = {"from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to], "faces": f}
    if rot: e["rotation"] = {"angle": rot[0], "axis": rot[1], "origin": [round(v, 3) for v in rot[2]]}
    return e

def mirror(box): (x1, y1, z1), (x2, y2, z2) = box; return [16 - x2, y1, z1], [16 - x1, y2, z2]
def pivot(box): (x1, y1, z1), (x2, y2, z2) = box; return [(x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2]

def model(elements, textures):
    return {"textures": dict(textures, particle=list(textures.values())[0]), "elements": elements,
            "display": {"fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]}}}

T = lambda n: "azrathiel:item/" + n
MODELS = {}   # key -> (model json, uses tint)

def add(key, elements, textures, tint=False): MODELS[key] = (model(elements, textures), tint)

def horn(sign, y0, out_rot=22.5, tex="#0"):
    """three stacked boxes curving up and outward"""
    els = []
    for i in range(3):
        x = sign * (3.6 + i * 1.6); y = y0 + i * 2.0; b = C(x - 0.9, y, -0.9, x + 0.9, y + 2.4, 0.9)
        els.append(el(b, tex, rot=(out_rot * sign * -1, "z", pivot(b))))
    return els

def build_models():
    bone = {"0": T("bone_armor"), "1": T("skull_face"), "2": T("shard"), "3": T("gold_trim")}
    # ---- Dormant ----
    e = [el(C(-3.6, -3.2, -3.4, 3.6, 3.8, 3.4), face_tex={"south": "#1"}), el(C(-2.6, -5.2, -2.4, 2.6, -3.2, 2.6)), el(C(-4.2, 2.0, -3.0, 4.2, 3.2, 3.6)),
         el(C(-0.6, 3.8, -0.6, 0.6, 7.6, 0.6), "#3"), el(C(-4.4, -2.5, -2.0, -3.6, 1.5, 2.0)), el(C(3.6, -2.5, -2.0, 4.4, 1.5, 2.0)), el(C(-1, -2, 3.4, 1, 5, 5.0), "#2")]
    b1 = C(-2.6, 3.8, -0.4, -1.6, 6.2, 0.4); b2 = C(1.6, 3.8, -0.4, 2.6, 6.2, 0.4)
    e += [el(b1, "#3", rot=(22.5, "z", pivot(b1))), el(b2, "#3", rot=(-22.5, "z", pivot(b2))), el(C(-6.4, -1, -1.5, -4.8, 3, 1.5), "#2"), el(C(4.8, -1, -1.5, 6.4, 3, 1.5), "#2")]
    add("dormant/body", e, bone)
    ring = []
    for sx in (-1, 1):
        ring.append(el(([8 - 2.7, 8 + sx * 6.5 - 0.3, 7.7], [8 + 2.7, 8 + sx * 6.5 + 0.3, 8.3]), "#0", tint=True))
        ring.append(el(([8 + sx * 6.5 - 0.3, 8 - 2.7, 7.7], [8 + sx * 6.5 + 0.3, 8 + 2.7, 8.3]), "#0", tint=True))
    for sx, sy in ((1, 1), (-1, -1), (1, -1), (-1, 1)):
        cx, cy = 8 + sx * 4.6, 8 + sy * 4.6; ring.append(el(([cx - 2.7, cy - 0.6, 7.4], [cx + 2.7, cy + 0.6, 8.6]), "#0", tint=True, rot=(-45 if sx == sy else 45, "z", [cx, cy, 8])))
    add("dormant/ring", ring, {"0": T("glow_white")}, True)
    core = [el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "y", [8, 8, 8])), el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "x", [8, 8, 8])), el(C(-3, -3, -3, 3, 3, 3), "#0", True, rot=(45, "z", [8, 8, 8]))]
    add("core", core, {"0": T("glow_white")}, True)
    spikes = list(core)
    for (a, b_) in ((C(-0.5, -0.5, 4, 0.5, 0.5, 8)), (C(-0.5, -0.5, -8, 0.5, 0.5, -4)), (C(-0.5, 4, -0.5, 0.5, 8, 0.5)), (C(-0.5, -8, -0.5, 0.5, -4, 0.5)), (C(4, -0.5, -0.5, 8, 0.5, 0.5)), (C(-8, -0.5, -0.5, -4, 0.5, 0.5))):
        spikes.append(el(([a[0], a[1], a[2]], [b_[0], b_[1], b_[2]]), "#0", True))
    add("core_apoc", spikes, {"0": T("glow_white")}, True)
    add("frag_a", [el(C(-1, -5, -1, 1, 5, 1), "#0", rot=(22.5, "z", [8, 8, 8])), el(C(-1.5, -2, -1.5, 1.5, 2, 1.5), "#0")], {"0": T("shard")})
    wedge = C(-2, -4, -1, 2, 4, 1); add("frag_b", [el(wedge, "#0", rot=(45, "x", pivot(wedge))), el(C(-1, -5, -0.5, 1, 5, 0.5), "#0")], {"0": T("shard")})
    add("frag_c", [el(C(-0.8, -5, -0.8, 0.8, 5, 0.8), "#0", rot=(45, "z", [8, 8, 8])), el(C(-0.8, -5, -0.8, 0.8, 5, 0.8), "#0", rot=(-45, "z", [8, 8, 8]))], {"0": T("shard")})

    # ---- Released / Apocalypse bodies (v2: segmented, layered, detailed) ----
    def torso(apoc):
        G = "#3" if apoc else "#0"
        t = [el(C(-6.5, -2, -4, 6.5, 9, 4)), el(C(-4.8, -8, -3, 4.8, -2, 3)), el(C(-5.6, -10, -3.4, 5.6, -8, 3.4)), el(C(-4.6, 9, -3, 4.6, 11, 3)),
             el(C(-5.8, -3.5, 4.0, 5.8, 8.2, 4.7)), el(C(-1.2, -2, 4.7, 1.2, 8.5, 5.5), G), el(C(-5.2, -8.7, -3.6, 5.2, -7.5, 3.6), "#3")]
        for i in range(5):
            y = -1 + i * 2.1; t.append(el(C(-6.4, y, 4.6, 6.4, y + 0.9, 5.3)))
            t.append(el(C(-7.4, y, -2.5, -6.4, y + 0.9, 4.3))); t.append(el(C(6.4, y, -2.5, 7.4, y + 0.9, 4.3)))
        for i in range(6):                                                                       # spine: vertebrae + processes
            y = -8 + i * 2.9; t.append(el(C(-1.6, y, -5.4, 1.6, y + 1.5, -4.2), "#2")); t.append(el(C(-0.5, y + 0.2, -6.5, 0.5, y + 1.2, -5.4), "#2"))
        for sx in (-1, 1):
            for j, (y0, y1, x0, x1, zz) in enumerate(((6.5, 10.5, 7, 12.5, 3.6), (4.2, 6.5, 7.8, 12.2, 3.2), (2.2, 4.2, 8.4, 11.8, 2.8))):   # layered pauldrons
                b = C(x0, y0, -zz, x1, y1, zz) if sx == 1 else C(-x1, y0, -zz, -x0, y1, zz); t.append(el(b, G if j == 0 else "#0"))
            sp = C(9, 10.5, -0.8, 12.5, 15, 0.8) if sx == 1 else C(-12.5, 10.5, -0.8, -9, 15, 0.8); t.append(el(sp, G, rot=(-22.5 * sx, "z", pivot(sp))))
            sp2 = C(10.5, 8.5, -3.8, 12.8, 11.5, -1.8) if sx == 1 else C(-12.8, 8.5, -3.8, -10.5, 11.5, -1.8); t.append(el(sp2, "#2", rot=(22.5 * sx, "y", pivot(sp2))))
            bl = C(1.8, 0, -5.2, 5.5, 8, -4.2) if sx == 1 else C(-5.5, 0, -5.2, -1.8, 8, -4.2); t.append(el(bl))                              # shoulder blades
        for x0, x1 in ((-4.8, -2.2), (-1.2, 1.2), (2.2, 4.8)): t.append(el(C(x0, -15, 2.8, x1, -10, 3.8)))        # tassets
        for i, x in enumerate((-3, 0, 3)): bk = C(x - 0.6, 8, -6.5, x + 0.6, 14 + (i == 1) * 2, -5); t.append(el(bk, G if apoc else "#2", rot=(-22.5, "x", pivot(bk))))
        for q in ((-3.2, 0.6, -3.2, 1.4), (-3.2, 6.0, 3.2, 6.8)): t.append(el(C(q[0], q[1], 4.7, q[2] if q[2] > 0 else 3.2, q[3], 5.4), "#3"))   # core socket frame
        t += [el(C(-3.2, 0.6, 4.7, -2.4, 6.8, 5.4), "#3"), el(C(2.4, 0.6, 4.7, 3.2, 6.8, 5.4), "#3")]
        if apoc:
            t += [el(C(-0.9, 9, 4.9, 0.9, 16, 6.2), "#3"), el(C(-6.5, 7.5, 4.2, 6.5, 8.6, 5.0), "#3")]
            for sx in (-1, 1):
                cr = C(5 * sx - 0.8, 10, -0.8, 5 * sx + 0.8, 17, 0.8) if sx == 1 else C(-5.8, 10, -0.8, -4.2, 17, 0.8); t.append(el(cr, "#3", rot=(-22.5 * sx, "z", pivot(cr))))
        return t
    add("released/torso", torso(False), bone); add("apoc/torso", torso(True), bone)

    def head(apoc):
        h = [el(C(-4.2, -3.6, -4, 4.2, 4.6, 4), face_tex={"south": "#1"}), el(C(-3.2, -7, -2.6, 3.2, -4.4, 3.4)), el(C(-4.8, 2.6, -3.4, 4.8, 3.8, 4.4)),
             el(C(-5, -2, -2.4, -4.2, 2.6, 2.4)), el(C(4.2, -2, -2.4, 5, 2.6, 2.4)), el(C(-1.2, 4.6, -3.8, 1.2, 5.6, 3.2), "#2"), el(C(-4.4, -4.4, -3.6, 4.4, -3.6, 4.2), "#2")]
        for i in range(6): x = -2.5 + i * 1.0; h.append(el(C(x, -5.4, 3.0, x + 0.6, -4.4, 3.7), "#1"))            # lower teeth
        for sx in (-1, 1):
            h.append(el(C(sx * 4.6 - 0.5, -4, 2.2, sx * 4.6 + 0.5, -1, 4.6), "#3" if apoc else "#2", rot=(22.5 * sx, "z", [8 + sx * 4.6, 8 - 2.5, 8 + 3.4])))   # cheek spikes
        h += horn(-1, 3.0) + horn(1, 3.0)
        for sx in (-1, 1):                                                                                          # 4th horn segment: tips
            tb = C(sx * 8.2 - 0.6, 9.4, -0.6, sx * 8.2 + 0.6, 12.6, 0.6); h.append(el(tb, "#3" if apoc else "#0", rot=(-22.5 * sx, "z", pivot(tb))))
        if apoc:
            for i, x in enumerate((-3.2, -1.6, 0, 1.6, 3.2)):
                sp = C(x - 0.6, 4.6, -0.6, x + 0.6, 8.5 + (3 - abs(i - 2)) * 1.6, 0.6); h.append(el(sp, "#3", rot=([-22.5, -22.5, 0, 22.5, 22.5][i], "z", pivot(sp))))   # vanilla only allows 0, +-22.5, +-45
        return h
    add("released/head", head(False), bone); add("apoc/head", head(True), bone)

    ua = [el(C(-1.8, -9.3, -1.8, 1.8, 0, 1.8)), el(C(-2.6, -2.6, -2.6, 2.6, 2.6, 2.6)), el(C(-0.8, -9.3, 1.8, 0.8, -4, 2.8), "#3")]
    for i in range(3): y = -8 + i * 2.6; ua.append(el(C(-2.7, y, -2.7, 2.7, y + 1.6, 2.7), "#2" if i == 1 else "#0"))      # stacked biceps plates
    sp = C(1.8, -6, -0.7, 4.6, -2.5, 0.7); ua.append(el(sp, "#0", rot=(-22.5, "z", pivot(sp))))
    add("released/arm_upper", ua, bone)
    la = [el(C(-1.4, -9.3, -1.4, 1.4, 0, 1.4)), el(C(-2.2, -3, -2.2, 2.2, 0.6, 2.2), "#2"), el(C(-2.5, -7.5, -2.5, 2.5, -4.5, 2.5)), el(C(-2.0, -10.4, -1.8, 2.0, -9.3, 1.8))]
    for i, x in enumerate((-1.8, -0.6, 0.6, 1.8)):                                                                     # four clawed fingers
        c = C(x - 0.35, -13.2, -0.6, x + 0.35, -10.4, 0.6); la.append(el(c, "#0", rot=(22.5 if i in (0, 3) and False else 0, "x", pivot(c))))
    el_sp = C(1.4, -5, -0.6, 4.4, -3, 0.6); la.append(el(el_sp, "#2", rot=(22.5, "z", pivot(el_sp))))              # elbow blade
    add("released/arm_lower", la, bone)
    hs = [el(C(-1.4, -5.5, -0.8, 1.4, 5.5, 0.8), "#0", True), el(C(-2.2, -4.5, -0.4, -1.4, 4.5, 0.4), "#0", True)]
    add("released/halo_seg", hs, {"0": T("glow_white")}, True)
    for name, c in EIDOLONS:
        add("apoc/halo_" + name, [el(C(-1.4, -5.5, -0.8, 1.4, 5.5, 0.8), "#0"), el(C(1.4, -1.0, -0.5, 4.2, 1.0, 0.5), "#0")], {"0": T("halo_" + name)})
        for suffix in ("", "_dim"):
            add("mark/" + name + suffix, [el(([0, 0, 7.7], [16, 16, 8.3]), "#0", faces=["north", "south"], full=("north", "south"))], {"0": T("mark_" + name + suffix)})

    # ---- full-bright glow overlays: thin tinted boxes that sit just proud of the armour (eyes, brow runes, circuitry) ----
    def glow(boxes): return [el(b, "#0", True) for b in boxes]
    eyes = [C(-3.5, 0.9, 4.05, -1.0, 2.1, 4.45), C(1.0, 0.9, 4.05, 3.5, 2.1, 4.45)]
    brow = [C(-3.9, 3.0, 4.05, -0.6, 3.5, 4.4), C(0.6, 3.0, 4.05, 3.9, 3.5, 4.4), C(-0.3, 3.6, 4.05, 0.3, 6.4, 4.4), C(-1.2, 4.6, 4.05, 1.2, 5.0, 4.4)]
    add("dormant/body_glow", glow([C(-2.6, 0.7, 3.5, -0.9, 1.9, 3.8), C(0.9, 0.7, 3.5, 2.6, 1.9, 3.8), C(-0.3, 2.6, 3.5, 0.3, 3.8, 3.8)]), {"0": T("glow_white")}, True)
    for key, extra in (("released", []), ("apoc", [C(-4.6, 4.5, 3.2, 4.6, 4.9, 4.2)])):
        add(key + "/head_glow", glow(eyes + brow + extra), {"0": T("glow_white")}, True)
        circ = [C(-0.35, -3.5, 5.55, 0.35, -1.2, 5.75), C(-0.35, 6.9, 5.55, 0.35, 8.4, 5.75), C(-3.0, 3.4, 5.55, -2.5, 4.4, 5.75), C(2.5, 3.4, 5.55, 3.0, 4.4, 5.75)]
        for i in range(5): y = -1 + i * 2.1; circ += [C(-3.8, y + 0.3, 5.35, -1.8, y + 0.6, 5.5), C(1.8, y + 0.3, 5.35, 3.8, y + 0.6, 5.5)]       # rib circuitry
        for i in range(6): circ.append(C(-0.4, -8 + i * 2.9 + 0.4, -6.7, 0.4, -8 + i * 2.9 + 1.0, -6.5))                                           # spine glow
        circ += [C(8.5, 8.2, 3.4, 11.5, 8.6, 3.8), C(-11.5, 8.2, 3.4, -8.5, 8.6, 3.8)]
        if key == "apoc": circ += [C(-0.4, 9.5, 6.3, 0.4, 15.5, 6.5), C(-6.2, 7.7, 5.0, 6.2, 8.0, 5.2)]
        add(key + "/torso_glow", glow(circ), {"0": T("glow_white")}, True)


# ------------------------------------------------------------------------------------------------ VFX quads (white + alpha, recoloured at runtime by the tint)
import math
def _sm(a, b, x): t = max(0.0, min(1.0, (x - a) / (b - a))); return t * t * (3 - 2 * t)
def _seg(u, v, p, q):
    dx, dy = q[0] - p[0], q[1] - p[1]; l2 = dx * dx + dy * dy
    t = 0 if l2 == 0 else max(0, min(1, ((u - p[0]) * dx + (v - p[1]) * dy) / l2)); return math.hypot(u - (p[0] + t * dx), v - (p[1] + t * dy)), t
def _g(d, w): return math.exp(-(d / w) ** 2)

def fx_ring(u, v): r = math.hypot(u, v); return _g(r - 0.43, 0.022) + 0.35 * _g(r - 0.43, 0.07) + 0.12 * _g(r - 0.40, 0.2)
def fx_glow(u, v): r = math.hypot(u, v); return max(0, 1 - r / 0.5) ** 2 + 0.9 * _g(r, 0.06)
def fx_beam(u, v): e = min(1.0, (0.5 - abs(u)) / 0.1); return max(0, e) * (_g(v, 0.09) * 0.7 + _g(v, 0.022))
def fx_slash(u, v):
    d1 = math.hypot(u, v); d2 = math.hypot(u - 0.17, v); inside = _sm(0.0, 0.02, 0.46 - d1); outside = _sm(0.0, 0.03, d2 - 0.36)
    taper = max(0.0, 1 - (abs(v) / 0.46) ** 3); return min(1.0, inside * outside * (0.45 + 0.9 * taper) * 1.2)
_RUNE_STAR = [((0.30 * math.cos(k * math.pi / 4), 0.30 * math.sin(k * math.pi / 4)), (0.30 * math.cos((k + 3) * math.pi / 4), 0.30 * math.sin((k + 3) * math.pi / 4))) for k in range(8)]
def fx_rune(u, v):
    r = math.hypot(u, v); a = _g(r - 0.47, 0.009) + 0.8 * _g(r - 0.435, 0.006) + _g(r - 0.30, 0.007) + 0.7 * _g(r - 0.18, 0.006)
    th = math.atan2(v, u)
    if 0.445 < r < 0.465: a += 0.8 * (1 if (th * 24 / math.pi) % 1 < 0.35 else 0)                      # tick ring
    for p, q in _RUNE_STAR: a += 0.8 * _g(_seg(u, v, p, q)[0], 0.006)                                     # {8/3} star
    for k in range(8):
        cx, cy = 0.385 * math.cos(k * math.pi / 4 + math.pi / 8), 0.385 * math.sin(k * math.pi / 4 + math.pi / 8); a += _g(math.hypot(u - cx, v - cy) - 0.02, 0.006) * 1.2   # eight glyph rings
    return a + 0.5 * _g(r, 0.05)
def fx_spark(u, v):
    r = math.hypot(u, v); h = _g(v, 0.012) * max(0, 1 - abs(u) / 0.5) ** 2; w_ = _g(u, 0.012) * max(0, 1 - abs(v) / 0.5) ** 2
    a1 = (u + v) * 0.7071; b1 = (u - v) * 0.7071; d = (_g(a1, 0.01) * max(0, 1 - abs(b1) / 0.4) ** 2 + _g(b1, 0.01) * max(0, 1 - abs(a1) / 0.4) ** 2) * 0.5
    return h + w_ + d + _g(r, 0.06) * 1.2
import random as _rnd
def _crack_polylines():
    r = _rnd.Random(21); lines = []
    for k in range(11):
        th = k * 2 * math.pi / 11 + r.uniform(-0.2, 0.2); L = r.uniform(0.32, 0.5); pts = [(0.0, 0.0)]; a = th
        for i in range(1, 7): a += r.uniform(-0.35, 0.35); pts.append((pts[-1][0] + math.cos(a) * L / 6, pts[-1][1] + math.sin(a) * L / 6))
        lines.append(pts)
        if r.random() < 0.6: b = pts[3]; a2 = th + r.choice((-1, 1)) * 0.7; lines.append([b, (b[0] + math.cos(a2) * 0.12, b[1] + math.sin(a2) * 0.12)])
    return lines
_CRACKS = _crack_polylines()
def fx_crack(u, v):
    best = 0.0
    for pts in _CRACKS:
        for i in range(len(pts) - 1):
            d, t = _seg(u, v, pts[i], pts[i + 1]); w_ = 0.014 * (1 - 0.7 * (i + t) / max(1, len(pts) - 1)) + 0.002; best = max(best, _g(d, w_))
    return best + 0.5 * _g(math.hypot(u, v), 0.06)
def fx_void(u, v):
    r = math.hypot(u, v); th = math.atan2(v, u)
    if r > 0.5: return 0.0
    arms = (0.5 + 0.5 * math.cos(3 * (th - 14 * r))) ** 3; return min(1.0, arms * _sm(0.03, 0.1, r) * (1 - _sm(0.38, 0.5, r)) * 1.2 + _g(r - 0.45, 0.012) * 0.8 + 0.5 * _g(r, 0.04))
def fx_eye(u, v):
    a = 0.0
    if abs(u) < 0.46: h = 0.2 * (1 - (u / 0.46) ** 2); a += _g(abs(v) - h, 0.014)
    r = math.hypot(u, v); a += _g(r - 0.105, 0.012) + (1.0 if r < 0.045 else 0) * 0.9
    for k in range(10): th = k * math.pi / 5; a += 0.7 * _g(_seg(u, v, (0.15 * math.cos(th), 0.15 * math.sin(th)), (0.21 * math.cos(th), 0.21 * math.sin(th)))[0], 0.006) if abs(u) < 0.46 else 0
    return a
_CROWN = [(-0.34, -0.2), (0.34, -0.2), (0.38, 0.16), (0.18, -0.02), (0.0, 0.26), (-0.18, -0.02), (-0.38, 0.16)]
def _inpoly(u, v, poly):
    c = False
    for i in range(len(poly)):
        x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % len(poly)]
        if (y1 > v) != (y2 > v) and u < (x2 - x1) * (v - y1) / (y2 - y1) + x1: c = not c
    return c
def fx_crown(u, v):
    edge = min(_seg(u, v, _CROWN[i], _CROWN[(i + 1) % len(_CROWN)])[0] for i in range(len(_CROWN))); a = 0.45 if _inpoly(u, v, _CROWN) else 0.0
    for gx in (-0.24, 0.0, 0.24): a += 0.9 * _g(math.hypot(u - gx, v + 0.12) - 0.025, 0.01)
    return a + 1.1 * _g(edge, 0.012)
def fx_soul(u, v):
    a = _g(math.hypot(u, v - 0.2) - 0.14, 0.03) * 0.8 + (0.45 if math.hypot(u, v - 0.2) < 0.14 else 0)
    for i in range(24):
        s = i / 23.0; cx, cy = 0.11 * math.sin(5 * s) * s * 1.6, 0.18 - 0.62 * s; a = max(a, _g(math.hypot(u - cx, v - cy), 0.05 * (1 - 0.8 * s)) * (1 - 0.6 * s))
    for ex in (-0.05, 0.05):
        if math.hypot(u - ex, v - 0.22) < 0.022: a *= 0.0
    return a
def fx_hex(u, v):
    x, y = (u + 0.5) * 5.0, (v + 0.5) * 5.0 * 1.7320508 / 1.7320508
    def hd(px, py): px, py = abs(px), abs(py); return max(px * 0.5 + py * 0.8660254, px)
    ra, rb = (1.0, 1.7320508), (0.5, 0.8660254)
    ga = ((x % ra[0]) - ra[0] / 2, (y % ra[1]) - ra[1] / 2); gb = (((x - rb[0]) % ra[0]) - ra[0] / 2, ((y - rb[1]) % ra[1]) - ra[1] / 2)
    g = ga if ga[0] ** 2 + ga[1] ** 2 < gb[0] ** 2 + gb[1] ** 2 else gb; d = hd(*g)
    border = _g(0.5 - max(abs(u), abs(v)), 0.012) * 1.1
    vert = 0.35 + 0.65 * (1 - abs(v) * 2) ** 2
    return max(0.0, (_g(d - 0.5, 0.03) * 0.95 + 0.10) * vert) + border

FX_TEXTURES = {"ring": fx_ring, "glow": fx_glow, "beam": fx_beam, "slash": fx_slash, "rune": fx_rune, "spark": fx_spark, "crack": fx_crack, "void": fx_void, "eye": fx_eye, "crown": fx_crown, "soul": fx_soul, "hex": fx_hex}

def build_fx():
    tx = os.path.join(AS, "textures", "item")
    for name, fn in FX_TEXTURES.items():
        n = 128; im = Img(n, n)
        for y in range(n):
            for x in range(n):
                a = fn((x + 0.5) / n - 0.5, 0.5 - (y + 0.5) / n); im.put(x, y, (255, 255, 255, int(255 * max(0.0, min(1.0, a)))))
        im.save(os.path.join(tx, "fx_%s.png" % name))
        add("fx/" + name, [el(([0, 0, 7.9], [16, 16, 8.1]), "#0", True, faces=["north", "south"], full=("north", "south"))], {"0": T("fx_" + name)}, True)

def build_textures():
    tx = os.path.join(AS, "textures", "item")
    tex_bone(3).save(os.path.join(tx, "bone_armor.png")); tex_gold(5).save(os.path.join(tx, "gold_trim.png")); tex_face().save(os.path.join(tx, "skull_face.png"))
    tex_glow().save(os.path.join(tx, "glow_white.png")); tex_shard().save(os.path.join(tx, "shard.png")); tex_weapon().save(os.path.join(tx, "weapon.png"))
    for name, c in EIDOLONS:
        tex_halo(c).save(os.path.join(tx, "halo_" + name + ".png"))
        tex_mark(name, c, True).save(os.path.join(tx, "mark_" + name + ".png")); tex_mark(name, c, False).save(os.path.join(tx, "mark_" + name + "_dim.png"))

# ------------------------------------------------------------------------------------------------ sounds + voice manifest
SFX = {  # custom event -> (vanilla event, volume, pitch). Replace later with real .ogg by pointing "name" at your file.
 "cast.vigor": ("minecraft:entity.iron_golem.damage", 1.0, 0.6), "cast.abyss": ("minecraft:entity.enderman.teleport", 1.0, 0.5),
 "cast.fate": ("minecraft:block.amethyst_block.resonate", 1.0, 1.0), "cast.ruin": ("minecraft:entity.wither.shoot", 1.0, 0.6),
 "cast.aegis": ("minecraft:block.beacon.activate", 1.0, 1.0), "cast.evolution": ("minecraft:block.respawn_anchor.charge", 1.0, 1.2),
 "cast.wraith": ("minecraft:particle.soul_escape", 1.0, 0.8), "cast.dominion": ("minecraft:entity.ender_dragon.growl", 0.8, 0.7),
 "transform": ("minecraft:entity.wither.spawn", 0.9, 0.7), "release": ("minecraft:block.beacon.power_select", 1.0, 0.8), "dismiss": ("minecraft:block.beacon.deactivate", 1.0, 0.8),
 "summon": ("minecraft:block.beacon.activate", 1.0, 0.7), "ultimate.awaken": ("minecraft:entity.ender_dragon.growl", 1.0, 0.5), "ultimate.charge": ("minecraft:entity.warden.sonic_charge", 1.0, 0.8),
 "ultimate.main": ("minecraft:entity.warden.sonic_boom", 1.0, 0.7), "ultimate.impact": ("minecraft:entity.generic.explode", 1.0, 0.6), "lastguardian": ("minecraft:entity.warden.roar", 1.0, 0.7),
 "intercept": ("minecraft:item.shield.block", 1.0, 1.0), "hit": ("minecraft:entity.player.attack.strong", 1.0, 0.9), "combo": ("minecraft:block.end_portal.spawn", 0.8, 1.2)}

def parse_voice(path):
    cats = {}; out = []; cur = None
    eid = {n for n, _ in EIDOLONS}
    for raw in open(path, encoding="utf-8").read().splitlines():
        s = raw.strip()
        if not s or s.startswith("#"): continue
        if s.startswith("@"): cur = s[1:].strip().lower(); continue
        sub = eidol = None
        while s.startswith("["):
            j = s.index("]"); tag = s[1:j].strip(); s = s[j + 1:].lstrip()
            if tag.startswith("#"): sub = tag[1:].lower()
            elif tag.lower() in eid: eidol = tag.lower()
        cats[cur] = cats.get(cur, 0) + 1
        out.append({"id": "%s.%03d" % (cur, cats[cur]), "sound": "%s_%03d" % (cur, cats[cur]), "category": cur, "sub": sub, "eidolon": eidol, "text": s})
    return out

def build_sounds(scan):
    ev = {k: {"sounds": [{"name": v[0], "type": "event", "volume": v[1], "pitch": v[2]}]} for k, v in SFX.items()}
    found = 0
    if scan:
        base = os.path.join(AS, "sounds", "voice")
        for dp, _, fs in os.walk(base):
            for f in fs:
                if not f.endswith(".ogg"): continue
                rel = os.path.relpath(os.path.join(dp, f), os.path.join(AS, "sounds")).replace("\\", "/")[:-4]; parts = rel.split("/")
                if len(parts) == 2: ev["voice." + parts[1]] = {"sounds": [{"name": "azrathiel:" + rel, "stream": True}]}; found += 1
                elif len(parts) == 4 and parts[1] == "layers": ev["voice.layer.%s.%s" % (parts[2], parts[3])] = {"sounds": [{"name": "azrathiel:" + rel, "stream": True}]}; found += 1
    wjson(os.path.join(AS, "sounds.json"), ev); return found

def build_manifest():
    voice = os.path.join(ROOT, "src", "main", "resources", "azrathiel", "voice", "vaelzarion_voice.txt")
    lines = parse_voice(voice); man = []
    for l in lines:
        have = os.path.exists(os.path.join(AS, "sounds", "voice", l["sound"] + ".ogg"))
        e = dict(l, file="assets/azrathiel/sounds/voice/%s.ogg" % l["sound"], status="RECORDED" if have else "MISSING_RECORDING")
        e["layers"] = {n: "assets/azrathiel/sounds/voice/layers/%s/%s.ogg" % (n, l["sound"]) for n, _ in EIDOLONS}
        man.append(e)
    wjson(os.path.join(PACK, "voice_manifest.json"), {"note": "Every authored line, its text, and the file name the plugin will look for. NO recordings are included.", "count": len(man), "lines": man})
    return len(man)


# ------------------------------------------------------------------------------------------------ Blockbench export (editable sources)
def bbmodel(key, m):
    """Blockbench 'java_block' project for one model so an artist can open, refine or replace it. Generated from the same data as the pack;
    NOT opened in Blockbench by the generator author - if a build of Blockbench rejects a file, the pack JSON models remain the source of truth."""
    import base64, uuid
    vars_ = sorted([k for k in m["textures"] if k != "particle"], key=int); textures = []
    for i, v in enumerate(vars_):
        fn = m["textures"][v].split("/")[-1] + ".png"; raw = open(os.path.join(AS, "textures", "item", fn), "rb").read(); wd, ht = struct.unpack(">II", raw[16:24])
        textures.append({"path": "", "name": fn, "folder": "", "namespace": "azrathiel", "id": str(i), "width": wd, "height": ht, "uv_width": 16, "uv_height": 16, "particle": i == 0,
                         "render_mode": "default", "render_sides": "auto", "frame_time": 1, "frame_order_type": "loop", "frame_order": "", "frame_interpolate": False, "visible": True,
                         "internal": True, "saved": False, "uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, key + fn)), "relative_path": "", "source": "data:image/png;base64," + base64.b64encode(raw).decode()})
    els = []
    for n, e in enumerate(m["elements"]):
        rot = [0, 0, 0]; org = [8, 8, 8]
        if "rotation" in e: rot["xyz".index(e["rotation"]["axis"])] = e["rotation"]["angle"]; org = e["rotation"]["origin"]
        faces = {}
        for fk, fc in e["faces"].items():
            d = {"uv": fc["uv"], "texture": vars_.index(fc["texture"][1:])}
            if "tintindex" in fc: d["tintindex"] = fc["tintindex"]
            faces[fk] = d
        els.append({"name": "%s_%02d" % (key.replace("/", "_"), n), "box_uv": False, "rescale": False, "locked": False, "light_emission": 0, "render_order": "default", "allow_mirror_modeling": True,
                    "from": e["from"], "to": e["to"], "autouv": 0, "color": n % 8, "origin": org, "rotation": rot, "faces": faces, "type": "cube", "uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, "%s#%d" % (key, n)))})
    group = {"name": key.replace("/", "_"), "origin": [8, 8, 8], "color": 0, "uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, key)), "export": True, "mirror_uv": False, "isOpen": True,
             "locked": False, "visibility": True, "autouv": 0, "children": [e["uuid"] for e in els]}
    return {"meta": {"format_version": "4.10", "model_format": "java_block", "box_uv": False}, "name": key.replace("/", "_"), "model_identifier": "", "visible_box": [1, 1, 0],
            "resolution": {"width": 16, "height": 16}, "elements": els, "outliner": [group], "textures": textures}

def export_bbmodels():
    n = 0
    for key, (m, tint) in MODELS.items():
        wjson(os.path.join(ROOT, "blockbench", key + ".bbmodel"), bbmodel(key, m)); n += 1
    return n

def main():
    scan = "--scan-voice" in sys.argv
    build_models(); build_textures(); build_fx()
    for key, (m, tint) in MODELS.items():
        wjson(os.path.join(AS, "models", key + ".json"), m)
        item = {"model": {"type": "minecraft:model", "model": "azrathiel:" + key}}
        if tint: item["model"]["tints"] = [{"type": "minecraft:custom_model_data", "index": 0, "default": 16777215}]
        wjson(os.path.join(AS, "items", key + ".json"), item)
    wjson(os.path.join(AS, "models", "weapon.json"), {"parent": "minecraft:item/handheld", "textures": {"layer0": "azrathiel:item/weapon"}})
    wjson(os.path.join(AS, "items", "weapon.json"), {"model": {"type": "minecraft:model", "model": "azrathiel:weapon"}})
    nbb = export_bbmodels(); n = build_sounds(scan); c = build_manifest()
    wjson(os.path.join(PACK, "pack.mcmeta"), {"pack": {"description": "AZRATHIEL assets - MERGE the assets/azrathiel folder into the DeS pack; keep the DeS pack's own pack.mcmeta", "pack_format": 46,
             "supported_formats": {"min_inclusive": 46, "max_inclusive": 99}}})
    print("blockbench projects: %d" % nbb); print("models: %d  textures: %d  sound events: %d (+%d voice files)  voice manifest lines: %d" % (len(MODELS) + 1, len(os.listdir(os.path.join(AS, "textures", "item"))), len(SFX), n, c))

if __name__ == "__main__": main()
