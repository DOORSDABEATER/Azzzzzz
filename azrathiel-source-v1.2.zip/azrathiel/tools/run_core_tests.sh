#!/usr/bin/env bash
# Compiles the dependency-free core package and runs the pure-logic tests. Needs only a JDK (java 21+).
set -e
cd "$(dirname "$0")/.."
JAVAC="javac"; command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
rm -rf build/core && mkdir -p build/core
$JAVAC -d build/core src/main/java/com/des/weapons/azrathiel/core/*.java tests/CoreTests.java
java -cp build/core CoreTests src/main/resources/azrathiel/voice/vaelzarion_voice.txt
