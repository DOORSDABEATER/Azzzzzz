#!/usr/bin/env python3
"""Poor-man's semantic check (no Paper jar available offline): finds capitalised type names that are used but neither imported,
declared, same-package, nor java.lang. Types resolved only through wildcard imports are listed for manual review."""
import os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "java")
JAVA_LANG = set("""String Math Object Integer Double Float Long Boolean Byte Character Short Number Exception RuntimeException IllegalArgumentException IllegalStateException Throwable Error Runnable
Iterable Comparable Override Deprecated SuppressWarnings FunctionalInterface System Thread StringBuilder Enum Record Void Class CharSequence NumberFormatException ArithmeticException
NullPointerException InterruptedException AutoCloseable NoSuchFieldError ClassCastException IndexOutOfBoundsException UnsupportedOperationException Process SafeVarargs Cloneable StackWalker""".split())
files = []
for dp, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(".java"): files.append(os.path.join(dp, f))
proj = {}   # simple name -> package
for p in files:
    s = open(p).read(); pk = re.search(r"^package ([\w.]+);", s, re.M).group(1)
    for n in re.findall(r"\b(?:class|interface|enum|record)\s+([A-Z]\w*)", s): proj.setdefault(n, set()).add(pk)
def strip(s):
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S); s = re.sub(r"//[^\n]*", " ", s); s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s); return re.sub(r"'(?:\\.|[^'\\])'", "''", s)
bad = 0; wild_report = {}
for p in sorted(files):
    raw = open(p).read(); s = strip(raw); pk = re.search(r"^package ([\w.]+);", raw, re.M).group(1)
    imports = {}; wild = []
    for m in re.finditer(r"^import (static )?([\w.]+?)(\.\*)?;", raw, re.M):
        if m.group(3): wild.append(m.group(2)) if not m.group(1) else None
        elif not m.group(1): imports[m.group(2).split(".")[-1]] = m.group(2)
    declared = set(re.findall(r"\b(?:class|interface|enum|record)\s+([A-Z]\w*)", s))
    tparams = set(re.findall(r"<\s*([A-Z])\s*(?:extends[^>]*)?>", s))
    used = set()
    for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\b", s):
        t = m.group(1)
        if t.isupper() or len(t) == 1: continue                       # constants / generic params
        used.add(t)
    for t in sorted(used):
        if t in imports or t in declared or t in JAVA_LANG or t in tparams: continue
        if t in proj and (pk in proj[t]): continue
        if any(t in proj and w in proj[t] for w in wild): continue
        if wild: wild_report.setdefault(os.path.relpath(p, ROOT), []).append(t); continue
        print("UNRESOLVED %s: %s" % (os.path.relpath(p, ROOT), t)); bad += 1
for f, ts in wild_report.items():
    print("REVIEW (resolved only if provided by a wildcard import) %s: %s" % (f, ", ".join(ts)))
print("import check: %d unresolved" % bad); sys.exit(1 if bad else 0)
