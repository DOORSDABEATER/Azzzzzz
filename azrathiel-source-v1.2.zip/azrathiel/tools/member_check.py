#!/usr/bin/env python3
"""Verifies that every member accessed through the well-known handles (v., mod., mod.fx., mod.tasks., b., ctx...) exists on the class it points to.
Complements stub_check.py, which cannot see errors hidden behind unresolved external-API expressions."""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "java"))
def strip(t): t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S); t = re.sub(r"//[^\n]*", " ", t); return re.sub(r'"(?:\\.|[^"\\])*"', '""', t)
files = {}
for dp, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(".java"): files[f[:-5]] = strip(open(os.path.join(dp, f)).read())
def members(cls):
    s = files[cls]; m = set()
    for x in re.finditer(r"(?:public|protected|private|static|final|abstract|synchronized|\s)+(?:<[^>]+>\s*)?[\w.<>\[\],? ]+?\s+(\w+)\s*\(", s): m.add(x.group(1))
    for x in re.finditer(r"(?:public|private|protected|static|final)[\w.<>\[\],? ]*\s+(\w+)\s*(?:=|;|,)", s): m.add(x.group(1))
    for x in re.finditer(r"\b(?:int|long|double|float|boolean|String|byte|char)\s+([\w, =.\"']+);", s):
        for n in re.findall(r"(\w+)\s*(?:=[^,;]*)?(?:,|$)", x.group(1)): m.add(n)
    for x in re.finditer(r"(?:public|private|protected)(?: static)?(?: final)? [\w.<>, ?\[\]]+? (\w+) = [^;]*?, (\w+) = ", s): m.update(x.groups())
    for x in re.finditer(r"\brecord\s+\w+\(([^)]*)\)", s):
        for part in x.group(1).split(","): 
            if part.strip(): m.add(part.strip().split()[-1])
    m |= set(re.findall(r"\b(\w+)\s*\(", re.search(r"\brecord\s+%s\b" % cls, s).group(0))) if re.search(r"\brecord\s+%s\b" % cls, s) else set()
    return m
# also treat constructor-assigned fields declared as multiple on one line
HANDLES = {  # regex of the receiver expression -> class
 r"\bmod\.fx": "Fx", r"\bmod\.tasks": "Tasks", r"\bmod\.executor": "AbilityExecutor", r"\bmod\.targeting": "Targeting", r"\bmod\.voice": "Voice", r"\bmod\.vaels": "VaelManager",
 r"\bmod\.actions": "Actions", r"\bmod\.store": "Store", r"\bmod\.adapt": "AdaptLog", r"\bmod\.weapon": "WeaponItem", r"\bmod\.prompts": "Prompts", r"\bmod\.cfg": "Settings", r"\bmod\.tracker": "EffectivenessTracker",
 r"\bc\.mod\.fx": "Fx", r"\bc\.mod\.tasks": "Tasks", r"\bc\.mod\.targeting": "Targeting", r"\bc\.mod\.adapt": "AdaptLog", r"\bc\.mod\.tracker": "EffectivenessTracker", r"\bc\.mod\.cfg": "Settings",
 r"\bv\.bond": "BondData", r"\bb": None, r"\bv": "Vael", r"\bmod": "AzrathielModule", r"\bv\.anim": "AnimationController", r"\bv\.essence": "Resource", r"\bv\.director": "DialogueDirector", r"\bv\.brain": "Brain",
}
order = sorted([k for k, v in HANDLES.items() if v], key=lambda k: -len(k)); bad = 0; checked = 0
cache = {c: members(c) for c in files}
for fn, s in files.items():
    for rx in order:
        cls = HANDLES[rx]
        for m in re.finditer(rx + r"\.(\w+)\b", s):
            # skip when the matched receiver is only a prefix of a longer handle (e.g. "mod" of "mod.fx")
            pre = s[max(0, m.start() - 1):m.start()]
            if pre and (pre.isalnum() or pre in "._"): continue
            tail = s[m.end(1):m.end(1) + 1]; name = m.group(1)
            longer = [k for k in order if len(k) > len(rx) and re.match(k + r"\.", s[m.start():m.start() + 40])]
            if longer: continue
            if cls in ("Vael", "BondData", "AnimationController", "Resource", "DialogueDirector", "Brain") and rx.startswith(r"\bv") and not re.search(r"\bVael v\b", s): continue   # 'v' means something else in this file
            checked += 1
            if name not in cache[cls] and name not in ("class",):
                if fn == cls: continue
                print("MISSING  %s: %s.%s  (not a member of %s)" % (fn, rx.replace("\\b", ""), name, cls)); bad += 1
print("member check: %d accesses verified, %d missing" % (checked, bad)); sys.exit(1 if bad else 0)
