# VFX system and "it does nothing" troubleshooting

## If an ability seems to deal no damage — do this first (2 minutes)
1. Look at the **action bar** after a left-click cast. Every manual cast now reports one of:
   `TITAN BREAKER - 3 hit(s), 42 damage` · `... nothing to hit. Aim at a mob ...` · `... damage was CANCELLED by another plugin/protection`.
2. Aim at a mob and run **`/azrathiel admin trace`**. It prints: whether the vessel/bond/guardian are recognised, the selected ability and its cooldown, the active rules, what your crosshair sees, and **every living entity within 12 blocks with the exact reason it is or is not targetable**.
3. Then run **`/azrathiel admin trace hit`**: it applies exactly 1 point of damage to your crosshair target through the real damage pipeline and tells you the result:
   * `dealt N` → damage works on your server; the earlier cast simply had no valid target.
   * `CANCELLED by another plugin/region protection` → our code worked and something else (claims, WorldGuard mob-damage/PvP flags, a combat plugin) vetoed the event. Test outside the protected region or allow the damage there.
   * `absorbed` → the target is invulnerable / has absorption.

### Why a cast could legitimately hit nothing (fixed or now explained)
* **Area hits and the AI only target hostile mobs** (zombies, skeletons, ...). Cows, pigs, armor stands, villagers, pets, NPCs and (by default) other players are never hit by area effects.
* **New:** whatever you deliberately **aim at** is a valid target for your manual casts (`combat.manual-aim-any-mob: true`), except pets, villagers, NPCs, invulnerable entities, and armor stands (`combat.hit-armor-stands: true` to allow). Players still follow `combat.pvp`.
* **Dormant form does not fight by default** (it watches and warns). **New:** it now releases itself as soon as a hostile is targeting you (`combat.auto-release-when-targeted`), or press **F** / `/azrathiel release`.
* Cooldown / essence: the action bar says so; `/azrathiel admin trace` shows the cooldown.

## VFX
Two layers, both purely cosmetic and guarded so a failure can never affect gameplay (the first 5 effect failures are **always** printed to the console, never silently swallowed):
* **Model effects** (`visual.vfx: MODELS`, default): textured quads on `item_display` entities — soft rings, magic circles, beams, crescent slashes, a void spiral, an eye, a crown, a soul wisp, hex shield panels, ground cracks, sparks, glows — recoloured per Eidolon and animated by client-side interpolation. They need the updated resource pack (`assets/azrathiel/models/fx/*`, `textures/item/fx_*.png`). **If you see purple/black cubes, the pack was not updated.**
* **Particles** (always on, `visual.particles`): the supporting dust/sparks/smoke.
* `visual.vfx: PARTICLES` = no custom models at all (use while the pack is not deployed). `OFF` = nothing but sound.
* **Damage numbers** (`visual.damage-numbers`): every hit shows its damage in the move's colour, red `BLOCKED` if another plugin cancelled it.
* Limits: 90 effect entities per cast, `visual.max-fx-displays: 300` alive at once; everything is removed within ~2 seconds and purged on startup/shutdown (`/azrathiel admin cleanup`).

### What each move looks like
| Move | Choreography |
|---|---|
| Titan Breaker | ground sigil → a pillar of light drops in → ground cracks → three shockwave rings + flare + sparks |
| Void Consumption | spinning void disc + dark orb, inward-collapsing rings each pull |
| Inevitable Future | an eye opens over each mark, a thread of light ties it, then a white pillar + flare + ring at the verdict |
| Decaying Judgement | rotting sigil + cracks, red burst and ring on every decay tick |
| Absolute Bastion | ground seal + eight hex wall panels that refresh while the barrier lasts; ripple where a projectile is stopped |
| Adaptive Response | green analysis ring + three orbiting glyphs |
| Spectral Execution | crescent trail along the dash, cold beam, souls rise from the struck |
| Sovereign Decree | gold seal, crowns descend on subjects with light columns |
| Convergences | every participating Eidolon adds a ring in its own colour; named combinations add their own flourish |
| EIGHTFOLD APOCALYPSE | huge rune + eight Eidolon-coloured pillars; eight module bursts; pulsing domination rings; eight beams striking enemies; final multi-ring shockwave with a blinding flare |
| LAST GUARDIAN | blue seal + wall + beam of light that pulses; final shockwave rings |
| Basic strike / intercept / summon / transform | slash + flares / ripple / rune rising / ring cascade |

### Preview without damage
`/azrathiel admin vfxtest <name>` plays any effect at your crosshair (`all`, `ring`, `rune`, `void`, `crack`, `beam`, `pillar`, `flare`, `glow`, `slash`, `eye`, `crown`, `soul`, `dome`, `vigor` ... `dominion`, `convergence`, `ultimate`, `guardian`).

## Honest status
The textures were rendered and inspected; the Java and the geometry pass every offline check. **Nothing here has been seen in a Minecraft client**, so timing, sizes and brightness will need tuning on your server (all sizes/durations are plain numbers in `combat/Choreo.java`). Translucent quads on `item_display` are a standard technique but I could not confirm the exact blending on your client version.
