package com.des.weapons.azrathiel.core;

/** Pure threat scoring. Higher = deal with first. */
public final class ThreatModel {
    private ThreatModel() {}

    public record Threat(double distToMaster, double distToVael, double healthFrac, double maxHealth, boolean targetsMaster,
                         boolean boss, boolean ranged, boolean flying, double damageToMaster, boolean recentAttacker, boolean player) {}

    public static double score(Threat t, Form form) {
        double s = 100.0 / (1.0 + t.distToMaster() / 4.0);
        if (t.targetsMaster()) s += 60;
        if (t.recentAttacker()) s += 35;
        s += Math.min(60, t.damageToMaster() * 8);
        if (t.boss()) s += 80;
        if (t.ranged()) s += 20;
        if (t.flying()) s += 8;
        if (t.maxHealth() >= 100) s += 10;
        if (t.healthFrac() < 0.25) s += 10;                          // finishing blows are cheap
        if (t.player()) s += 15;
        s -= Math.min(15, t.distToVael() / 3.0);
        if (form == Form.DORMANT) s *= 0.8;
        return s;
    }

    /** Danger level 0..1 for the master from the combined enemy picture. */
    public static double danger(double masterHpFrac, int enemiesNear, boolean bossNear, double dmgRecent) {
        double d = (1 - masterHpFrac) * 0.5 + Math.min(1, enemiesNear / 6.0) * 0.25 + (bossNear ? 0.15 : 0) + Math.min(0.1, dmgRecent / 40.0);
        return Math.max(0, Math.min(1, d));
    }
}
