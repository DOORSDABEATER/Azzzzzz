package com.des.weapons.azrathiel.core;

import java.util.List;
import java.util.Optional;
import java.util.random.RandomGenerator;

/** Chooses which Eidolon ability or Convergence VAELZARION should use right now. Pure scoring. */
public final class AbilityChooser {
    private AbilityChooser() {}

    public record Cand(String key, Convergence.Spec spec, boolean ready) {}
    public record Situation(int enemies, boolean boss, boolean ranged, boolean flying, double masterHp, boolean threatened,
                            double nearest, boolean surrounded, double avgHealthFrac, String targetType) {}

    static double affinity(Eidolon e, Situation s) {
        return switch (e) {
            case VIGOR -> (s.nearest() <= 7 ? 14 : 2) + (s.enemies() <= 3 ? 4 : 0) - (s.flying() ? 10 : 0);
            case ABYSS -> Math.min(s.enemies(), 6) * 4 + (s.nearest() < 10 ? 4 : 0);
            case FATE -> (s.ranged() || s.flying() ? 16 : (s.nearest() > 8 ? 10 : 3)) + (s.boss() ? 3 : 0);
            case RUIN -> (s.boss() ? 18 : 6) + (s.avgHealthFrac() > 0.6 ? 6 : 0);
            case AEGIS -> s.masterHp() < 0.45 ? 40 : s.surrounded() ? 24 : (s.threatened() && s.enemies() >= 3) ? 14 : -20;
            case EVOLUTION -> 8;
            case WRAITH -> (s.avgHealthFrac() < 0.5 ? 16 : 6) + (s.nearest() > 6 ? 4 : 0);
            case DOMINION -> s.enemies() >= 4 ? 18 : s.boss() ? 12 : 4;
        };
    }

    public static double score(Cand c, Situation s, EffectivenessTracker tr, RandomGenerator rng) {
        double sc = 0;
        for (Eidolon e : c.spec().order()) sc += affinity(e, s);
        sc += Math.min(25, c.spec().damage() * 0.25);
        if (c.spec().order().size() > 1) sc += (s.enemies() >= 4 || s.boss()) ? 8 : -6;
        sc *= tr.factor(c.key(), s.targetType());
        return sc + rng.nextDouble() * 3;
    }

    public static Optional<Cand> choose(List<Cand> cands, Situation s, EffectivenessTracker tr, RandomGenerator rng, double minScore) {
        Cand best = null; double bs = minScore;
        for (Cand c : cands) {
            if (!c.ready()) continue;
            double sc = score(c, s, tr, rng);
            if (sc > bs) { bs = sc; best = c; }
        }
        return Optional.ofNullable(best);
    }
}
