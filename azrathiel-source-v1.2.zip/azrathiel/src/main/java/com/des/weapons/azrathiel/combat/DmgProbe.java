package com.des.weapons.azrathiel.combat;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/** Watches the damage events WE trigger, at MONITOR priority, so a cancellation by another plugin (claims, region flags, PvP plugins) is detected instead of silently swallowed. */
public final class DmgProbe implements Listener {
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
    public void onDamage(EntityDamageEvent e) {
        if (Dmg.probeTarget != null && Dmg.probeTarget.equals(e.getEntity().getUniqueId())) { Dmg.probeSeen = true; Dmg.probeCancelled = e.isCancelled(); }
    }
}
