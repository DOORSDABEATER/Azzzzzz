package com.des.weapons.azrathiel.core;

/** Smoothing maths used for natural floating: critically damped springs instead of teleport snapping. */
public final class Kinematics {
    private Kinematics() {}

    /** Critically-damped smooth follow (SmoothDamp). vel is a 1-element in/out array. Never overshoots the target. */
    public static double smoothDamp(double cur, double target, double[] vel, double smoothTime, double maxSpeed, double dt) {
        smoothTime = Math.max(0.0001, smoothTime);
        double omega = 2.0 / smoothTime, x = omega * dt;
        double exp = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x);
        double change = cur - target, orig = target, maxChange = maxSpeed * smoothTime;
        change = Math.max(-maxChange, Math.min(maxChange, change));
        target = cur - change;
        double temp = (vel[0] + omega * change) * dt;
        vel[0] = (vel[0] - omega * temp) * exp;
        double out = target + (change + temp) * exp;
        if ((orig - cur > 0) == (out > orig)) { out = orig; vel[0] = dt > 0 ? (out - orig) / dt : 0; }
        return out;
    }

    public static float wrap180(float deg) { deg %= 360f; if (deg >= 180f) deg -= 360f; if (deg < -180f) deg += 360f; return deg; }

    /** Move an angle toward a target along the shortest arc with exponential easing and a turn-rate cap (deg/s). */
    public static float approachAngle(float cur, float target, float easeRate, float maxDegPerSec, float dt) {
        float diff = wrap180(target - cur);
        float step = diff * (1f - (float) Math.exp(-easeRate * dt));
        float cap = maxDegPerSec * dt;
        step = Math.max(-cap, Math.min(cap, step));
        return wrap180(cur + step);
    }
}
