package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Convergence;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** State of one ability execution. The dedupe set guarantees one hit per (stage, target) even if callbacks or hitboxes overlap. */
public final class CastCtx {
    private static long counter;
    public final long id = ++counter; public final AzrathielModule mod; public final Player master; public final Convergence.Spec spec;
    public final boolean cosmetics; public Location origin, focus; public final Set<String> dedupe = ConcurrentHashMap.newKeySet();
    public double totalDamage; public int hits, cancelled; public LivingEntity primary; public int rgb = 0xFFC83D; public boolean feedback; public final List<LivingEntity> killed = new ArrayList<>();
    public com.des.weapons.azrathiel.entity.Vael vael;   // may be null (admin tests, LAST GUARDIAN after rig loss)

    public CastCtx(AzrathielModule mod, Player master, Convergence.Spec spec, boolean cosmetics, Location origin, Location focus) {
        this.mod = mod; this.master = master; this.spec = spec; this.cosmetics = cosmetics; this.origin = origin; this.focus = focus;
    }
    public CastCtx derive(Convergence.Spec s) { CastCtx c = new CastCtx(mod, master, s, cosmetics, origin, focus); c.vael = vael; c.primary = primary; c.rgb = rgb; return c; }
}
