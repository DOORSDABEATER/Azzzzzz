package com.des.weapons.azrathiel.item;

import com.des.weapons.azrathiel.data.Settings;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** The AZRATHIEL binding vessel. Secret rarity. Identified by persistent data, never by name. */
public final class WeaponItem {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final Plugin plugin; private final Settings cfg;
    public final NamespacedKey KEY_WEAPON, KEY_BOND, KEY_RARITY, MODEL;

    public WeaponItem(Plugin plugin, Settings cfg) {
        this.plugin = plugin; this.cfg = cfg;
        KEY_WEAPON = new NamespacedKey(plugin, "azrathiel_weapon"); KEY_BOND = new NamespacedKey(plugin, "azrathiel_bond"); KEY_RARITY = new NamespacedKey(plugin, "rarity");
        MODEL = NamespacedKey.fromString("azrathiel:weapon");
    }

    /** bondId may be null: an unbound vessel binds to the first player who awakens it. */
    public ItemStack create(UUID bondId) {
        Material m = Material.matchMaterial(cfg.weaponMaterial); if (m == null || !m.isItem()) m = Material.NETHERITE_SWORD;
        ItemStack it = new ItemStack(m); ItemMeta meta = it.getItemMeta();
        meta.displayName(MM.deserialize("<!italic><gradient:#7a1bff:#ffc83d><bold>AZRATHIEL</bold></gradient> <dark_gray>-</dark_gray> <gray>The Eightfold Sovereign"));
        List<Component> lore = new ArrayList<>();
        for (String s : List.of("<!italic><gradient:#ff6a1f:#ffc83d><bold>SECRET</bold></gradient> <dark_gray>weapon", "",
                "<!italic><gray>The binding vessel of <white>VAELZARION</white>, an ancient guardian", "<!italic><gray>who answers to exactly one master.", "",
                "<!italic><gold>Right-click</gold> <gray>summon / dismiss", "<!italic><gold>Shift + Right-click</gold> <gray>control panel",
                "<!italic><gold>Left-click</gold> <gray>command selected ability", "<!italic><gold>Shift + Left-click</gold> <gray>next ability",
                "<!italic><gold>Swap-hand (F)</gold> <gray>release / dormant", "<!italic><gold>Shift + F</gold> <gray>EIGHTFOLD APOCALYPSE", "",
                bondId == null ? "<!italic><dark_gray>Unbound - awaken it to claim it" : "<!italic><dark_gray>Bound")) lore.add(MM.deserialize(s));
        meta.lore(lore);
        meta.setUnbreakable(true); meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        try { if (MODEL != null) meta.setItemModel(MODEL); } catch (Throwable ignored) { }
        try {
            meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(new NamespacedKey(plugin, "azr_damage"), cfg.weaponDamage - 1.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
            meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(new NamespacedKey(plugin, "azr_speed"), cfg.weaponSpeed - 4.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        } catch (Throwable t) { plugin.getLogger().warning("Could not apply weapon attributes: " + t); }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(KEY_WEAPON, PersistentDataType.BYTE, (byte) 1); pdc.set(KEY_RARITY, PersistentDataType.STRING, "SECRET");
        if (bondId != null) pdc.set(KEY_BOND, PersistentDataType.STRING, bondId.toString());
        it.setItemMeta(meta); return it;
    }

    public boolean is(ItemStack it) { return it != null && it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(KEY_WEAPON, PersistentDataType.BYTE); }

    public UUID bondOf(ItemStack it) {
        if (!is(it)) return null; String s = it.getItemMeta().getPersistentDataContainer().get(KEY_BOND, PersistentDataType.STRING);
        try { return s == null ? null : UUID.fromString(s); } catch (IllegalArgumentException e) { return null; }
    }

    public void bind(ItemStack it, UUID bondId) {
        ItemMeta meta = it.getItemMeta(); meta.getPersistentDataContainer().set(KEY_BOND, PersistentDataType.STRING, bondId.toString());
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        if (!lore.isEmpty()) lore.set(lore.size() - 1, MM.deserialize("<!italic><dark_gray>Bound")); meta.lore(lore); it.setItemMeta(meta);
    }
}
