package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import org.bukkit.Location;

/** Public entry points into the package-private choreography for code outside the combat package (entity.Vael). */
public final class ChoreoBridge {
    public static final java.util.List<String> DEMOS = java.util.List.of("all", "ring", "rune", "void", "crack", "beam", "pillar", "flare", "glow", "slash", "eye", "crown", "soul", "dome",
            "vigor", "abyss", "fate", "ruin", "aegis", "evolution", "wraith", "dominion", "convergence", "ultimate", "guardian");

    /** Plays one effect (or all of them in sequence) at the spot the player is looking at, with NO damage. Returns an error text or null. */
    public static String demo(AzrathielModule mod, org.bukkit.entity.Player p, String name) {
        org.bukkit.block.Block b = p.getTargetBlockExact(30);
        Location f = b != null ? b.getLocation().add(0.5, 1, 0.5) : p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(7));
        if (name.equals("all")) { int i = 0; for (String n : DEMOS) if (!n.equals("all") && !n.equals("ultimate")) { final String nn = n; mod.tasks.later(i++ * 30L, () -> demo(mod, p, nn)); } return null; }
        if (!DEMOS.contains(name)) return "unknown effect; options: " + DEMOS;
        mod.fx.begin(); Vfx v = mod.vfx; CastCtx c = new CastCtx(mod, p, com.des.weapons.azrathiel.core.Convergence.build(0xFF, null, mod.balance()), true, p.getLocation(), f);
        Location up = f.clone().add(0, 1.2, 0); java.util.List<org.bukkit.entity.LivingEntity> none = java.util.List.of();
        switch (name) {
            case "ring" -> v.ring(f, 0xFFC83D, 0.5f, 4f, 20, 0, 0.1f);
            case "rune" -> v.flat(f, "rune", 0xFFC83D, 0.5f, 4f, 6, 60, 180, 0.05f, 0);
            case "void" -> v.flat(f, "void", 0xA874FF, 0.5f, 4f, 6, 60, 240, 0.05f, 0);
            case "crack" -> v.flat(f, "crack", 0xFFB070, 0.5f, 4f, 2, 50, 0, 0.04f, 0);
            case "beam" -> v.beam(p.getEyeLocation().add(0, -0.4, 0), up, 0x7FDBFF, 0.4f, 30, 0);
            case "pillar" -> v.pillar(f, 0xFFD9A0, 10f, 2f, 30, 0, 8f);
            case "flare" -> v.flare(up, 0xFFFFFF, 3f, 20, 0);
            case "glow" -> v.glow(up, 0xFFC83D, 0.5f, 4f, 24, 0);
            case "slash" -> v.slash(up, 0xFFFFFF, 3f, -25f, 16, 0);
            case "eye" -> v.sprite(up, "eye", 0x7FDBFF, 2f, 40, 0, 20f);
            case "crown" -> v.sprite(up, "crown", 0xFFC83D, 2f, 40, 0, 0f);
            case "soul" -> v.sprite(up, "soul", 0xC9F4F0, 2f, 40, 0, 30f);
            case "dome" -> v.domeWall(f, 0x2E6FFF, 4f, 3.5f, 50, 0);
            case "vigor" -> Choreo.vigor(c, f, 5);
            case "abyss" -> { Choreo.abyss(c, f, 7, 0); mod.tasks.later(20, () -> Choreo.abyss(c, f, 7, 1)); }
            case "fate" -> { Choreo.fateMark(c, p.getEyeLocation().add(0, -0.4, 0), p); mod.tasks.later(15, () -> Choreo.fateStrike(c, p)); }
            case "ruin" -> { Choreo.ruin(c, f, 6); mod.tasks.later(10, () -> Choreo.ruinPulse(c, f, 6)); }
            case "aegis" -> { Choreo.aegis(c, f, 6, true); mod.tasks.later(20, () -> { mod.fx.begin(); Choreo.aegis(c, f, 6, false); }); }
            case "evolution" -> Choreo.evolution(c, f, 9);
            case "wraith" -> Choreo.wraith(c, p.getEyeLocation().add(0, -0.4, 0), f.clone().add(p.getLocation().getDirection().multiply(8)), none);
            case "dominion" -> Choreo.dominion(c, f, 10, none);
            case "convergence" -> Choreo.convergence(c, f, 6);
            case "ultimate" -> { Choreo.ultAwaken(c, f); mod.tasks.later(30, () -> { mod.fx.begin(); Choreo.ultDomination(c, f, 20); }); mod.tasks.later(60, () -> { mod.fx.begin(); Choreo.ultMain(c, f.clone().add(0, 4, 0), none, f); }); mod.tasks.later(90, () -> { mod.fx.begin(); Choreo.ultImpact(c, f, 24); }); }
            case "guardian" -> { Choreo.guardSeal(mod, f, 10); mod.tasks.later(40, () -> Choreo.guardPulse(mod, f, 10)); }
            default -> { }
        }
        return null;
    }

    private ChoreoBridge() {}
    public static void summon(AzrathielModule mod, Location l, int rgb) { Choreo.summon(mod, l, rgb); }
    public static void transform(AzrathielModule mod, Location l, int rgb, boolean big) { Choreo.transform(mod, l, rgb, big); }
}
