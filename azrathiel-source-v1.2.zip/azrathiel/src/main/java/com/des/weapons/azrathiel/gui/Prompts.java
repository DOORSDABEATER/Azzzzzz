package com.des.weapons.azrathiel.gui;

import com.des.weapons.azrathiel.AzrathielModule;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** One-shot chat input ("type a name in chat"). Cancels the chat message and runs the callback on the main thread. */
public final class Prompts implements Listener {
    private final AzrathielModule mod; private final Map<UUID, Consumer<String>> waiting = new HashMap<>();
    public Prompts(AzrathielModule mod) { this.mod = mod; }

    public void ask(Player p, String question, Consumer<String> cb) {
        p.closeInventory(); waiting.put(p.getUniqueId(), cb);
        p.sendMessage(mod.msg("<gold>" + question + " <gray>(type in chat, or <white>cancel</white>)"));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Consumer<String> cb = waiting.remove(e.getPlayer().getUniqueId()); if (cb == null) return;
        e.setCancelled(true); String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim(); Player p = e.getPlayer();
        mod.plugin.getServer().getScheduler().runTask(mod.plugin, () -> { if (text.equalsIgnoreCase("cancel")) p.sendMessage(mod.msg("<gray>Cancelled.")); else { try { cb.accept(text); } catch (Throwable t) { p.sendMessage(mod.msg("<red>Invalid input: " + t.getMessage())); } } });
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { waiting.remove(e.getPlayer().getUniqueId()); }
}
