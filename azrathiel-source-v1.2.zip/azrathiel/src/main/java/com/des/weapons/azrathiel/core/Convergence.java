package com.des.weapons.azrathiel.core;

import java.util.*;

/**
 * Modular Convergence engine. 255 = every non-empty subset of eight Eidolons. Nothing here is hardcoded per combination:
 * a Spec is COMPUTED from per-Eidolon profiles + a synergy rule, then optionally flavoured by a handcrafted script
 * (see combat.ComboScripts) keyed by the same mask.
 */
public final class Convergence {
    private Convergence() {}

    public enum Mode { SINGLE, SIMULTANEOUS, SEQUENTIAL, LAYERED }
    /** Potion-style effect by registry key ("slowness"), duration ticks, amplifier. */
    public record Eff(String type, int ticks, int amp) {}
    public record Profile(double damage, double radius, double range, int cost, int cooldown, double knockback,
                          List<Eff> enemy, List<Eff> self) {}
    public record Balance(double damageMul, double cooldownMul, double costMul, Map<Eidolon, Double> perEidolon) {
        public static final Balance DEFAULT = new Balance(1, 1, 1, new EnumMap<>(Eidolon.class));
        public double dmg(Eidolon e) { return damageMul * perEidolon.getOrDefault(e, 1.0); }
    }
    public record Spec(int mask, String name, List<Eidolon> order, Mode mode, Map<Eidolon, Double> stageDamage, double damage,
                       double radius, double range, int cooldownTicks, int cost, double knockback, int stageDelay,
                       List<Eff> enemy, List<Eff> self, boolean handcrafted) {
        public String key() { return "C:" + mask; }
        public boolean has(Eidolon e) { return (mask & e.bit()) != 0; }
    }

    public static final Map<Eidolon, Profile> PROFILES = new EnumMap<>(Eidolon.class);
    private static final Map<Integer, String> HANDCRAFTED = new LinkedHashMap<>();
    private static final Map<Integer, Mode> HC_MODE = new HashMap<>();

    private static Eff e(String t, int ticks, int amp) { return new Eff(t, ticks, amp); }

    static {
        PROFILES.put(Eidolon.VIGOR, new Profile(14, 5.0, 6, 80, 140, 1.4, List.of(e("slowness", 40, 1)), List.of()));
        PROFILES.put(Eidolon.ABYSS, new Profile(10, 7.0, 10, 90, 180, 1.2, List.of(e("blindness", 60, 0)), List.of()));
        PROFILES.put(Eidolon.FATE, new Profile(12, 16.0, 20, 85, 160, 0.3, List.of(e("glowing", 120, 0)), List.of()));
        PROFILES.put(Eidolon.RUIN, new Profile(11, 6.0, 8, 90, 170, 0.4, List.of(e("wither", 100, 1), e("weakness", 100, 0)), List.of()));
        PROFILES.put(Eidolon.AEGIS, new Profile(4, 6.0, 0, 100, 300, 1.0, List.of(), List.of(e("resistance", 160, 1), e("absorption", 200, 2))));
        PROFILES.put(Eidolon.EVOLUTION, new Profile(9, 9.0, 12, 70, 120, 0.3, List.of(e("slowness", 40, 0)), List.of(e("speed", 100, 0))));
        PROFILES.put(Eidolon.WRAITH, new Profile(13, 3.0, 14, 85, 160, 0.2, List.of(e("slowness", 20, 1)), List.of()));
        PROFILES.put(Eidolon.DOMINION, new Profile(6, 10.0, 12, 95, 240, 0.8, List.of(e("slowness", 80, 3), e("weakness", 80, 1)), List.of()));

        hc("GRAVITY EXECUTION", Mode.SEQUENTIAL, Eidolon.VIGOR, Eidolon.ABYSS);
        hc("INEVITABLE IMPACT", Mode.LAYERED, Eidolon.VIGOR, Eidolon.FATE);
        hc("NULL BARRIER", Mode.SIMULTANEOUS, Eidolon.ABYSS, Eidolon.AEGIS);
        hc("ENDLESS DECAY", Mode.LAYERED, Eidolon.RUIN, Eidolon.EVOLUTION);
        hc("SOUL PROPHECY", Mode.SEQUENTIAL, Eidolon.FATE, Eidolon.WRAITH);
        hc("IMPERIAL SANCTUARY", Mode.SIMULTANEOUS, Eidolon.AEGIS, Eidolon.DOMINION);
        hc("WORLD DEVOURER", Mode.SEQUENTIAL, Eidolon.VIGOR, Eidolon.RUIN, Eidolon.ABYSS);
        hc("FUTURE//REWRITE", Mode.LAYERED, Eidolon.FATE, Eidolon.EVOLUTION, Eidolon.WRAITH);
        hc("UNBREAKABLE SOVEREIGN", Mode.SIMULTANEOUS, Eidolon.AEGIS, Eidolon.EVOLUTION, Eidolon.DOMINION);
        hc("KINGDOM OF ASH", Mode.LAYERED, Eidolon.RUIN, Eidolon.DOMINION);
    }

    private static void hc(String name, Mode m, Eidolon... es) { int k = mask(es); HANDCRAFTED.put(k, name); HC_MODE.put(k, m); }

    public static int mask(Eidolon... es) { int m = 0; for (Eidolon x : es) m |= x.bit(); return m; }
    public static int mask(Collection<Eidolon> es) { int m = 0; for (Eidolon x : es) m |= x.bit(); return m; }
    public static List<Eidolon> fromMask(int mask) {
        List<Eidolon> l = new ArrayList<>(); for (Eidolon e : Eidolon.values()) if ((mask & e.bit()) != 0) l.add(e); return l;
    }
    public static List<Integer> allMasks() { List<Integer> l = new ArrayList<>(); for (int i = 1; i <= Eidolon.FULL_MASK; i++) l.add(i); return l; }
    public static Map<Integer, String> handcrafted() { return Collections.unmodifiableMap(HANDCRAFTED); }
    public static boolean isHandcrafted(int mask) { return HANDCRAFTED.containsKey(mask); }

    /** Display name for any of the 255 masks. Handcrafted names win; everything else is generated deterministically and uniquely. */
    public static String nameOf(int mask) {
        String h = HANDCRAFTED.get(mask); if (h != null) return h;
        List<Eidolon> l = fromMask(mask); int k = l.size();
        if (k == 1) return l.get(0).signatureUpper();
        if (k == 8) return "EIGHTFOLD CONVERGENCE";
        if (k <= 4) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < k - 1; i++) sb.append(l.get(i).adjective).append(' ');
            return sb.append(l.get(k - 1).noun).toString().toUpperCase(Locale.ROOT);
        }
        StringBuilder sb = new StringBuilder("CHORD OF " + k + ":");
        for (Eidolon e : l) sb.append(' ').append(e.code);
        return sb.toString();
    }

    public static Spec build(int mask, List<Eidolon> order, Balance bal) {
        if (mask < 1 || mask > Eidolon.FULL_MASK) throw new IllegalArgumentException("mask out of range: " + mask);
        List<Eidolon> ord = new ArrayList<>();
        if (order != null) for (Eidolon e : order) if ((mask & e.bit()) != 0 && !ord.contains(e)) ord.add(e);
        for (Eidolon e : fromMask(mask)) if (!ord.contains(e)) ord.add(e);          // anything missing keeps natural order
        int k = ord.size();
        double synergy = k == 1 ? 1.0 : 0.75 + 0.05 * k;
        Map<Eidolon, Double> stage = new EnumMap<>(Eidolon.class);
        double dmg = 0, radius = 0, range = 0, kb = 0, costSum = 0; int cd = 0;
        Map<String, Eff> enemy = new LinkedHashMap<>(), self = new LinkedHashMap<>();
        for (Eidolon e : ord) {
            Profile p = PROFILES.get(e);
            double d = p.damage() * synergy * bal.dmg(e); stage.put(e, d); dmg += d;
            radius = Math.max(radius, p.radius()); range = Math.max(range, p.range()); kb = Math.max(kb, p.knockback());
            cd = Math.max(cd, p.cooldown()); costSum += p.cost();
            for (Eff f : p.enemy()) enemy.merge(f.type(), f, (a, b) -> new Eff(a.type(), Math.max(a.ticks(), b.ticks()), Math.max(a.amp(), b.amp())));
            for (Eff f : p.self()) self.merge(f.type(), f, (a, b) -> new Eff(a.type(), Math.max(a.ticks(), b.ticks()), Math.max(a.amp(), b.amp())));
        }
        Mode mode = k == 1 ? Mode.SINGLE : HC_MODE.getOrDefault(mask, k == 2 ? Mode.SIMULTANEOUS : Mode.SEQUENTIAL);
        int stageDelay = switch (mode) { case SINGLE, SIMULTANEOUS -> 0; case LAYERED -> 8; case SEQUENTIAL -> 6; };
        int cooldown = (int) Math.round((cd + 20.0 * (k - 1)) * bal.cooldownMul());
        int cost = (int) Math.round(costSum * (k == 1 ? 1.0 : 0.8) * bal.costMul());
        return new Spec(mask, nameOf(mask), List.copyOf(ord), mode, stage, dmg, radius + 0.5 * (k - 1), range, Math.max(10, cooldown),
                Math.max(1, cost), kb, stageDelay, List.copyOf(enemy.values()), List.copyOf(self.values()), HANDCRAFTED.containsKey(mask));
    }
}
