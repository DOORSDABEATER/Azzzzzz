package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Validates and runs an ability or Convergence. Order of operations is deliberate:
 * validate -> pay -> start cooldown -> DAMAGE STAGES (scheduled by the server, never by animation) -> cosmetics/voice (guarded).
 */
public final class AbilityExecutor {
    public record Result(boolean ok, String reason, double damage, int hits, int kills, String name) {
        static Result fail(String why) { return new Result(false, why, 0, 0, 0, ""); }
    }
    public static final class Opts {
        public boolean cosmetics = true, free, bypassCooldown, silent, feedback; public Resource payer; public Location origin;
        public List<LivingEntity> targets; public Consumer<Result> done;
    }

    private final AzrathielModule mod;
    public AbilityExecutor(AzrathielModule mod) { this.mod = mod; }

    public Convergence.Spec specFor(BondData b, String key) {
        try {
            if (key.startsWith("C:")) return Convergence.build(Integer.parseInt(key.substring(2)), null, mod.balance());
            if (key.startsWith("X:")) { BondData.Custom cu = b.custom(key.substring(2)); if (cu != null) return Convergence.build(Convergence.mask(cu.order()), cu.order(), mod.balance()); }
        } catch (Exception ignored) { }
        return null;
    }

    public boolean usable(BondData b, Convergence.Spec s) { for (Eidolon e : s.order()) if (!mod.unlocked(b, e)) return false; return true; }
    public long cooldownLeftMs(BondData b, String key) { return Math.max(0, b.cooldownReadyAt.getOrDefault(key, 0L) - System.currentTimeMillis()); }

    public List<AbilityChooser.Cand> candidates(Vael v) {
        List<AbilityChooser.Cand> out = new ArrayList<>();
        for (String key : v.bond.loadout()) {
            Convergence.Spec s = specFor(v.bond, key); if (s == null || !usable(v.bond, s)) continue;
            boolean allowed = true; for (Eidolon e : s.order()) if (!v.bond.enabled.contains(e)) allowed = false;
            out.add(new AbilityChooser.Cand(key, s, allowed && cooldownLeftMs(v.bond, key) == 0 && v.essence.has(s.cost())));
        }
        return out;
    }

    public Result cast(Vael v, String key, Opts o) {
        Convergence.Spec spec = specFor(v.bond, key);
        if (spec == null) return Result.fail("unknown ability " + key);
        return cast(v, key, spec, o);
    }

    public Result cast(Vael v, String key, Convergence.Spec spec, Opts o) {
        Player master = v.master();
        if (master == null || !master.isOnline()) return Result.fail("master offline");
        if (master.isDead() && o.origin == null) return Result.fail("master is dead");
        if (!usable(v.bond, spec)) return Result.fail("locked Eidolon");
        if (!o.bypassCooldown && cooldownLeftMs(v.bond, key) > 0) return Result.fail("cooldown " + cooldownLeftMs(v.bond, key) / 1000 + "s");
        Resource payer = o.payer != null ? o.payer : v.essence; int cost = spec.cost();
        if (!o.free && !payer.has(cost)) return Result.fail("not enough essence (" + (int) payer.cur + "/" + cost + ")");

        Location origin = o.origin != null ? o.origin : master.getLocation();
        LivingEntity primary = (o.targets != null && !o.targets.isEmpty()) ? o.targets.get(0) : mod.targeting.aimed(master, Math.max(8, spec.range()));   // crosshair target
        Location focus = resolveFocus(master, origin, spec, o, primary);
        CastCtx ctx = new CastCtx(mod, master, spec, o.cosmetics, origin, focus); ctx.vael = v; ctx.primary = primary; ctx.feedback = o.feedback;
        ctx.rgb = spec.order().get(0).rgb;
        if (!o.free) payer.consume(cost);
        if (!o.bypassCooldown) { v.bond.cooldownReadyAt.put(key, System.currentTimeMillis() + spec.cooldownTicks() * 50L); v.bond.touch(); }

        mod.fx.begin();
        if (!o.silent) mod.fx.safe(() -> { v.onCast(spec, focus); });                              // animation + voice: guarded, optional
        List<Eidolon> order = spec.order(); int lastDelay = 0;
        for (int i = 0; i < order.size(); i++) {
            final int idx = i; final Eidolon e = order.get(i); int delay = spec.stageDelay() * i; lastDelay = delay;
            mod.tasks.later(delay, () -> { try { Modules.apply(ctx, e, idx); } catch (Throwable t) { mod.plugin.getLogger().warning("Eidolon " + e + " stage failed: " + t); } });
        }
        if (o.feedback) mod.tasks.later(Math.max(lastDelay + 1L, 24L), () -> summary(master, spec, ctx));
        mod.tasks.later(lastDelay + 1L, () -> {
            if (spec.handcrafted()) { try { ComboScripts.finale(ctx); } catch (Throwable t) { mod.plugin.getLogger().warning("Combo finale '" + spec.name() + "' failed: " + t); } }
            mod.onCastFinished(v, ctx);
            if (o.done != null) o.done.accept(new Result(true, "", ctx.totalDamage, ctx.hits, ctx.killed.size(), spec.name()));
        });
        return new Result(true, "", 0, 0, 0, spec.name());
    }

    /** What the master sees after a manual cast: proof of damage, or the exact reason there was none. */
    private void summary(Player master, Convergence.Spec spec, CastCtx ctx) {
        if (!master.isOnline()) return; String n = spec.name();
        if (ctx.hits > 0) master.sendActionBar(mod.msg("<gold>" + n + " <gray>- <white>" + ctx.hits + " hit(s), " + (int) ctx.totalDamage + " damage" + (ctx.cancelled > 0 ? " <red>(" + ctx.cancelled + " blocked)" : "")));
        else if (ctx.cancelled > 0) master.sendActionBar(mod.msg("<red>" + n + ": damage was CANCELLED by another plugin/protection (" + ctx.cancelled + "). Try /azrathiel admin trace hit"));
        else if (spec.order().size() == 1 && spec.has(Eidolon.AEGIS)) master.sendActionBar(mod.msg("<aqua>" + n + " <gray>- barrier raised"));
        else master.sendActionBar(mod.msg("<yellow>" + n + ": nothing to hit. Aim at a mob (or stand near hostiles). /azrathiel admin trace explains why."));
    }

    private Location resolveFocus(Player master, Location origin, Convergence.Spec spec, Opts o, LivingEntity primary) {
        boolean defensive = spec.order().size() == 1 && spec.has(Eidolon.AEGIS);
        if (defensive) return origin.clone();
        LivingEntity t = primary;
        if (t == null && !master.isDead()) t = mod.targeting.nearestInCone(master, master.getEyeLocation(), master.getEyeLocation().getDirection(), Math.max(6, spec.range()), 0.4);
        if (t == null) { List<LivingEntity> near = mod.targeting.around(master, origin, Math.max(6, spec.range())); if (!near.isEmpty()) t = near.get(0); }
        if (t != null) return t.getLocation();
        Vector dir = master.isDead() ? new Vector(0, 0, 1) : master.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 1e-4) dir = new Vector(0, 0, 1);
        return origin.clone().add(dir.normalize().multiply(Math.min(spec.range(), 5)));
    }
}
