package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Category;
import com.des.weapons.azrathiel.core.Convergence;
import com.des.weapons.azrathiel.core.Eidolon;
import com.des.weapons.azrathiel.core.Resource;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * LAST GUARDIAN: master died while VAELZARION was Released. Defends the death location inside a fixed radius using a FINITE energy pool,
 * then fires a final shockwave (reserved energy) and becomes exhausted. Never resurrects, never invulnerable, never chases, has a cooldown.
 */
public final class LastGuardian {
    private final AzrathielModule mod; private final Vael v; public final Location center; public final Resource pool;
    private final double reserve; private final long startMs = System.currentTimeMillis();
    private boolean exhausted; private long exhaustedAt, nextBastion, nextStrike, lastPulse; private int bastionCount;

    private LastGuardian(AzrathielModule mod, Vael v, Location center) {
        this.mod = mod; this.v = v; this.center = center.clone(); this.pool = new Resource(mod.cfg.lgEnergy, 0); this.reserve = Math.min(mod.cfg.lgShockCost, mod.cfg.lgEnergy * 0.5);
    }

    /** Returns null if LAST GUARDIAN is disabled or on cooldown (then VAELZARION simply mourns: Mode.DOWN). */
    public static LastGuardian start(AzrathielModule mod, Vael v, Location deathLoc) {
        if (!mod.cfg.lgEnabled || System.currentTimeMillis() < v.bond.lgReadyAt) return null;
        LastGuardian g = new LastGuardian(mod, v, deathLoc);
        mod.fx.safe(() -> Choreo.guardSeal(mod, deathLoc, mod.cfg.lgRadius));
        v.bond.lgReadyAt = System.currentTimeMillis() + mod.cfg.lgCooldownSeconds * 1000L; v.bond.touch();      // anti-exploit: cannot chain guardians
        return g;
    }

    public boolean exhausted() { return exhausted; }
    private boolean canSpend(double x) { return pool.cur - x >= reserve; }

    public void tick() {
        long now = System.currentTimeMillis(); double dt = mod.cfg.aiInterval / 20.0; Player m = v.master(); if (m == null) return;
        if (exhausted) { if (now - exhaustedAt > mod.cfg.lgExhaustSeconds * 1000L) v.mode = Vael.Mode.DOWN; return; }
        pool.cur -= mod.cfg.lgDrain * dt;
        if (pool.cur <= reserve || now - startMs > mod.cfg.lgMaxSeconds * 1000L) { finish(m); return; }

        CastCtx ctx = new CastCtx(mod, m, null, true, center, center); ctx.vael = v;
        int removed = Util.removeProjectiles(ctx, center, mod.cfg.lgRadius);
        if (removed > 0) { pool.cur -= removed * mod.cfg.lgInterceptCost * 0.4; mod.fx.begin(); mod.fx.safe(() -> { Choreo.aegisBlock(ctx, center.clone().add(0, 1.5, 0)); mod.fx.sound(center, "intercept", 1f, 0.8f); }); }
        if ((System.currentTimeMillis() - startMs) / 1000 % 4 == 0 && now - lastPulse > 3000) { lastPulse = now; mod.fx.safe(() -> Choreo.guardPulse(mod, center, mod.cfg.lgRadius)); }

        List<LivingEntity> threats = mod.targeting.around(m, center, mod.cfg.lgRadius);      // hard leash: only the protected area, never beyond it
        if (threats.isEmpty()) return;
        v.target = threats.get(0);
        if (now >= nextBastion && canSpend(mod.cfg.lgBastionCost)) {                          // AEGIS defence and defensive Convergences
            int mask = (threats.size() >= 3 && (bastionCount % 2 == 1)) ? Convergence.mask(Eidolon.AEGIS, Eidolon.DOMINION) : Eidolon.AEGIS.bit(); bastionCount++;
            String key = "C:" + mask; var spec = mod.executor.specFor(v.bond, key);
            if (spec != null && mod.executor.usable(v.bond, spec)) {
                var o = new AbilityExecutor.Opts(); o.origin = center; o.free = true; o.bypassCooldown = true; o.targets = List.copyOf(threats);
                if (mod.executor.cast(v, key, spec, o).ok()) { pool.cur -= mod.cfg.lgBastionCost; nextBastion = now + 12_000; v.say(Category.LAST_GUARDIAN, null, "hold", null, false); }
            }
        }
        if (now >= nextStrike && canSpend(mod.cfg.lgInterceptCost)) {
            LivingEntity t = threats.get(0); ctx.focus = t.getLocation();
            Dmg.deal(ctx, 1, t, mod.cfg.basicDamage * 1.3, false, Util.outward(center, t.getLocation(), 0.8).setY(0.25));
            pool.cur -= mod.cfg.lgInterceptCost; nextStrike = now + 900; v.strike(t.getLocation(), false);
        }
    }

    private void finish(Player m) {
        exhausted = true; exhaustedAt = System.currentTimeMillis();
        CastCtx ctx = new CastCtx(mod, m, null, true, center, center); ctx.vael = v;
        double r = mod.cfg.lgShockRadius;
        for (LivingEntity t : mod.targeting.around(m, center, r)) Dmg.deal(ctx, 2, t, mod.cfg.lgShockDamage, true, Util.outward(center, t.getLocation(), 1.8).setY(0.7));   // the final defensive shockwave
        pool.set(0);
        v.say(Category.LAST_GUARDIAN, null, "shock", null, true);
        mod.fx.begin(); mod.fx.safe(() -> { Choreo.guardShock(mod, center, r); mod.fx.shockwave(center, r, 0x2E6FFF, Particle.END_ROD); mod.fx.spawn(center, Particle.EXPLOSION_EMITTER, 2, 1, 0.5, 1, 0); mod.fx.sound(center, "ultimate.impact", 1.2f, 0.8f); });
        v.mode = Vael.Mode.EXHAUSTED; v.setMarkMask(0); v.anim.play(com.des.weapons.azrathiel.core.AnimState.RECOVERY);
        mod.tasks.later(30, () -> v.say(Category.LAST_GUARDIAN, null, "exhaust", null, true));
        mod.onCastFinished(v, ctx);
    }
}
