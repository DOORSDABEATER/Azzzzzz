package com.des.weapons.azrathiel.gui;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.Actions;
import com.des.weapons.azrathiel.combat.AbilityExecutor;
import com.des.weapons.azrathiel.combat.SelfTest;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.*;

/** Every screen of AZRATHIEL CONTROL. Factory methods at the top; each screen is a small nested class. */
public final class Menus {
    private Menus() {}
    public static Menu control(AzrathielModule m, Player p) { return new Control(m, p); }
    public static Menu eidolons(AzrathielModule m, Player p) { return new Eidolons(m, p); }
    public static Menu loadout(AzrathielModule m, Player p) { return new Loadout(m, p, 0); }
    public static Menu workshop(AzrathielModule m, Player p) { return new Workshop(m, p); }

    static Material iconOf(Eidolon e) {
        return switch (e) { case VIGOR -> Material.BLAZE_POWDER; case ABYSS -> Material.ENDER_PEARL; case FATE -> Material.CLOCK; case RUIN -> Material.WITHER_SKELETON_SKULL;
            case AEGIS -> Material.SHIELD; case EVOLUTION -> Material.AMETHYST_SHARD; case WRAITH -> Material.SOUL_LANTERN; case DOMINION -> Material.GOLDEN_HELMET; };
    }
    static String col(Eidolon e) { return String.format("<#%06X>", e.rgb); }
    static String cd(AzrathielModule mod, BondData b, String key) { long ms = mod.executor.cooldownLeftMs(b, key); return ms == 0 ? "<green>ready" : "<red>" + (ms / 1000) + "s"; }
    static String specLore(Convergence.Spec s) { return "<gray>" + s.order().size() + " Eidolon(s) | " + s.mode().name().toLowerCase() + " | dmg <white>" + (int) s.damage() + "<gray> | cd <white>" + s.cooldownTicks() / 20 + "s<gray> | cost <white>" + s.cost(); }

    // ============================================================================================ AZRATHIEL CONTROL
    static final class Control extends Menu {
        Control(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<gradient:#7a1bff:#ffc83d><bold>AZRATHIEL CONTROL"; }
        @Override protected int size() { return 54; }
        @Override protected void build() {
            BondData b = bond(); Vael v = vael(); if (b == null) { set(22, icon(Material.BARRIER, "<red>No bond", "Right-click the AZRATHIEL vessel to awaken it.")); return; }
            List<String> st = new ArrayList<>(); if (v == null) st.add("<red>Not summoned"); else { st.add("Form: <white>" + v.form().title); st.add("Mode: <white>" + v.mode + (v.inCombat() ? " <red>(combat)" : ""));
                st.add("Animation: <white>" + v.animState()); st.add("Essence: <gold>" + Actions.bar(v.essence.fraction(), 20) + " <white>" + (int) v.essence.cur + "/" + (int) v.essence.max); }
            st.add("Bond: <white>" + b.ownerName + " <dark_gray>(" + b.bondId.toString().substring(0, 8) + ")"); st.add("Active loadout: <white>" + b.activeLoadout);
            set(4, icon(Material.NETHER_STAR, "<gradient:#7a1bff:#ffc83d><bold>VAELZARION STATUS", st.toArray(new String[0])));
            set(10, icon(v == null ? Material.BEACON : Material.BARRIER, v == null ? "<green>Summon VAELZARION" : "<red>Dismiss VAELZARION"), e -> { result(mod.actions.toggleSummon(p)); redraw(); });
            set(11, icon(Material.SHIELD, "<gold>Form control", "Current: <white>" + (v == null ? "-" : v.form().title), "Click: toggle Dormant / Released"), e -> { result(mod.actions.release(p, null)); redraw(); });
            long ul = Math.max(0, b.ultReadyAt - System.currentTimeMillis());
            set(12, icon(Material.TNT, "<gold><bold>EIGHTFOLD APOCALYPSE", "Cost: <white>" + (int) mod.cfg.ultCost + " essence", "Cooldown: " + (ul == 0 ? "<green>ready" : "<red>" + ul / 1000 + "s"), "Click: awaken all eight authorities"), e -> { result(mod.actions.ultimate(p)); p.closeInventory(); });
            Object[][] stance = {{19, Material.LEAD, "Follow", Vael.Mode.FOLLOW}, {20, Material.ANVIL, "Stay", Vael.Mode.STAY}, {21, Material.SHIELD, "Defend", Vael.Mode.DEFEND},
                    {22, Material.IRON_SWORD, "Attack", Vael.Mode.ATTACK}, {23, Material.ENDER_PEARL, "Return", Vael.Mode.RETURN}};
            for (Object[] s : stance) { Vael.Mode md = (Vael.Mode) s[3]; set((int) s[0], icon((Material) s[1], "<yellow>" + s[2], v != null && v.mode == md ? "<green>active" : "Click to command"), e -> { result(mod.actions.stance(p, md)); redraw(); }); }
            set(24, icon(Material.COMPASS, "<yellow>Resume", "Return to autonomous judgement"), e -> { result(mod.actions.resume(p)); redraw(); });
            set(28, icon(Material.ENDER_EYE, "<light_purple>EIDOLON MANAGEMENT", "Awaken, enable and cast the eight authorities"), e -> new Eidolons(mod, p).open());
            set(29, icon(Material.DIAMOND_SWORD, "<aqua>ABILITIES", "Everything VAELZARION can use + cooldowns"), e -> new Loadout(mod, p, 0).open());
            set(30, icon(Material.ENCHANTED_BOOK, "<gold>CONVERGENCE WORKSHOP", "Build, test and save any of the 255 combinations"), e -> new Workshop(mod, p).open());
            set(31, icon(Material.CHEST, "<green>SET LOADOUT", "Ordering, presets and the full arsenal"), e -> new Loadout(mod, p, 0).open());
            set(32, icon(Material.NOTE_BLOCK, "<light_purple>VOICE & PERSONALITY", "Volume, layers, subtitles, personality"), e -> new Voices(mod, p).open());
            set(33, icon(Material.PAINTING, "<yellow>VISUAL CUSTOMIZATION", "Theme: <white>" + b.theme), e -> new Visuals(mod, p).open());
            set(34, icon(Material.REPEATER, "<aqua>ANIMATION SETTINGS", "Intensity and live preview of all 25 states"), e -> new Anims(mod, p).open());
            set(37, icon(Material.NAME_TAG, "<white>MASTER BOND", "Owner, identity, statistics"), e -> new Bond(mod, p).open());
            set(38, icon(Material.IRON_SWORD, "<red>COMBAT SETTINGS", "Aggression, following, interception"), e -> new Combat(mod, p).open());
            set(39, icon(Material.EXPERIENCE_BOTTLE, "<green>PROGRESSION", "Kills: <white>" + b.kills + "<gray> | Boss kills: <white>" + b.bossKills), e -> new Progress(mod, p).open());
            if (p.hasPermission("des.azrathiel.admin")) set(40, icon(Material.COMMAND_BLOCK, "<dark_red>ADMINISTRATION", "Reload, self-test, cleanup"), e -> new Admin(mod, p).open());
            set(49, icon(Material.BARRIER, "<gray>Close"), e -> p.closeInventory());
        }
    }

    // ============================================================================================ EIDOLON MANAGEMENT
    static final class Eidolons extends Menu {
        Eidolons(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<light_purple><bold>EIDOLON MANAGEMENT"; }
        @Override protected int size() { return 36; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return;
            for (Eidolon e : Eidolon.values()) {
                boolean un = mod.unlocked(b, e), en = b.enabled.contains(e); String key = "C:" + e.bit();
                set(10 + e.ordinal() + (e.ordinal() > 3 ? 1 : 0), icon(iconOf(e), col(e) + "<bold>" + e.display.toUpperCase(), "<gray>" + e.authority, "Signature: <white>" + e.signature, "Personality: <white>" + e.personality,
                        "Status: " + (!un ? "<red>locked" : en ? "<green>awakened" : "<yellow>silenced"), "Cooldown: " + cd(mod, b, key), "", "Left-click: enable / disable", "Right-click: cast signature"), c -> {
                    if (c.isRightClick()) result(mod.actions.cast(p, key)); else if (un) { if (!b.enabled.remove(e)) b.enabled.add(e); Vael v = vael(); if (v != null) v.restoreMarkMask(); changed(); return; }
                    redraw(); });
            }
            back(31, () -> new Control(mod, p));
        }
    }

    // ============================================================================================ SET LOADOUT / ABILITIES
    static final class Loadout extends Menu {
        private int page; Loadout(AzrathielModule m, Player p, int page) { super(m, p); this.page = page; }
        @Override protected String title() { return "<green><bold>SET LOADOUT <dark_gray>- abilities"; }
        @Override protected int size() { return 54; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return; List<String> keys = b.loadout(); int per = 36, pages = Math.max(1, (keys.size() + per - 1) / per); page = Math.max(0, Math.min(page, pages - 1));
            for (int i = 0; i < per; i++) { int idx = page * per + i; if (idx >= keys.size()) break; final int ix = idx; String key = keys.get(idx); var s = mod.executor.specFor(b, key);
                if (s == null) { set(i, icon(Material.BARRIER, "<red>" + key, "Unknown ability", "Right-click: remove"), c -> { if (c.isRightClick()) { keys.remove(ix); changed(); } }); continue; }
                boolean sel = Math.floorMod(b.selected, Math.max(1, keys.size())) == idx;
                set(i, icon(s.handcrafted() ? Material.ENCHANTED_BOOK : s.order().size() == 1 ? iconOf(s.order().get(0)) : Material.BOOK, (sel ? "<green>> " : "<white>") + s.name(), specLore(s),
                        "Eidolons: <white>" + String.join(" + ", s.order().stream().map(x -> x.display).toList()), "Cooldown: " + cd(mod, b, key), "", "Left: select / cast", "Right: remove", "Shift-Left: move earlier", "Shift-Right: move later"), c -> {
                    if (c.isRightClick() && c.isShiftClick()) { if (ix < keys.size() - 1) Collections.swap(keys, ix, ix + 1); }
                    else if (c.isRightClick()) keys.remove(ix);
                    else if (c.isShiftClick()) { if (ix > 0) Collections.swap(keys, ix, ix - 1); }
                    else { b.selected = ix; result(mod.actions.cast(p, key)); }
                    changed(); });
            }
            int slot = 36; for (String name : b.loadouts.keySet()) { if (slot > 44) break; final String nm = name; boolean act = nm.equals(b.activeLoadout);
                set(slot++, icon(act ? Material.LIME_DYE : Material.GRAY_DYE, (act ? "<green>" : "<white>") + "Preset: " + nm, b.loadouts.get(nm).size() + " abilities", "Left: switch", "Right: delete (not the last)"), c -> {
                    if (c.isRightClick()) { if (b.loadouts.size() > 1) { b.loadouts.remove(nm); if (nm.equals(b.activeLoadout)) b.activeLoadout = b.loadouts.keySet().iterator().next(); } } else { b.activeLoadout = nm; b.selected = 0; } changed(); }); }
            set(45, icon(Material.ARROW, "<yellow>Previous page"), c -> { page--; redraw(); }); set(53, icon(Material.ARROW, "<yellow>Next page"), c -> { page++; redraw(); });
            set(46, icon(Material.WRITABLE_BOOK, "<green>New preset", "Copies the current loadout"), c -> mod.prompts.ask(p, "Name the new preset", n -> { String nm = n.length() > 24 ? n.substring(0, 24) : n; if (!b.loadouts.containsKey(nm)) b.loadouts.put(nm, new ArrayList<>(b.loadout())); b.activeLoadout = nm; b.touch(); new Loadout(mod, p, 0).open(); }));
            set(47, icon(Material.HOPPER, "<aqua>Add abilities", "Browse all 255 Convergences and your saved ones"), c -> new Picker(mod, p, 0).open());
            set(48, icon(Material.NETHER_STAR, "<gold>Add EVERYTHING", "All 255 combinations (full arsenal)"), c -> { Set<String> have = new HashSet<>(keys); for (int mk : Convergence.allMasks()) if (!have.contains("C:" + mk)) keys.add("C:" + mk); changed(); });
            set(49, icon(Material.BARRIER, "<red>Reset preset", "Back to Eidolons + handcrafted"), c -> { keys.clear(); keys.addAll(BondData.defaultKeys(true, true)); changed(); });
            back(52, () -> new Control(mod, p));
            set(50, icon(Material.PAPER, "Page " + (page + 1) + "/" + pages, "Essence: <gold>" + (vael() == null ? "-" : (int) vael().essence.cur)));
        }
    }

    static final class Picker extends Menu {
        private int page; Picker(AzrathielModule m, Player p, int page) { super(m, p); this.page = page; }
        @Override protected String title() { return "<aqua><bold>ADD ABILITIES"; }
        @Override protected int size() { return 54; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return; List<String> all = new ArrayList<>(); for (BondData.Custom c : b.customs) all.add("X:" + c.name()); for (int mk : Convergence.allMasks()) all.add("C:" + mk);
            int per = 45, pages = (all.size() + per - 1) / per; page = Math.max(0, Math.min(page, pages - 1));
            for (int i = 0; i < per; i++) { int idx = page * per + i; if (idx >= all.size()) break; String key = all.get(idx); var s = mod.executor.specFor(b, key); if (s == null) continue; boolean has = b.loadout().contains(key);
                set(i, icon(has ? Material.LIME_DYE : s.handcrafted() ? Material.ENCHANTED_BOOK : Material.BOOK, (has ? "<green>" : "<white>") + s.name(), specLore(s), has ? "Already in loadout" : "Click to add"), c -> { if (!has) { b.loadout().add(key); b.touch(); } redraw(); }); }
            set(45, icon(Material.ARROW, "<yellow>Previous"), c -> { page--; redraw(); }); set(53, icon(Material.ARROW, "<yellow>Next"), c -> { page++; redraw(); });
            back(49, () -> new Loadout(mod, p, 0)); set(50, icon(Material.PAPER, "Page " + (page + 1) + "/" + pages));
        }
    }

    // ============================================================================================ CONVERGENCE WORKSHOP
    static final class Workshop extends Menu {
        private final List<Eidolon> sel = new ArrayList<>();
        Workshop(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<gold><bold>CONVERGENCE WORKSHOP"; }
        @Override protected int size() { return 54; }
        private Convergence.Spec spec() { return sel.isEmpty() ? null : Convergence.build(Convergence.mask(sel), sel, mod.balance()); }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return;
            for (Eidolon e : Eidolon.values()) { int pos = sel.indexOf(e); boolean un = mod.unlocked(b, e);
                set(9 + e.ordinal(), icon(iconOf(e), (pos >= 0 ? col(e) + "<bold>" : "<white>") + e.display.toUpperCase(), pos >= 0 ? "<green>Order #" + (pos + 1) : un ? "Click to add (order = selection order)" : "<red>Locked", "Click again to remove"), c -> {
                    if (!un) return; if (!sel.remove(e)) sel.add(e); redraw(); }); }
            Convergence.Spec s = spec();
            if (s == null) set(4, icon(Material.PAPER, "<gray>Select Eidolons", "Any combination of the eight, in any order.", "No restrictions."));
            else { List<String> l = new ArrayList<>(List.of(specLore(s), "Sequence: <white>" + String.join(" > ", s.order().stream().map(x -> x.display).toList()), "Radius: <white>" + String.format("%.1f", s.radius()) + "<gray> | Range: <white>" + (int) s.range(),
                    s.handcrafted() ? "<gold>Handcrafted Convergence" : "<gray>Generated by the Convergence engine"));
                for (Convergence.Eff f : s.enemy()) l.add("<red>Enemies: " + f.type() + " " + f.ticks() / 20 + "s"); for (Convergence.Eff f : s.self()) l.add("<green>Master: " + f.type() + " " + f.ticks() / 20 + "s");
                set(4, icon(Material.NETHER_STAR, "<gold><bold>" + s.name(), l.toArray(new String[0]))); }
            set(2, icon(Material.BARRIER, "<red>Clear selection"), c -> { sel.clear(); redraw(); });
            set(18, icon(Material.ENDER_EYE, "<light_purple>Preview", "Shows the participating Eidolons (no damage)"), c -> { if (s != null) preview(s); });
            set(19, icon(Material.ZOMBIE_HEAD, "<red>Test on dummy", "Spawns a controlled dummy and casts it (free, no cooldown)"), c -> { if (s != null) test(b, s); });
            set(20, icon(Material.WRITABLE_BOOK, "<green>Save combination", "Stores this exact order under a name"), c -> { if (s != null) mod.prompts.ask(p, "Name this combination", n -> { String nm = n.length() > 24 ? n.substring(0, 24) : n; if (b.custom(nm) != null) throw new IllegalArgumentException("that name exists"); b.customs.add(new BondData.Custom(nm, new ArrayList<>(sel), false)); b.touch(); new Workshop(mod, p).open(); }); });
            set(21, icon(Material.CHEST, "<aqua>Add to loadout", "Appends this combination to the active preset"), c -> { if (s != null) { String key = "C:" + s.mask(); if (!b.loadout().contains(key)) b.loadout().add(key); b.touch(); p.sendMessage(mod.msg("<gray>Added <white>" + s.name())); } });
            set(22, icon(Material.TARGET, "<yellow>Cast now", "Uses normal cooldown and essence"), c -> { if (s != null) result(mod.actions.cast(p, "C:" + s.mask())); });
            back(26, () -> new Control(mod, p));
            List<BondData.Custom> cs = new ArrayList<>(b.customs); cs.sort(Comparator.comparing((BondData.Custom x) -> !x.favorite()).thenComparing(BondData.Custom::name));
            for (int i = 0; i < Math.min(18, cs.size()); i++) { BondData.Custom cu = cs.get(i);
                set(27 + i, icon(cu.favorite() ? Material.ENCHANTED_BOOK : Material.BOOK, (cu.favorite() ? "<gold>* " : "<white>") + cu.name(), "Order: <white>" + String.join(" > ", cu.order().stream().map(x -> x.display).toList()),
                        "Left: load | Right: duplicate", "Shift-Left: rename | Shift-Right: delete", "Q (drop): favourite"), c -> {
                    ClickType t = c.getClick();
                    if (t == ClickType.DROP || t == ClickType.CONTROL_DROP) { b.customs.set(b.customs.indexOf(cu), cu.withFav(!cu.favorite())); changed(); }
                    else if (t == ClickType.SHIFT_RIGHT) { b.customs.remove(cu); b.loadouts.values().forEach(l -> l.remove("X:" + cu.name())); changed(); }
                    else if (t == ClickType.SHIFT_LEFT) mod.prompts.ask(p, "New name", n -> { String nm = n.length() > 24 ? n.substring(0, 24) : n; if (b.custom(nm) != null) throw new IllegalArgumentException("that name exists"); int ix = b.customs.indexOf(cu); b.customs.set(ix, cu.withName(nm)); b.loadouts.values().forEach(l -> { int k = l.indexOf("X:" + cu.name()); if (k >= 0) l.set(k, "X:" + nm); }); b.touch(); new Workshop(mod, p).open(); });
                    else if (t == ClickType.RIGHT) { String nm = cu.name() + " II"; int k = 2; while (b.custom(nm) != null) nm = cu.name() + " " + (++k); b.customs.add(new BondData.Custom(nm, new ArrayList<>(cu.order()), false)); changed(); }
                    else { sel.clear(); sel.addAll(cu.order()); redraw(); } });
            }
        }
        private void preview(Convergence.Spec s) {
            Location l = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(5)); mod.fx.begin();
            for (int i = 0; i < s.order().size(); i++) { final Eidolon e = s.order().get(i); mod.tasks.later(i * 8L, () -> { mod.fx.ring(l, 2 + e.ordinal() * 0.4, e.rgb, 30, 0.1 + e.ordinal() * 0.12); mod.fx.sound(l, "cast." + e.id(), 0.6f, 1f); }); }
            p.sendMessage(mod.msg("<gray>Previewing <gold>" + s.name() + "</gold>: " + String.join(" > ", s.order().stream().map(x -> col(x) + x.display).toList())));
        }
        private void test(BondData b, Convergence.Spec s) {
            Vael v = vael(); if (v == null) { p.sendMessage(mod.msg("<red>Summon VAELZARION first.")); return; } p.closeInventory();
            LivingEntity d = SelfTest.dummy(mod, p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(7)), 900);
            var o = new AbilityExecutor.Opts(); o.free = true; o.bypassCooldown = true; o.targets = List.of(d); double before = d.getHealth();
            var r = mod.executor.cast(v, "C:" + s.mask(), s, o); if (!r.ok()) { p.sendMessage(mod.msg("<red>" + r.reason())); return; }
            mod.tasks.later(110, () -> p.sendMessage(mod.msg("<gray>Test of <gold>" + s.name() + "</gold>: dummy lost <white>" + String.format("%.1f", before - d.getHealth()) + "</white> health.")));
        }
    }

    // ============================================================================================ VOICE & PERSONALITY
    static final class Voices extends Menu {
        Voices(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<light_purple><bold>VOICE & PERSONALITY"; }
        @Override protected int size() { return 54; }
        private void pct(int slot, Material mat, String name, java.util.function.DoubleSupplier get, java.util.function.DoubleConsumer put, double lo, double hi) {
            set(slot, icon(mat, "<white>" + name + ": <gold>" + (int) Math.round(get.getAsDouble() * 100) + "%", "Left +10% | Right -10% | Shift x5"), c -> { put.accept(clamp(get.getAsDouble() + step(c, 0.1), lo, hi)); changed(); });
        }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return;
            pct(10, Material.NOTE_BLOCK, "Master voice volume", () -> b.voiceVolume, x -> b.voiceVolume = x, 0, 2);
            pct(11, Material.CLOCK, "Voice frequency", () -> b.voiceFrequency, x -> b.voiceFrequency = x, 0, 1);
            pct(12, Material.GOAT_HORN, "Pitch (0.5-2.0)", () -> b.pitch, x -> b.pitch = x, 0.5, 2);
            pct(13, Material.AMETHYST_BLOCK, "Reverb / echo", () -> b.reverb, x -> b.reverb = x, 0, 1);
            pct(14, Material.SCULK_SENSOR, "Eidolon layer intensity", () -> b.layerIntensity, x -> b.layerIntensity = x, 0, 1);
            set(15, icon(Material.NAME_TAG, "<white>Subtitles: <gold>" + b.subtitleMode, "Click to cycle ACTIONBAR / CHAT / BOTH / OFF"), c -> { List<String> m = List.of("ACTIONBAR", "CHAT", "BOTH", "OFF"); b.subtitleMode = m.get((m.indexOf(b.subtitleMode) + 1) % m.size()); changed(); });
            set(16, icon(b.silent ? Material.BARRIER : Material.LIME_DYE, "<white>Silent mode: " + onOff(b.silent), "VAELZARION says nothing at all"), c -> { b.silent = !b.silent; changed(); });
            Personality[] ps = Personality.values();
            set(19, icon(Material.PLAYER_HEAD, "<white>Personality: <gold>" + b.personality, "Changes what is said and how often.", "Never changes damage or balance.", "Left: next | Right: previous"), c -> { b.personality = ps[Math.floorMod(b.personality.ordinal() + (c.isRightClick() ? -1 : 1), ps.length)]; changed(); });
            if (b.personality == Personality.CUSTOM) pct(20, Material.COMPARATOR, "Custom chatter level", () -> b.customMul, x -> b.customMul = x, 0, 1.5);
            int s = 21; for (Form f : Form.values()) { final Form ff = f; pct(s++, Material.BEACON, f.name() + " volume", () -> b.formVolume.getOrDefault(ff, 1.0), x -> b.formVolume.put(ff, x), 0, 2); }
            for (Eidolon e : Eidolon.values()) { final Eidolon ee = e; set(27 + e.ordinal(), icon(iconOf(e), col(e) + e.display + " voice: <gold>" + (int) Math.round(b.eidolonVolume.getOrDefault(e, 1.0) * 100) + "%", "Left +10% | Right -10%"), c -> { b.eidolonVolume.put(ee, clamp(b.eidolonVolume.getOrDefault(ee, 1.0) + step(c, 0.1), 0, 2)); changed(); }); }
            set(37, icon(Material.BOOKSHELF, "<white>Dialogue categories", "Toggle each kind of line"), c -> new Categories(mod, p).open());
            set(38, icon(Material.WRITTEN_BOOK, "<white>Dialogue history", "Prints the last lines to chat"), c -> { Vael v = vael(); p.closeInventory(); if (v == null) { p.sendMessage(mod.msg("<gray>Summon VAELZARION to build a history.")); return; }
                var h = v.director.history().stream().filter(x -> x.line().category() != Category.SECRET).toList(); for (var x : h.subList(Math.max(0, h.size() - 10), h.size())) p.sendMessage(mod.msg("<gray>" + x.line().category().key() + ": <white>" + x.line().text())); if (h.isEmpty()) p.sendMessage(mod.msg("<gray>Nothing yet.")); });
            set(39, icon(Material.JUKEBOX, "<white>Preview voice", mod.cfg.recordingsInstalled ? "Plays a random line" : "<yellow>No recordings installed - subtitle preview only"), c -> { Vael v = vael(); if (v == null) { p.sendMessage(mod.msg("<red>Summon VAELZARION first.")); return; }
                var pool = mod.voiceLib.all().stream().filter(x -> x.category() != Category.SECRET && x.sub() == null).toList(); mod.voice.sayLine(v, pool.get(new Random().nextInt(pool.size()))); });
            back(49, () -> new Control(mod, p));
        }
    }

    static final class Categories extends Menu {
        Categories(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<light_purple><bold>DIALOGUE CATEGORIES"; }
        @Override protected int size() { return 36; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return; int i = 0;
            for (Category c : Category.values()) { if (c == Category.SECRET) continue; boolean off = b.disabledCategories.contains(c);
                set(i++, icon(off ? Material.GRAY_DYE : Material.LIME_DYE, (off ? "<red>" : "<green>") + c.name().replace('_', ' '), mod.voiceLib.of(c).size() + " lines", "Click to toggle"), e -> { if (off) b.disabledCategories.remove(c); else b.disabledCategories.add(c); changed(); }); }
            back(31, () -> new Voices(mod, p));
        }
    }

    // ============================================================================================ VISUAL CUSTOMIZATION
    static final class Visuals extends Menu {
        Visuals(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<yellow><bold>VISUAL CUSTOMIZATION"; }
        @Override protected int size() { return 36; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return; List<String> th = BondData.THEMES;
            set(10, icon(Material.PAINTING, "<white>Theme: <gold>" + b.theme, "Left: next | Right: previous", "All themes keep VAELZARION recognisable"), c -> { b.theme = th.get(Math.floorMod(th.indexOf(b.theme) + (c.isRightClick() ? -1 : 1), th.size())); changed(); });
            set(11, icon(Material.PURPLE_DYE, "<white>Custom colour: " + String.format("#%06X", b.customColor & 0xFFFFFF), "Click, then type #RRGGBB (selects CUSTOM theme)"), c -> mod.prompts.ask(p, "Enter a hex colour like #7A1BFF", s -> { b.customColor = Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF; b.theme = "CUSTOM"; b.touch(); new Visuals(mod, p).open(); }));
            set(12, icon(Material.BLAZE_POWDER, "<white>Particle intensity: <gold>" + (int) Math.round(b.particleIntensity * 100) + "%", "Left +10% | Right -10%"), c -> { b.particleIntensity = clamp(b.particleIntensity + step(c, 0.1), 0, 2); changed(); });
            set(13, icon(Material.ENDER_EYE, "<white>Core size: <gold>" + (int) Math.round(b.coreScale * 100) + "%", "Left +10% | Right -10%"), c -> { b.coreScale = clamp(b.coreScale + step(c, 0.1), 0.5, 2); changed(); });
            set(14, icon(Material.HEART_OF_THE_SEA, "<white>Halo speed: <gold>" + (int) Math.round(b.haloSpeed * 100) + "%", "Left +10% | Right -10%"), c -> { b.haloSpeed = clamp(b.haloSpeed + step(c, 0.1), 0.2, 3); changed(); });
            Object[][] tg = {{19, "Aura particles", b.aura}, {20, "Halo", b.showHalo}, {21, "Floating fragments", b.showFragments}, {22, "Eidolon markings", b.showMarkings}, {23, "Transformation effects", b.transformFx}};
            for (Object[] t : tg) { int slot = (int) t[0]; set(slot, icon((boolean) t[2] ? Material.LIME_DYE : Material.GRAY_DYE, "<white>" + t[1] + ": " + onOff((boolean) t[2])), c -> {
                switch (slot) { case 19 -> b.aura = !b.aura; case 20 -> b.showHalo = !b.showHalo; case 21 -> b.showFragments = !b.showFragments; case 22 -> b.showMarkings = !b.showMarkings; default -> b.transformFx = !b.transformFx; } changed(); }); }
            back(31, () -> new Control(mod, p));
        }
    }

    // ============================================================================================ ANIMATION SETTINGS
    static final class Anims extends Menu {
        Anims(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<aqua><bold>ANIMATION SETTINGS"; }
        @Override protected int size() { return 54; }
        @Override protected void build() {
            BondData b = bond(); Vael v = vael(); if (b == null) return;
            set(49, icon(Material.REPEATER, "<white>Animation intensity: <gold>" + (int) Math.round(b.animIntensity * 100) + "%", "Scales arm / lean excursions", "Left +10% | Right -10%"), c -> { b.animIntensity = clamp(b.animIntensity + step(c, 0.1), 0.2, 1.5); changed(); });
            set(48, icon(Material.PAPER, "<white>Current: <gold>" + (v == null ? "-" : v.animState()), v == null ? "Summon VAELZARION to preview" : v.diagnostics(), "Click a state to preview it for 4s"));
            int i = 0; for (AnimState s : AnimState.values()) { final AnimState st = s;
                set(i++, icon(s.loops() ? Material.CLOCK : Material.FEATHER, "<white>" + s.name(), s.loops() ? "Looping state" : "One-shot " + s.duration + "s", "Priority " + s.priority), c -> { Vael vv = vael(); if (vv != null) vv.preview(st); else p.sendMessage(mod.msg("<red>Summon VAELZARION first.")); }); }
            back(53, () -> new Control(mod, p));
        }
    }

    // ============================================================================================ MASTER BOND / COMBAT / PROGRESSION / ADMIN
    static final class Bond extends Menu {
        Bond(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<white><bold>MASTER BOND"; }
        @Override protected int size() { return 27; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return;
            set(11, icon(Material.NAME_TAG, "<white>Master: " + b.ownerName, "UUID: <white>" + b.owner, "Bond identity: <white>" + b.bondId, "Only this UUID can command VAELZARION.", "Administrators can reassign the bond; everything is kept."));
            set(13, icon(Material.EXPERIENCE_BOTTLE, "<white>History", "Kills: <white>" + b.kills, "Boss kills: <white>" + b.bossKills, "Apocalypses: <white>" + b.awakenings, "Master deaths: <white>" + b.deaths));
            set(15, icon(Material.CHEST, "<white>Saved data", "Presets: <white>" + b.loadouts.size(), "Saved Convergences: <white>" + b.customs.size(), "Persisted across restarts."));
            back(22, () -> new Control(mod, p));
        }
    }

    static final class Combat extends Menu {
        Combat(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<red><bold>COMBAT SETTINGS"; }
        @Override protected int size() { return 27; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return;
            set(10, icon(b.autoRelease ? Material.LIME_DYE : Material.GRAY_DYE, "<white>Auto-release on danger: " + onOff(b.autoRelease), "Dormant becomes Released vs bosses / crowds"), c -> { b.autoRelease = !b.autoRelease; changed(); });
            set(11, icon(b.interceptProjectiles ? Material.LIME_DYE : Material.GRAY_DYE, "<white>Intercept projectiles: " + onOff(b.interceptProjectiles)), c -> { b.interceptProjectiles = !b.interceptProjectiles; changed(); });
            set(12, icon(Material.IRON_SWORD, "<white>Aggression: <gold>" + (int) Math.round(b.aggression * 100) + "%", "Higher = acts sooner and more often. No effect on damage.", "Left +10% | Right -10%"), c -> { b.aggression = clamp(b.aggression + step(c, 0.1), 0.2, 2); changed(); });
            set(13, icon(Material.LEAD, "<white>Follow distance: <gold>" + (b.followDistance <= 0 ? "default" : b.followDistance), "Left +0.2 | Right -0.2 (0 = server default)"), c -> { b.followDistance = clamp(b.followDistance + step(c, 0.2), 0, 8); changed(); });
            set(14, icon(Material.FEATHER, "<white>Hover height: <gold>" + (b.hoverHeight <= 0 ? "default" : b.hoverHeight), "Left +0.2 | Right -0.2 (0 = server default)"), c -> { b.hoverHeight = clamp(b.hoverHeight + step(c, 0.2), 0, 6); changed(); });
            set(16, icon(Material.PAPER, "<white>Server rules", "Detection radius: <white>" + (int) mod.cfg.detectionRadius, "PvP: <white>" + mod.cfg.pvpMode, "Global cooldown: <white>" + mod.cfg.globalCooldownMs + "ms"));
            back(22, () -> new Control(mod, p));
        }
    }

    static final class Progress extends Menu {
        Progress(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<green><bold>PROGRESSION"; }
        @Override protected int size() { return 36; }
        @Override protected void build() {
            BondData b = bond(); if (b == null) return; long pts = b.kills + (long) b.bossKills * mod.cfg.bossKillBonus;
            set(4, icon(Material.EXPERIENCE_BOTTLE, "<green>Progress points: " + pts, mod.cfg.fullAccess ? "<yellow>FULL ACCESS is enabled: everything is unlocked." : mod.cfg.progressionEnabled ? "One new Eidolon every " + mod.cfg.killsPerEidolon + " points (boss kill = " + (1 + mod.cfg.bossKillBonus) + ")" : "Admin unlocking only"));
            int i = 0; for (Eidolon e : mod.cfg.unlockOrder) { boolean un = mod.unlocked(b, e); set(9 + i, icon(iconOf(e), (un ? col(e) : "<dark_gray>") + e.display, un ? "<green>Awakened" : "<red>Needs " + ((i) * mod.cfg.killsPerEidolon) + " points")); i++; }
            back(31, () -> new Control(mod, p));
        }
    }

    static final class Admin extends Menu {
        Admin(AzrathielModule m, Player p) { super(m, p); }
        @Override protected String title() { return "<dark_red><bold>ADMINISTRATION"; }
        @Override protected int size() { return 27; }
        @Override protected void build() {
            if (!p.hasPermission("des.azrathiel.admin")) { p.closeInventory(); return; }
            set(10, icon(Material.COMMAND_BLOCK, "<white>Reload config + voice packs"), c -> { var w = mod.reload(); p.sendMessage(mod.msg("<green>Reloaded." + (w.isEmpty() ? "" : " <yellow>" + w.size() + " warning(s) in console."))); });
            set(11, icon(Material.ZOMBIE_HEAD, "<white>Run self-test", "Spawns a dummy and verifies damage for every ability"), c -> { p.closeInventory(); SelfTest.run(mod, p, true); });
            set(12, icon(Material.TNT, "<white>Remove stray rig entities"), c -> p.sendMessage(mod.msg("<gray>Removed <white>" + mod.vaels.purgeOrphans())));
            set(13, icon(Material.NETHERITE_SWORD, "<white>Give AZRATHIEL vessel (unbound)"), c -> { p.getInventory().addItem(mod.weapon.create(null)); });
            set(14, icon(mod.debug ? Material.LIME_DYE : Material.GRAY_DYE, "<white>Debug logging: " + onOff(mod.debug)), c -> { mod.debug = !mod.debug; redraw(); });
            set(16, icon(Material.PAPER, "<white>Runtime", "Active guardians: <white>" + mod.vaels.count(), "Scheduled tasks: <white>" + mod.tasks.active(), "Bonds on disk: <white>" + mod.store.all().size(), "Full access: <white>" + mod.cfg.fullAccess));
            back(22, () -> new Control(mod, p));
        }
    }
}
