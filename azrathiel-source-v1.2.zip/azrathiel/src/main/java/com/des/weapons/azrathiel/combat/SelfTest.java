package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Convergence;
import com.des.weapons.azrathiel.core.Eidolon;
import com.des.weapons.azrathiel.core.Form;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * In-game verification harness (/azrathiel admin selftest). For every Eidolon, the ten handcrafted Convergences, a custom 4-way
 * combination and the ultimate: spawn a controlled dummy, execute with cosmetics OFF and no animation/voice, then verify real health
 * loss and damage attribution. Also verifies cooldown behaviour and multi-target ultimate damage. Results go to chat and console.
 */
public final class SelfTest {
    private SelfTest() {}

    public static LivingEntity dummy(AzrathielModule mod, Location loc, int lifeTicks) {
        Zombie z = loc.getWorld().spawn(loc, Zombie.class, e -> {
            e.setAI(false); e.setSilent(true); e.setBaby(false); e.setPersistent(false); e.setRemoveWhenFarAway(true); e.setShouldBurnInDay(false);
            e.customName(Component.text("Convergence Dummy")); e.setCustomNameVisible(true);
            var a = e.getAttribute(Attribute.MAX_HEALTH); if (a != null) a.setBaseValue(2000); e.setHealth(2000);
        });
        mod.tasks.later(lifeTicks, () -> { if (z.isValid()) z.remove(); });
        return z;
    }

    private record Case(String name, String key, Convergence.Spec spec, boolean ultimate, int wait) {}

    public static void run(AzrathielModule mod, CommandSender out, boolean cosmeticsOff) {
        if (!(out instanceof Player p)) { out.sendMessage("Run the self-test in-game, standing in an open area."); return; }
        if (mod.testing) { out.sendMessage("A self-test is already running."); return; }
        BondData b = mod.actions.bond(p); if (b == null) { out.sendMessage("Awaken the AZRATHIEL vessel first."); return; }
        Vael v = mod.vaels.of(p.getUniqueId());
        if (v == null) { String e = mod.actions.summon(p); if (e != null) { out.sendMessage(e); return; } v = mod.vaels.of(p.getUniqueId()); }
        if (v == null) { out.sendMessage("Could not summon VAELZARION."); return; }
        if (!v.released()) v.setForm(Form.RELEASED, false);
        List<Case> cases = new ArrayList<>();
        for (Eidolon e : Eidolon.values()) cases.add(new Case(e.signatureUpper(), "C:" + e.bit(), Convergence.build(e.bit(), null, mod.balance()), false, 90));
        for (int mask : Convergence.handcrafted().keySet()) cases.add(new Case(Convergence.nameOf(mask), "C:" + mask, Convergence.build(mask, null, mod.balance()), false, 110));
        int four = Convergence.mask(Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.EVOLUTION, Eidolon.DOMINION);
        cases.add(new Case(Convergence.nameOf(four) + " (auto-generated, custom order)", "C:" + four,
                Convergence.build(four, List.of(Eidolon.WRAITH, Eidolon.VIGOR, Eidolon.EVOLUTION, Eidolon.DOMINION), mod.balance()), false, 110));
        cases.add(new Case("EIGHTFOLD APOCALYPSE", "ULT", null, true, mod.cfg.ultDurationTicks + 30));
        mod.testing = true; out.sendMessage(mod.msg("<gold>Self-test started: " + cases.size() + " cases. Stand still in an open area. Cosmetics " + (cosmeticsOff ? "OFF" : "ON") + "."));
        new Runner(mod, p, v, b, cases, cosmeticsOff, out).start();
    }

    private static final class Runner {
        final AzrathielModule mod; final Player p; final Vael v; final BondData b; final List<Case> cases; final boolean cosOff; final CommandSender out;
        int idx = -1, waitLeft, pass, fail; Case cur; List<LivingEntity> dummies = new ArrayList<>(); final List<Double> before = new ArrayList<>(); final Location base;

        Runner(AzrathielModule mod, Player p, Vael v, BondData b, List<Case> cases, boolean cosOff, CommandSender out) {
            this.mod = mod; this.p = p; this.v = v; this.b = b; this.cases = cases; this.cosOff = cosOff; this.out = out;
            this.base = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(4));
        }
        void start() { mod.tasks.every(10, 5, n -> step()); }
        void log(String s) { out.sendMessage(mod.msg(s)); mod.plugin.getLogger().info("[selftest] " + s.replaceAll("<[^>]+>", "")); }

        boolean step() {
            if (!p.isOnline() || p.isDead()) { finish("aborted (player offline or dead)"); return false; }
            if (cur != null) { waitLeft -= 5; if (waitLeft > 0) return true; evaluate(); }
            idx++; if (idx >= cases.size()) { finish(null); return false; }
            cur = cases.get(idx); launch(); return true;
        }

        void launch() {
            for (LivingEntity d : dummies) if (d.isValid()) d.remove(); dummies.clear(); before.clear();
            int count = cur.ultimate ? 3 : 1;
            for (int i = 0; i < count; i++) { Location l = base.clone().add(i == 0 ? 0 : (i == 1 ? 3 : -3), 0, i == 0 ? 0 : 1.5); LivingEntity d = dummy(mod, l, cur.wait + 100); dummies.add(d); before.add(d.getHealth()); }
            b.cooldownReadyAt.remove(cur.key); v.essence.set(v.essence.max); mod.fx.begin();
            if (cur.ultimate) { String[] err = {null}; v.ultimate(true, s -> err[0] = s); if (err[0] != null) { log("<red>FAIL <white>" + cur.name + "<gray>: " + err[0]); fail++; cur = null; waitLeft = 0; } else waitLeft = cur.wait; return; }
            var o = new AbilityExecutor.Opts(); o.cosmetics = !cosOff; o.free = true; o.silent = true; o.targets = List.of(dummies.get(0));   // cooldown NOT bypassed: verifies cooldown handling
            var r = mod.executor.cast(v, cur.key, cur.spec, o);
            if (!r.ok()) { log("<red>FAIL <white>" + cur.name + "<gray>: " + r.reason()); fail++; cur = null; waitLeft = 0; return; }
            var o2 = new AbilityExecutor.Opts(); o2.free = true; o2.silent = true; o2.cosmetics = false;
            var again = mod.executor.cast(v, cur.key, cur.spec, o2);
            boolean cdOk = !again.ok() && again.reason().startsWith("cooldown"); if (!cdOk) log("<yellow>WARN <white>" + cur.name + "<gray>: a second cast was not refused by the cooldown");
            waitLeft = cur.wait;
        }

        void evaluate() {
            double lost = 0; int hit = 0; boolean attributed = true;
            for (int i = 0; i < dummies.size(); i++) { LivingEntity d = dummies.get(i); double l = before.get(i) - (d.isValid() ? d.getHealth() : 0); if (l > 0.01) hit++; lost += Math.max(0, l);
                if (d.isValid() && l > 0.01 && !(d.getLastDamageCause() instanceof EntityDamageByEntityEvent be && be.getDamager().equals(p))) attributed = false; }
            boolean ok = cur.ultimate ? hit >= 2 : hit >= 1; boolean ultState = !cur.ultimate || v.ultimate == null;
            if (ok && attributed && ultState) { pass++; log("<green>PASS <white>" + cur.name + "<gray>: dealt <white>" + String.format("%.1f", lost) + "<gray> to " + hit + " target(s), attributed to master" + (cur.ultimate ? ", multi-target OK" : "")); }
            else { fail++; log("<red>FAIL <white>" + cur.name + "<gray>: dealt " + String.format("%.1f", lost) + ", targets hit " + hit + ", attributed=" + attributed + (ultState ? "" : ", ultimate still running")); }
            cur = null;
        }

        void finish(String abort) {
            for (LivingEntity d : dummies) if (d.isValid()) d.remove();
            mod.testing = false;
            log((fail == 0 && abort == null ? "<green>" : "<red>") + "Self-test " + (abort != null ? abort : "complete") + ": " + pass + " passed, " + fail + " failed of " + cases.size());
        }
    }
}
