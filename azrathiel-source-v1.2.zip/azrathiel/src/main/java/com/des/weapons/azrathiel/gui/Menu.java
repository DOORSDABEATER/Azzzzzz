package com.des.weapons.azrathiel.gui;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Tiny GUI framework: a holder, a handler per slot, automatic background fill. All clicks are cancelled. */
public abstract class Menu implements InventoryHolder {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    protected final AzrathielModule mod; protected final Player p; protected Inventory inv; private final Map<Integer, Consumer<InventoryClickEvent>> handlers = new HashMap<>();

    protected Menu(AzrathielModule mod, Player p) { this.mod = mod; this.p = p; }
    protected abstract String title(); protected abstract int size(); protected abstract void build();

    public void open() { inv = Bukkit.createInventory(this, size(), MM.deserialize(title())); redraw(); p.openInventory(inv); }

    public void redraw() {
        inv.clear(); handlers.clear(); build();
        ItemStack pane = icon(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, pane);
    }

    protected void set(int slot, ItemStack it, Consumer<InventoryClickEvent> h) { if (slot >= 0 && slot < inv.getSize()) { inv.setItem(slot, it); if (h != null) handlers.put(slot, h); } }
    protected void set(int slot, ItemStack it) { set(slot, it, null); }
    protected void back(int slot, Supplier<Menu> to) { set(slot, icon(Material.ARROW, "<yellow>Back"), e -> to.get().open()); }
    protected BondData bond() { return mod.store.byOwner(p.getUniqueId()); }
    protected Vael vael() { return mod.vaels.of(p.getUniqueId()); }
    protected void result(String err) { if (err != null) p.sendMessage(mod.msg("<red>" + err)); }
    protected void changed() { BondData b = bond(); if (b != null) b.touch(); Vael v = vael(); if (v != null) v.syncPrefs(); redraw(); }

    public void click(InventoryClickEvent e) { Consumer<InventoryClickEvent> h = handlers.get(e.getSlot()); if (h != null) { try { h.accept(e); } catch (Throwable t) { p.sendMessage(mod.msg("<red>GUI error: " + t.getMessage())); mod.plugin.getLogger().warning("GUI error: " + t); } } }
    @Override public Inventory getInventory() { return inv; }

    public static ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m); ItemMeta im = it.getItemMeta(); im.displayName(MM.deserialize("<!italic>" + name));
        if (lore.length > 0) { List<Component> l = new ArrayList<>(); for (String s : lore) l.add(MM.deserialize("<!italic><gray>" + s)); im.lore(l); }
        im.addItemFlags(ItemFlag.HIDE_ATTRIBUTES); it.setItemMeta(im); return it;
    }
    public static String onOff(boolean b) { return b ? "<green>ON" : "<red>OFF"; }
    public static double step(InventoryClickEvent e, double base) { double s = e.isShiftClick() ? base * 5 : base; return e.isRightClick() ? -s : s; }
    public static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, Math.round(v * 100.0) / 100.0)); }

    public static final class Listener implements org.bukkit.event.Listener {
        @EventHandler public void onClick(InventoryClickEvent e) {
            if (e.getView().getTopInventory().getHolder() instanceof Menu m) { e.setCancelled(true); if (e.getClickedInventory() == e.getView().getTopInventory()) m.click(e); }
        }
        @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true); }
    }
}
