package com.des.weapons.azrathiel.core;

/**
 * Animation state machine. One looping BASE state (what the entity is doing) plus at most one ONE-SHOT (an action).
 * One-shots obey priority: a lower-priority request cannot interrupt a higher-priority one-shot, so conflicting
 * states never fight. Output parameters are smoothed every update, so every transition is continuous.
 * Pure logic: it NEVER controls damage; gameplay runs independently of whatever this does.
 */
public final class AnimationController {
    private AnimState base = AnimState.IDLE_FLOAT, shot = null;
    private float baseAge = 99f, shotTime = 0f;
    private final float[] cur = new float[P.COUNT], tgt = new float[P.COUNT];
    private float headYaw, headPitch, headYawT, headPitchT;
    public float intensity = 1.0f;       // animation intensity setting (scales arm/lean excursions)

    public AnimationController() { Poses.sample(AnimState.IDLE_FLOAT, 0, cur); System.arraycopy(cur, 0, tgt, 0, cur.length); }

    /** Set the continuous state. Flicker guard: a lower-priority base cannot replace the current one for 0.35s. */
    public void setBase(AnimState s) {
        if (s == base) return;
        if (!s.loops()) { play(s); return; }
        if (baseAge < 0.35f && s.priority <= base.priority) return;
        base = s; baseAge = 0;
    }

    /** Start a one-shot. Returns false if a higher-priority one-shot is currently playing. */
    public boolean play(AnimState s) {
        if (s.loops()) { setBase(s); return true; }
        if (shot != null && shotTime < shot.duration && shot.priority > s.priority) return false;
        shot = s; shotTime = 0; return true;
    }

    public void clearShot() { shot = null; }
    public AnimState base() { return base; }
    public AnimState effective() { return shot != null ? shot : base; }
    public boolean shotActive() { return shot != null; }
    public void look(float yawDeg, float pitchDeg) { headYawT = Math.max(-75, Math.min(75, yawDeg)); headPitchT = Math.max(-40, Math.min(40, pitchDeg)); }
    public float get(int i) { return cur[i]; }
    public float headYaw() { return headYaw; }
    public float headPitch() { return headPitch; }

    public void update(float dt) {
        baseAge += dt;
        AnimState eff = base;
        if (shot != null) { shotTime += dt; if (shotTime >= shot.duration) { shot = null; } else eff = shot; }
        float t = eff == shot && shot != null ? shotTime / shot.duration : 0f;
        Poses.sample(eff, t, tgt);
        float k = 1f - (float) Math.exp(-dt * eff.rate);
        for (int i = 0; i < cur.length; i++) {
            float goal = tgt[i];
            if (i == P.ARM_RAISE || i == P.ARM_RAISE + 1 || i == P.ARM_RAISE + 2 || i == P.ARM_RAISE + 3 || i == P.LEAN) goal *= intensity;
            cur[i] += (goal - cur[i]) * k;
        }
        float hk = 1f - (float) Math.exp(-dt * 7f);
        headYaw += (headYawT - headYaw) * hk; headPitch += (headPitchT - headPitch) * hk;
    }
}
