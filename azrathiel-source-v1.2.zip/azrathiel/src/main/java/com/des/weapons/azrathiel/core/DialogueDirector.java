package com.des.weapons.azrathiel.core;

import java.util.*;
import java.util.random.RandomGenerator;

/**
 * Pure dialogue brain: eligibility, priority/interruption, cooldowns, recent-line tracking, personality weighting, history.
 * Time is injected so it is fully unit-testable. It NEVER blocks or delays gameplay: callers ask, get a line or nothing.
 */
public final class DialogueDirector {
    public static final class Prefs {
        public boolean silent;
        public double frequency = 1.0;       // 0..1 global chatter level
        public double customMul = 1.0;       // used by Personality.CUSTOM
        public Personality personality = Personality.LOYAL;
        public final Set<Category> disabled = EnumSet.noneOf(Category.class);
    }

    public record Request(Category cat, Eidolon eidolon, Form form, Set<Cond> conds, String sub, String trigger, boolean force) {
        public static Request of(Category c, Form f) { return new Request(c, null, f, EnumSet.noneOf(Cond.class), null, null, false); }
        public Request eid(Eidolon e) { return new Request(cat, e, form, conds, sub, trigger, force); }
        public Request sub(String s) { return new Request(cat, eidolon, form, conds, s, trigger, force); }
        public Request conds(Set<Cond> c) { return new Request(cat, eidolon, form, c, sub, trigger, force); }
        public Request trigger(String t) { return new Request(cat, eidolon, form, conds, sub, t, force); }
        public Request forced() { return new Request(cat, eidolon, form, conds, sub, trigger, true); }
    }

    public record Spoken(VoiceLine line, long atMs) {}

    private static final int RECENT_MAX = 40, HISTORY_MAX = 60;
    private final VoiceLibrary lib; private final RandomGenerator rng; private final Prefs prefs;
    private final Map<Category, Long> catReady = new EnumMap<>(Category.class);
    private final Map<Eidolon, Long> eidReady = new EnumMap<>(Eidolon.class);
    private final ArrayDeque<String> recent = new ArrayDeque<>();
    private final ArrayDeque<Spoken> history = new ArrayDeque<>();
    private long speakingUntil; private int speakingPriority;
    public long eidolonCooldownMs = 6000;

    public DialogueDirector(VoiceLibrary lib, Prefs prefs, RandomGenerator rng) { this.lib = lib; this.prefs = prefs; this.rng = rng; }

    public Prefs prefs() { return prefs; }
    public boolean isSpeaking(long now) { return now < speakingUntil; }
    public List<Spoken> history() { return List.copyOf(history); }
    public void reset() { speakingUntil = 0; speakingPriority = 0; }   // e.g. on dismiss: nothing may be queued or spoken

    public Optional<VoiceLine> request(Request r, long now) {
        if (prefs.silent || prefs.disabled.contains(r.cat())) return Optional.empty();
        boolean busy = now < speakingUntil;
        if (busy && !r.force() && r.cat().priority <= speakingPriority) return Optional.empty();   // never talk over equal/higher priority
        if (!r.force()) {
            if (now < catReady.getOrDefault(r.cat(), 0L)) return Optional.empty();
            if (r.eidolon() != null && now < eidReady.getOrDefault(r.eidolon(), 0L)) return Optional.empty();
            if (!r.cat().critical) {
                double p = Math.min(1.0, prefs.frequency * prefs.personality.frequency(r.cat(), prefs.customMul));
                if (rng.nextDouble() > p) return Optional.empty();
            } else if (prefs.personality == Personality.SILENT && rng.nextDouble() > 0.9) return Optional.empty();
            if (r.cat() == Category.SECRET && rng.nextDouble() > 0.4) return Optional.empty();   // secrets stay rare even when triggered
        }
        List<VoiceLine> pool = eligible(r);
        if (pool.isEmpty()) return Optional.empty();
        List<VoiceLine> fresh = new ArrayList<>();
        for (VoiceLine v : pool) if (!recent.contains(v.id())) fresh.add(v);
        if (fresh.isEmpty()) { for (VoiceLine v : pool) recent.remove(v.id()); fresh = pool; }   // shuffle-bag: pool exhausted, restart
        VoiceLine pick = weighted(fresh);
        recent.addLast(pick.id()); while (recent.size() > RECENT_MAX) recent.removeFirst();
        double fq = Math.max(0.3, prefs.frequency);
        catReady.put(r.cat(), now + (long) (r.cat().cooldownMs / fq));
        if (r.eidolon() != null) eidReady.put(r.eidolon(), now + eidolonCooldownMs);
        speakingUntil = now + 900 + pick.text().length() * 62L; speakingPriority = r.cat().priority;
        history.addLast(new Spoken(pick, now)); while (history.size() > HISTORY_MAX) history.removeFirst();
        return Optional.of(pick);
    }

    List<VoiceLine> eligible(Request r) {
        List<VoiceLine> out = new ArrayList<>(), subMatch = new ArrayList<>();
        for (VoiceLine v : lib.of(r.cat())) {
            if (!v.formOk(r.form())) continue;
            if (!r.conds().containsAll(v.conds())) continue;
            if (r.eidolon() != null) { if (v.eidolon() != null && v.eidolon() != r.eidolon()) continue; }
            else if (v.eidolon() != null && r.cat() != Category.EIDOLON) continue;
            if (r.cat() == Category.SECRET) { if (v.trigger() == null || !v.trigger().equals(r.trigger())) continue; }
            if (r.sub() != null && r.sub().equals(v.sub())) subMatch.add(v);
            if (v.sub() == null) out.add(v);
        }
        if (r.sub() != null && !subMatch.isEmpty()) return subMatch;      // exact action subtype wins
        if (r.eidolon() != null) {                                            // prefer lines owned by that Eidolon
            List<VoiceLine> own = new ArrayList<>(); for (VoiceLine v : out) if (v.eidolon() == r.eidolon()) own.add(v);
            if (!own.isEmpty()) return own;
        }
        return out;
    }

    private VoiceLine weighted(List<VoiceLine> pool) {
        double[] w = new double[pool.size()]; double sum = 0;
        for (int i = 0; i < w.length; i++) {
            VoiceLine v = pool.get(i); double x = 1.0;
            if (!v.affinity().isEmpty()) x = v.affinity().contains(prefs.personality) ? 2.0 : 0.35;
            if (!v.conds().isEmpty()) x *= 2.5;                                // situational lines beat generic ones
            w[i] = x; sum += x;
        }
        double t = rng.nextDouble() * sum;
        for (int i = 0; i < w.length; i++) { t -= w[i]; if (t <= 0) return pool.get(i); }
        return pool.get(pool.size() - 1);
    }
}
