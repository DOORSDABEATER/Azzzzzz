package com.des.weapons.azrathiel.core;

import java.util.EnumSet;
import java.util.Set;

/** One authored line. sub = optional action subtype (summon, dismiss, follow, kill...). trigger = secret trigger key. */
public record VoiceLine(String id, Category category, String sub, Set<Form> forms, Eidolon eidolon,
                        Set<Personality> affinity, Set<Cond> conds, String trigger, String text) {

    public boolean formOk(Form f) { return forms.isEmpty() || forms.contains(f); }
    public String soundName() { return id.replace('.', '_'); }

    public static VoiceLine empty(String id) {
        return new VoiceLine(id, Category.IDLE, null, EnumSet.noneOf(Form.class), null,
                EnumSet.noneOf(Personality.class), EnumSet.noneOf(Cond.class), null, "...");
    }
}
