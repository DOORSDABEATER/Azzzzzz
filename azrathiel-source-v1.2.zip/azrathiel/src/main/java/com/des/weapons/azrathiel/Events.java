package com.des.weapons.azrathiel;

import com.des.weapons.azrathiel.combat.Targeting;
import com.des.weapons.azrathiel.core.Category;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import com.des.weapons.azrathiel.gui.Menus;
import com.des.weapons.azrathiel.model.RigModel;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.weather.LightningStrikeEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.HashSet;

public final class Events implements Listener {
    private final AzrathielModule mod; private final Map<UUID, Long> interceptReady = new HashMap<>();
    public Events(AzrathielModule mod) { this.mod = mod; }

    private void err(Player p, String e) { if (e != null) p.sendActionBar(mod.msg("<red>" + e)); }

    // ------------------------------------------------------------------------------------------------ weapon item
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return; ItemStack it = e.getItem(); if (!mod.weapon.is(it)) return; Player p = e.getPlayer(); Action a = e.getAction();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK, left = a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK;
        if (!right && !left) return;
        if (a == Action.RIGHT_CLICK_BLOCK && !p.isSneaking()) { Block b = e.getClickedBlock(); if (b != null && b.getType().isInteractable()) return; }   // never break chests, doors, etc.
        e.setCancelled(true);
        BondData b = mod.actions.bondForItem(p, it); if (b == null) return;
        if (right) { if (p.isSneaking()) Menus.control(mod, p).open(); else err(p, mod.actions.toggleSummon(p)); }
        else { if (p.isSneaking()) err(p, mod.actions.cycle(p, 1)); else err(p, mod.actions.castSelected(p)); }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer(); if (!mod.weapon.is(e.getMainHandItem()) && !mod.weapon.is(e.getOffHandItem())) return;
        e.setCancelled(true); BondData b = mod.actions.bond(p); if (b == null) return;
        err(p, p.isSneaking() ? mod.actions.ultimate(p) : mod.actions.release(p, null));
    }

    // ------------------------------------------------------------------------------------------------ lifecycle
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer(); BondData b = mod.store.byOwner(p.getUniqueId()); if (b == null) return; b.ownerName = p.getName(); b.touch();
        if (b.summoned) mod.tasks.later(30, () -> { if (p.isOnline() && mod.vaels.of(p.getUniqueId()) == null && mod.vaels.hasWeapon(p, b)) mod.vaels.summon(p, b); });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer(); BondData b = mod.store.byOwner(p.getUniqueId()); mod.vaels.release(p.getUniqueId()); mod.adapt.forget(p.getUniqueId()); interceptReady.remove(p.getUniqueId());
        if (b != null) mod.store.saveNow(b);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) { resnap(e.getPlayer()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { resnap(e.getPlayer()); }
    private void resnap(Player p) { mod.tasks.later(2, () -> { Vael v = mod.vaels.of(p.getUniqueId()); if (v != null && p.isOnline() && !p.isDead() && v.mode != Vael.Mode.GUARDIAN && v.mode != Vael.Mode.EXHAUSTED && v.mode != Vael.Mode.DOWN) v.snap(v.formationSlot(p)); }); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) { Vael v = mod.vaels.of(e.getPlayer().getUniqueId()); if (v != null) v.onMasterDeath(e.getPlayer().getLocation()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) { Player p = e.getPlayer(); mod.tasks.later(3, () -> { Vael v = mod.vaels.of(p.getUniqueId()); if (v != null && p.isOnline()) v.onMasterRespawn(); }); }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        Set<UUID> live = new HashSet<>(); for (Vael v : mod.vaels.all()) live.addAll(v.rigIds());
        for (Entity en : e.getEntities()) if (RigModel.isRigEntity(en) && !live.contains(en.getUniqueId())) en.remove();    // no duplicate or orphan rigs after chunk reloads
    }

    // ------------------------------------------------------------------------------------------------ protection
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) { if (e.getEntity() instanceof Player p && mod.adapt.isImmune(p.getUniqueId(), e.getCause().name())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageSeen(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p) || mod.store.byOwner(p.getUniqueId()) == null) return;
        mod.adapt.record(p, e); Vael v = mod.vaels.of(p.getUniqueId()); if (v != null) v.onMasterHurt(e.getFinalDamage(), p.getHealth() - e.getFinalDamage());
    }

    /** Real interception: a hostile projectile aimed at the master is stopped by VAELZARION (costs essence, has a cooldown). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectile(ProjectileHitEvent e) {
        if (!(e.getHitEntity() instanceof Player p) || !mod.cfg.interceptProjectiles) return;
        Vael v = mod.vaels.of(p.getUniqueId()); if (v == null || !v.released() || !v.bond.interceptProjectiles || v.mode == Vael.Mode.GUARDIAN || v.mode == Vael.Mode.EXHAUSTED || v.mode == Vael.Mode.DOWN) return;
        Projectile pr = e.getEntity(); if (pr.getShooter() instanceof Entity s && mod.targeting.isAlly(p, s)) return;
        long now = System.currentTimeMillis(); if (now < interceptReady.getOrDefault(p.getUniqueId(), 0L) || !v.essence.consume(mod.cfg.interceptCost)) return;
        interceptReady.put(p.getUniqueId(), now + mod.cfg.interceptCooldownMs);
        e.setCancelled(true); pr.remove(); v.intercept(pr.getLocation());
        mod.fx.begin(); mod.fx.safe(() -> { mod.vfx.flare(pr.getLocation(), 0xBFD4FF, 1.4f, 8, 0); mod.vfx.ring(pr.getLocation(), 0x2E6FFF, 0.2f, 1.2f, 8, 0, 0f); mod.fx.sound(pr.getLocation(), "intercept", 1f, 1f); mod.fx.spawn(pr.getLocation(), org.bukkit.Particle.END_ROD, 12, 0.2, 0.2, 0.2, 0.05); });
        v.say(Category.PROTECT, null, null, null, false);
    }

    // ------------------------------------------------------------------------------------------------ progression + secrets
    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent e) {
        Player k = e.getEntity().getKiller(); if (k == null || e.getEntity() instanceof Player && e.getEntity().equals(k)) return; BondData b = mod.store.byOwner(k.getUniqueId()); if (b == null) return;
        b.kills++; if (Targeting.isBoss(e.getEntity())) b.bossKills++; b.touch(); mod.applyProgression(b, k);
        Vael v = mod.vaels.of(k.getUniqueId()); if (v != null) { LivingEntity le = e.getEntity(); v.onKill(le); }
    }
    @EventHandler public void onBed(PlayerBedEnterEvent e) { if (e.getBedEnterResult() == PlayerBedEnterEvent.BedEnterResult.OK) { Vael v = mod.vaels.of(e.getPlayer().getUniqueId()); if (v != null) v.say(Category.SECRET, null, null, "sleep", true); } }
    @EventHandler public void onTotem(EntityResurrectEvent e) { if (!e.isCancelled() && e.getEntity() instanceof Player p) { Vael v = mod.vaels.of(p.getUniqueId()); if (v != null) mod.tasks.later(10, () -> v.say(Category.SECRET, null, null, "totem", true)); } }
    @EventHandler public void onLightning(LightningStrikeEvent e) {
        for (Player p : e.getWorld().getPlayers()) if (p.getLocation().distanceSquared(e.getLightning().getLocation()) < 400) { Vael v = mod.vaels.of(p.getUniqueId()); if (v != null) v.say(Category.SECRET, null, null, "lightning", true); }
    }
}
