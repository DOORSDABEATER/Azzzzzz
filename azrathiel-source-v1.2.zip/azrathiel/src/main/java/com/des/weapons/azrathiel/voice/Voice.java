package com.des.weapons.azrathiel.voice;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Voice playback. Order of concerns: DialogueDirector decides WHAT (pure, tested), this class decides HOW:
 * subtitles always; recorded audio (primary + subtle Eidolon layers + echo) when recordings are installed;
 * otherwise a vanilla placeholder cue for important lines. It never blocks or delays gameplay.
 */
public final class Voice {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final AzrathielModule mod; private final Map<UUID, Long> lastSubtitle = new HashMap<>();
    public Voice(AzrathielModule mod) { this.mod = mod; }

    public boolean subtitleRecent(Player p) { return System.currentTimeMillis() - lastSubtitle.getOrDefault(p.getUniqueId(), 0L) < 2800; }

    public void say(Vael v, Category cat, Eidolon eid, String sub, String trigger, boolean force) {
        Player m = v.master(); if (m == null || !m.isOnline()) return;
        var req = new DialogueDirector.Request(cat, eid, v.form(), conds(m, v), sub, trigger, force);
        v.director.request(req, System.currentTimeMillis()).ifPresent(line -> play(v, line, eid != null ? eid : line.eidolon()));
    }

    /** Plays an exact line (voice preview). */
    public void sayLine(Vael v, VoiceLine line) { play(v, line, line.eidolon()); }

    private Set<Cond> conds(Player m, Vael v) {
        Set<Cond> c = EnumSet.noneOf(Cond.class); World w = m.getWorld();
        double hp = m.getHealth() / Math.max(1, m.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) == null ? 20 : m.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        if (hp < 0.4) c.add(Cond.MASTER_LOW); if (hp < 0.2) c.add(Cond.MASTER_CRIT);
        if (w.getEnvironment() == World.Environment.NORMAL) { long t = w.getTime(); if (t >= 13000 && t <= 23000) c.add(Cond.NIGHT); if (w.hasStorm()) c.add(Cond.RAIN);
            if (m.getLocation().getY() - w.getHighestBlockYAt(m.getLocation()) > 25) c.add(Cond.HIGH_UP); }
        if (w.getEnvironment() == World.Environment.NETHER) c.add(Cond.NETHER);
        if (w.getEnvironment() == World.Environment.THE_END) c.add(Cond.END);
        if (m.getEyeLocation().getBlock().getType() == org.bukkit.Material.WATER) c.add(Cond.WATER);
        if (v.essence.fraction() < 0.2) c.add(Cond.LOW_ESSENCE);
        for (Player o : m.getWorld().getPlayers()) if (!o.equals(m) && o.getLocation().distanceSquared(m.getLocation()) < 144) { c.add(Cond.ALLY_NEARBY); break; }
        return c;
    }

    private void play(Vael v, VoiceLine line, Eidolon speaker) {
        Player m = v.master(); if (m == null || !m.isOnline()) return; BondData b = v.bond;
        subtitle(m, v, line, speaker);
        double vol = b.voiceVolume * b.formVolume.getOrDefault(v.form(), 1.0) * (speaker != null ? b.eidolonVolume.getOrDefault(speaker, 1.0) : 1.0);
        if (vol <= 0.001) return;
        List<Player> listeners = new ArrayList<>(List.of(m));
        if (mod.cfg.voiceBroadcast) for (Player o : m.getWorld().getPlayers()) if (!o.equals(m) && o.getLocation().distanceSquared(v.location()) < 400) listeners.add(o);
        Location at = v.location(); float pitch = (float) Math.max(0.5, Math.min(2.0, b.pitch));
        try {
            if (mod.cfg.recordingsInstalled) recorded(v, line, speaker, listeners, at, (float) vol, pitch);
            else placeholder(line, listeners, at, (float) vol, pitch);
        } catch (Throwable t) { if (mod.debug) mod.plugin.getLogger().warning("voice audio failed (ignored): " + t); }
    }

    private void subtitle(Player m, Vael v, VoiceLine line, Eidolon speaker) {
        String mode = v.bond.subtitleMode; if (mode.equals("OFF")) return;
        String color = String.format("#%06X", (speaker != null ? speaker.rgb : Vael.themeColor(v.bond)) & 0xFFFFFF);
        String name = speaker != null ? speaker.display.toUpperCase(Locale.ROOT) : "VAELZARION";
        String body;
        if (line.category() == Category.APOCALYPSE && line.forms().contains(Form.APOCALYPSE)) {     // eightfold treatment: each word carries one of the eight authorities
            StringBuilder sb = new StringBuilder(); int i = 0;
            for (String w : line.text().split(" ")) { sb.append(String.format("<#%06X>%s</#%06X> ", Eidolon.values()[i % 8].rgb, esc(w), Eidolon.values()[i % 8].rgb)); i++; }
            body = sb.toString().trim();
        } else body = "<white>" + esc(line.text());
        Component c = MM.deserialize("<" + color + ">" + name + "</" + color + "> <dark_gray>»</dark_gray> " + body);
        if (mode.equals("ACTIONBAR") || mode.equals("BOTH")) { m.sendActionBar(c); lastSubtitle.put(m.getUniqueId(), System.currentTimeMillis()); }
        if (mode.equals("CHAT") || mode.equals("BOTH")) m.sendMessage(c);
    }
    private static String esc(String s) { return s.replace("<", "").replace(">", ""); }

    /** Real recordings: primary voice + synchronized Eidolon layers (kept beneath the primary) + echo approximation. */
    private void recorded(Vael v, VoiceLine line, Eidolon speaker, List<Player> ls, Location at, float vol, float pitch) {
        String id = line.soundName(); BondData b = v.bond;
        for (Player p : ls) p.playSound(at, "azrathiel:voice." + id, SoundCategory.VOICE, vol, pitch);
        boolean ultimate = line.category() == Category.APOCALYPSE;
        if (v.form() != Form.DORMANT && b.layerIntensity > 0.01) {
            double gain = b.layerIntensity * (ultimate ? 1.0 : v.inCombat() ? 0.55 : 0.25), step = 2 * Math.PI / 8; int n = 0;
            for (Eidolon e : Eidolon.values()) {
                if (!ultimate && !(b.enabled.contains(e) && mod.unlocked(b, e))) continue;
                float lv = (float) (vol * gain * b.eidolonVolume.getOrDefault(e, 1.0) * 0.35); if (lv < 0.01f) continue;
                Location pos = at.clone().add(Math.cos(step * e.ordinal()) * 2.5, 0, Math.sin(step * e.ordinal()) * 2.5);   // spatial: layers sit around the entity
                float lp = pitch * (ultimate ? 0.92f + 0.02f * e.ordinal() : 1f); final int delay = n++ % 2;
                mod.tasks.later(delay, () -> { for (Player p : ls) p.playSound(pos, "azrathiel:voice.layer." + e.id() + "." + id, SoundCategory.VOICE, lv, lp); });
            }
        }
        if (b.reverb > 0.05) {
            mod.tasks.later(4, () -> { for (Player p : ls) p.playSound(at, "azrathiel:voice." + id, SoundCategory.VOICE, (float) (vol * 0.22 * b.reverb), pitch * 0.98f); });
            mod.tasks.later(9, () -> { for (Player p : ls) p.playSound(at, "azrathiel:voice." + id, SoundCategory.VOICE, (float) (vol * 0.10 * b.reverb), pitch * 0.96f); });
        }
    }

    /** No recordings yet: subtitles carry the dialogue; important lines also get a low vanilla cue. NOT a voice recording. */
    private void placeholder(VoiceLine line, List<Player> ls, Location at, float vol, float pitch) {
        if (line.category().priority < 45) return;
        boolean ult = line.category() == Category.APOCALYPSE; String key = ult ? "minecraft:entity.ender_dragon.growl" : mod.cfg.placeholderSound;
        for (Player p : ls) p.playSound(at, key, SoundCategory.VOICE, vol * (ult ? 1.0f : 0.5f), pitch * (ult ? 0.5f : 0.5f));
    }
}
