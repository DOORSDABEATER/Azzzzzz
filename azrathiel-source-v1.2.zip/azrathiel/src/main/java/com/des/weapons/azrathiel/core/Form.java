package com.des.weapons.azrathiel.core;

public enum Form {
    DORMANT("Form I - Dormant", 'D', 1.0f),
    RELEASED("Form II - Released", 'R', 1.75f),
    APOCALYPSE("Form III - Eightfold Apocalypse", 'A', 2.6f);

    public final String title; public final char tag; public final float scale;
    Form(String title, char tag, float scale) { this.title = title; this.tag = tag; this.scale = scale; }
    public boolean combatCapable() { return this != DORMANT; }
    public static Form ofTag(char c) { for (Form f : values()) if (f.tag == c) return f; return null; }
}
