package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.*;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Target acquisition and filtering. Decides who counts as an enemy; everything else (master, pets, villagers, NPCs...) is safe. */
public final class Targeting {
    private static final Set<String> NEVER = Set.of("VILLAGER", "WANDERING_TRADER", "IRON_GOLEM", "SNOW_GOLEM", "ALLAY", "COPPER_GOLEM", "ARMOR_STAND", "MANNEQUIN");
    private static final Set<String> RANGED = Set.of("SKELETON", "STRAY", "BOGGED", "PILLAGER", "BLAZE", "GHAST", "WITCH", "BREEZE", "SHULKER", "EVOKER", "ILLUSIONER", "WITHER", "GUARDIAN", "ELDER_GUARDIAN");
    private final AzrathielModule mod;
    public Targeting(AzrathielModule mod) { this.mod = mod; }

    public static boolean isBoss(LivingEntity e) {
        if (e instanceof Boss || e instanceof Warden) return true;
        String n = e.getType().name(); if (n.equals("ELDER_GUARDIAN") || n.equals("WITHER") || n.equals("ENDER_DRAGON")) return true;
        return maxHealth(e) >= 300;
    }
    public static double maxHealth(LivingEntity e) { try { var a = e.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH); return a == null ? e.getHealth() : a.getValue(); } catch (Throwable t) { return Math.max(20, e.getHealth()); } }
    public static boolean isRanged(LivingEntity e) { return RANGED.contains(e.getType().name()); }
    public static boolean isFlying(LivingEntity e) { return e instanceof Flying || e instanceof Phantom || e instanceof Vex || e instanceof Blaze || e instanceof EnderDragon || e instanceof Bat; }

    public boolean valid(Player master, Entity e) {
        if (!(e instanceof LivingEntity le) || le.isDead() || !le.isValid() || e.equals(master)) return false;
        if (NEVER.contains(e.getType().name()) || e.hasMetadata("NPC") || le.isInvulnerable()) return false;
        if (e instanceof Tameable t && t.isTamed()) return false;
        if (e instanceof Player p) return pvpAllowed(master, p);
        if (e instanceof Enemy || e instanceof Monster) return true;
        return e instanceof Mob m && master.equals(m.getTarget());
    }

    /** Manual casts: whatever the master deliberately AIMS at is a valid target (still never pets, villagers, NPCs, invulnerables; players follow the PvP rule). */
    public boolean validManual(Player master, Entity e) {
        if (valid(master, e)) return true;
        if (!mod.cfg.manualAimAnyMob) return false;
        if (!(e instanceof LivingEntity le) || le.isDead() || !le.isValid() || e.equals(master)) return false;
        String n = e.getType().name();
        if (n.equals("ARMOR_STAND")) return mod.cfg.hitArmorStands;
        if (NEVER.contains(n) || e.hasMetadata("NPC") || le.isInvulnerable()) return false;
        if (e instanceof Tameable t && t.isTamed()) return false;
        if (e instanceof Player p) return pvpAllowed(master, p);
        return true;
    }

    /** The living entity under the master's crosshair (ray-traced), or null. */
    public LivingEntity aimed(Player master, double range) {
        if (master == null || master.isDead() || !master.isOnline()) return null; Location eye = master.getEyeLocation();
        org.bukkit.util.RayTraceResult r = eye.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.35, en -> en instanceof LivingEntity && !en.equals(master) && validManual(master, en));
        return r != null && r.getHitEntity() instanceof LivingEntity le ? le : null;
    }

    /** Human-readable reason an entity is / is not a target. Used by /azrathiel admin trace. */
    public String explain(Player master, Entity e) {
        if (e.equals(master)) return "that is you";
        if (!(e instanceof LivingEntity le)) return "not a living entity";
        if (le.isDead() || !le.isValid()) return "dead or invalid";
        String n = e.getType().name();
        if (n.equals("ARMOR_STAND")) return mod.cfg.hitArmorStands ? "armor stand: hit only when aimed at (combat.hit-armor-stands)" : "armor stands are protected (set combat.hit-armor-stands: true to test on them)";
        if (NEVER.contains(n)) return "protected type " + n + " (never targeted)";
        if (e.hasMetadata("NPC")) return "NPC (Citizens-style metadata)";
        if (le.isInvulnerable()) return "entity is invulnerable";
        if (e instanceof Tameable t && t.isTamed()) return "tamed pet";
        if (e instanceof Player p) return pvpAllowed(master, p) ? "OK player (pvp rule allows)" : "player: pvp mode " + mod.cfg.pvpMode + " (needs a recent attack on you / not same team / survival)";
        if (e instanceof Enemy || e instanceof Monster) return "OK hostile (area, aimed and autonomous)";
        if (e instanceof Mob m && master.equals(m.getTarget())) return "OK (it is targeting you)";
        return mod.cfg.manualAimAnyMob ? "passive/neutral mob: only hit when you AIM at it (manual casts); area hits and the AI ignore it" : "passive/neutral mob: never targeted (combat.manual-aim-any-mob is false)";
    }

    public boolean pvpAllowed(Player master, Player p) {
        String mode = mod.cfg.pvpMode; if (mode.equals("OFF")) return false;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR || p.isDead()) return false;
        Team a = master.getScoreboard().getEntryTeam(master.getName()), b = p.getScoreboard().getEntryTeam(p.getName());
        if (a != null && a.equals(b)) return false;
        return mode.equals("ALL") || mod.adapt.recentPvpAttacker(master.getUniqueId(), p.getUniqueId(), 10_000);
    }

    /** Enemies within r of a point. Capped by performance.target-search-cap. */
    public List<LivingEntity> around(Player master, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>(); if (c.getWorld() == null) return out;
        for (Entity e : c.getWorld().getNearbyEntities(c, r, r, r)) { if (valid(master, e) && e.getLocation().distanceSquared(c) <= r * r) { out.add((LivingEntity) e); if (out.size() >= mod.cfg.targetCap) break; } }
        out.sort(Comparator.comparingDouble(x -> x.getLocation().distanceSquared(c))); return out;
    }

    public LivingEntity nearestInCone(Player master, Location from, Vector dir, double range, double minDot) {
        LivingEntity best = null; double bd = Double.MAX_VALUE; Vector d = dir.clone().normalize();
        for (LivingEntity e : around(master, from, range)) {
            Vector to = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(from.toVector()); double dist = to.length(); if (dist < 0.01) continue;
            if (to.normalize().dot(d) >= minDot && dist < bd) { bd = dist; best = e; }
        }
        return best;
    }

    public boolean isAlly(Player master, Entity e) {
        if (e.equals(master)) return true;
        if (e instanceof Tameable t && t.isTamed() && t.getOwner() != null && t.getOwner().getUniqueId().equals(master.getUniqueId())) return true;
        if (e instanceof Player p) { Team a = master.getScoreboard().getEntryTeam(master.getName()), b = p.getScoreboard().getEntryTeam(p.getName()); return a != null && a.equals(b); }
        return false;
    }
}
