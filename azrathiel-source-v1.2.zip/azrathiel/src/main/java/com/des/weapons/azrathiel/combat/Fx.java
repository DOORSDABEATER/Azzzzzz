package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import org.bukkit.*;
import org.bukkit.util.Vector;

import java.util.Map;

/** All cosmetics. Everything here is best-effort: a failure is swallowed so it can never break gameplay. */
public final class Fx {
    /** Pack sound events (assets/azrathiel/sounds.json) and their vanilla fallbacks. */
    private static final Map<String, String> FALLBACK = Map.ofEntries(
            Map.entry("cast.vigor", "minecraft:entity.iron_golem.damage"), Map.entry("cast.abyss", "minecraft:entity.enderman.teleport"),
            Map.entry("cast.fate", "minecraft:block.amethyst_block.resonate"), Map.entry("cast.ruin", "minecraft:entity.wither.shoot"),
            Map.entry("cast.aegis", "minecraft:block.beacon.activate"), Map.entry("cast.evolution", "minecraft:block.respawn_anchor.charge"),
            Map.entry("cast.wraith", "minecraft:particle.soul_escape"), Map.entry("cast.dominion", "minecraft:entity.ender_dragon.growl"),
            Map.entry("transform", "minecraft:entity.wither.spawn"), Map.entry("release", "minecraft:block.beacon.power_select"),
            Map.entry("dismiss", "minecraft:block.beacon.deactivate"), Map.entry("summon", "minecraft:block.beacon.activate"),
            Map.entry("ultimate.awaken", "minecraft:entity.ender_dragon.growl"), Map.entry("ultimate.charge", "minecraft:entity.warden.sonic_charge"),
            Map.entry("ultimate.main", "minecraft:entity.warden.sonic_boom"), Map.entry("ultimate.impact", "minecraft:entity.generic.explode"),
            Map.entry("lastguardian", "minecraft:entity.warden.roar"), Map.entry("intercept", "minecraft:item.shield.block"),
            Map.entry("hit", "minecraft:entity.player.attack.strong"), Map.entry("combo", "minecraft:block.end_portal.spawn"));

    private final AzrathielModule mod; private int budget;
    public Fx(AzrathielModule mod) { this.mod = mod; }

    public void begin() { budget = mod.cfg.maxParticlesPerCast; if (mod.vfx != null) mod.vfx.begin(); }
    private boolean on() { return mod.cfg.particles && budget > 0; }

    private int reported;
    /** Cosmetics must never break gameplay - but they must never fail SILENTLY either: the first failures are always logged. */
    public void safe(Runnable r) {
        try { r.run(); } catch (Throwable t) {
            if (reported < 5 || mod.debug) { reported++; mod.plugin.getLogger().warning("effect failed (gameplay unaffected) [" + reported + "]: " + t + (t.getStackTrace().length > 0 ? " at " + t.getStackTrace()[0] : "")); }
        }
    }

    public void sound(Location l, String event, float vol, float pitch) {
        safe(() -> { String key = mod.cfg.usePackSoundEvents ? "azrathiel:" + event : FALLBACK.getOrDefault(event, "minecraft:block.note_block.bass");
            l.getWorld().playSound(l, key, SoundCategory.MASTER, vol, pitch); });
    }

    public void spawn(Location l, Particle p, int n, double dx, double dy, double dz, double speed) {
        if (!on()) return; safe(() -> { int c = Math.min(n, budget); budget -= c; l.getWorld().spawnParticle(p, l, c, dx, dy, dz, speed); });
    }
    public void dust(Location l, int rgb, float size, int n, double spread) {
        if (!on()) return; safe(() -> { int c = Math.min(n, budget); budget -= c;
            l.getWorld().spawnParticle(Particle.DUST, l, c, spread, spread, spread, 0, new Particle.DustOptions(Color.fromRGB(rgb & 0xFFFFFF), size)); });
    }
    public void ring(Location c, double r, int rgb, int points, double y) {
        if (!on()) return;
        for (int i = 0; i < points; i++) { double a = 2 * Math.PI * i / points; dust(c.clone().add(Math.cos(a) * r, y, Math.sin(a) * r), rgb, 1.2f, 1, 0.02); }
    }
    public void line(Location a, Location b, int rgb, double step) {
        if (!on() || a.getWorld() != b.getWorld()) return;
        Vector d = b.toVector().subtract(a.toVector()); double len = d.length(); if (len < 0.01) return; d.normalize().multiply(step);
        Location p = a.clone(); for (double t = 0; t < len; t += step) { dust(p, rgb, 1.0f, 1, 0.0); p.add(d); }
    }
    public void sphere(Location c, double r, int rgb, int points) {
        if (!on()) return; double ga = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < points; i++) { double y = 1 - 2.0 * i / Math.max(1, points - 1), rr = Math.sqrt(Math.max(0, 1 - y * y)), th = ga * i;
            dust(c.clone().add(Math.cos(th) * rr * r, y * r, Math.sin(th) * rr * r), rgb, 1.1f, 1, 0.0); }
    }
    public void shockwave(Location c, double maxR, int rgb, Particle edge) {
        for (int k = 1; k <= 3; k++) { final double r = maxR * k / 3.0; mod.tasks.later(k * 2L, () -> { ring(c, r, rgb, (int) Math.min(48, 10 + r * 5), 0.15); spawn(c, edge, 4, r * 0.4, 0.1, r * 0.4, 0.02); }); }
    }
}
