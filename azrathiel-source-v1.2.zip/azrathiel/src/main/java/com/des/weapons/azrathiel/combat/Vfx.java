package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Visual effects built from textured quads on item_display entities (assets/azrathiel/models/fx/*), animated purely by interpolated
 * Transformations, plus floating damage numbers on text_display. Everything is short-lived, budgeted per cast and globally, tagged for
 * cleanup, and strictly cosmetic: nothing here can affect damage. In PARTICLES mode no custom model is ever spawned.
 */
public final class Vfx {
    public static final String TAG = "azrathiel_fx";
    private static final float D = (float) (Math.PI / 180.0);

    /** Pose of a quad: scale, rotation (euler: roll about the quad normal, then pitch, then yaw), translation. */
    public record P3(Vector3f s, Quaternionf q, Vector3f t) {
        public static P3 of(float sx, float sy, float sz, float pitch, float yaw, float roll, float tx, float ty, float tz) {
            return new P3(new Vector3f(sx, sy, sz), new Quaternionf().rotateY(yaw * D).rotateX(pitch * D).rotateZ(roll * D), new Vector3f(tx, ty, tz));
        }
        Transformation tf() { return new Transformation(new Vector3f(t), new Quaternionf(q), new Vector3f(s), new Quaternionf()); }
        P3 scaled(float k) { return new P3(new Vector3f(s).mul(k, k, 1f), new Quaternionf(q), new Vector3f(t)); }
    }
    public record Stage(P3 to, int ticks) {}

    private final AzrathielModule mod; private final Set<Entity> live = ConcurrentHashMap.newKeySet(); private final Map<String, ItemStack> cache = new HashMap<>(); private int castBudget;
    public Vfx(AzrathielModule mod) { this.mod = mod; }

    public void begin() { castBudget = 90; }
    public boolean models() { return mod.cfg.vfxMode.equals("MODELS"); }
    public boolean enabled() { return !mod.cfg.vfxMode.equals("OFF"); }
    public int alive() { live.removeIf(e -> !e.isValid()); return live.size(); }

    private boolean room() { return models() && castBudget > 0 && live.size() < mod.cfg.maxFx; }

    private ItemStack item(String model, int rgb) {
        return cache.computeIfAbsent(model + "|" + rgb, k -> {
            Material m = Material.matchMaterial(mod.cfg.rigItemMaterial); ItemStack it = new ItemStack(m != null && m.isItem() ? m : Material.PAPER); ItemMeta im = it.getItemMeta();
            try { im.setItemModel(NamespacedKey.fromString("azrathiel:fx/" + model)); } catch (Throwable ignored) { }
            try { CustomModelDataComponent c = im.getCustomModelDataComponent(); c.setColors(List.of(Color.fromRGB(rgb & 0xFFFFFF))); im.setCustomModelDataComponent(c); } catch (Throwable ignored) { }
            it.setItemMeta(im); return it;
        }).clone();
    }

    private void common(Display e) {
        e.setPersistent(false); e.setInvulnerable(true); e.setGravity(false); e.addScoreboardTag(TAG); e.setShadowRadius(0f); e.setViewRange(1.2f);
        e.setBrightness(new Display.Brightness(15, 15));
    }

    /** Spawn one textured quad and run it through its stages (interpolated), then remove it. */
    public void play(Location at, String model, int rgb, boolean billboard, P3 from, int delay, Stage... stages) {
        if (!room() || at.getWorld() == null) return; castBudget--;
        final Location loc = at.clone();
        mod.tasks.later(delay, () -> {
            if (loc.getWorld() == null) return;
            ItemDisplay d = loc.getWorld().spawn(loc, ItemDisplay.class, e -> {
                common(e); e.setItemStack(item(model, rgb)); e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                e.setBillboard(billboard ? Display.Billboard.CENTER : Display.Billboard.FIXED); e.setTransformation(from.tf());
            });
            live.add(d); int t = 1;
            for (Stage st : stages) { final int when = t; mod.tasks.later(when, () -> { if (!d.isValid()) return; d.setInterpolationDelay(0); d.setInterpolationDuration(Math.max(1, st.ticks())); d.setTransformation(st.to().tf()); }); t += Math.max(1, st.ticks()); }
            mod.tasks.later(t + 1, () -> { live.remove(d); if (d.isValid()) d.remove(); });
        });
    }

    // ---------------------------------------------------------------------------------------------------- primitives
    /** Flat ground ring, diameter = 2*radius. r0 -> r1 over ttl (inward if r1 < r0). */
    public void ring(Location c, int rgb, float r0, float r1, int ttl, int delay, float y) {
        int grow = Math.max(2, (int) (ttl * 0.8)); float yy = y;
        play(c, "ring", rgb, false, P3.of(r0 * 2, r0 * 2, 1, -90, 0, 0, 0, yy, 0), delay, new Stage(P3.of(r1 * 2, r1 * 2, 1, -90, 0, 0, 0, yy, 0), grow), new Stage(P3.of(0.01f, 0.01f, 1, -90, 0, 0, 0, yy, 0), Math.max(1, ttl - grow)));
    }

    /** Flat textured disc that grows, slowly spins (roll steps <= 120 deg so interpolation never takes the short way round), holds, then collapses. */
    public void flat(Location c, String model, int rgb, float r0, float r1, int growTicks, int holdTicks, float spinDegTotal, float y, int delay) {
        float d0 = r0 * 2, d1 = r1 * 2; Stage[] st = new Stage[2 + Math.max(1, (int) Math.ceil(holdTicks / 10.0))]; int k = 0;
        st[k++] = new Stage(P3.of(d1, d1, 1, -90, 0, 0, 0, y, 0), Math.max(1, growTicks)); int steps = st.length - 2; float roll = 0;
        for (int i = 0; i < steps; i++) { roll += spinDegTotal / steps; st[k++] = new Stage(P3.of(d1, d1, 1, -90, 0, roll, 0, y, 0), Math.max(1, holdTicks / steps)); }
        st[k] = new Stage(P3.of(0.01f, 0.01f, 1, -90, 0, roll, 0, y, 0), 4);
        play(c, model, rgb, false, P3.of(d0, d0, 1, -90, 0, 0, 0, y, 0), delay, st);
    }

    /** Camera-facing sprite that pops to `size` and fades by shrinking. */
    public void flare(Location l, int rgb, float size, int ttl, int delay) { sprite(l, "spark", rgb, size, ttl, delay, 45f); }
    public void glow(Location l, int rgb, float size0, float size1, int ttl, int delay) {
        play(l, "glow", rgb, true, P3.of(size0, size0, 1, 0, 0, 0, 0, 0, 0), delay, new Stage(P3.of(size1, size1, 1, 0, 0, 0, 0, 0, 0), Math.max(1, (int) (ttl * 0.7))), new Stage(P3.of(0.01f, 0.01f, 1, 0, 0, 0, 0, 0, 0), Math.max(1, ttl - (int) (ttl * 0.7))));
    }
    public void sprite(Location l, String model, int rgb, float size, int ttl, int delay, float spin) {
        int pop = Math.min(3, Math.max(1, ttl / 4));
        play(l, model, rgb, true, P3.of(0.05f, 0.05f, 1, 0, 0, 0, 0, 0, 0), delay, new Stage(P3.of(size, size, 1, 0, 0, spin * 0.4f, 0, 0, 0), pop), new Stage(P3.of(0.01f, 0.01f, 1, 0, 0, spin, 0, 0, 0), Math.max(1, ttl - pop)));
    }
    public void slash(Location l, int rgb, float size, float roll, int ttl, int delay) {
        play(l, "slash", rgb, true, P3.of(size * 0.3f, size * 0.3f, 1, 0, 0, roll - 40, 0, 0, 0), delay, new Stage(P3.of(size, size, 1, 0, 0, roll, 0, 0, 0), Math.max(1, ttl / 3)), new Stage(P3.of(size * 1.1f, 0.01f, 1, 0, 0, roll + 25, 0, 0, 0), Math.max(1, ttl - ttl / 3)));
    }

    /** Light beam between two points (two crossed quads so it reads from every angle). */
    public void beam(Location a, Location b, int rgb, float width, int ttl, int delay) {
        if (a.getWorld() != b.getWorld()) return; Vector d = b.toVector().subtract(a.toVector()); double len = d.length(); if (len < 0.2) return; d.normalize();
        Location mid = a.clone().add(d.clone().multiply(len / 2)); Quaternionf q1 = new Quaternionf().rotationTo(new Vector3f(1, 0, 0), new Vector3f((float) d.getX(), (float) d.getY(), (float) d.getZ()));
        Quaternionf q2 = new Quaternionf(q1).rotateX((float) (Math.PI / 2)); int grow = Math.max(1, Math.min(3, ttl / 3));
        for (Quaternionf q : new Quaternionf[]{q1, q2}) play(mid, "beam", rgb, false, new P3(new Vector3f((float) len, 0.01f, 1), q, new Vector3f()), delay,
                new Stage(new P3(new Vector3f((float) len, width, 1), q, new Vector3f()), grow), new Stage(new P3(new Vector3f((float) len, 0.01f, 1), q, new Vector3f()), Math.max(1, ttl - grow)));
    }

    /** Vertical column of light (three crossed planes). `dropFrom` > 0 makes it fall in from that height above. */
    public void pillar(Location base, int rgb, float height, float width, int ttl, int delay, float dropFrom) {
        int grow = Math.max(1, Math.min(4, ttl / 3));
        for (int i = 0; i < 3; i++) {
            float yaw = i * 60f; Quaternionf q = new Quaternionf().rotateY(yaw * D).rotateZ(90 * D);
            play(base, "beam", rgb, false, new P3(new Vector3f(height, 0.05f, 1), q, new Vector3f(0, height / 2 + dropFrom, 0)), delay,
                    new Stage(new P3(new Vector3f(height, width, 1), q, new Vector3f(0, height / 2, 0)), grow), new Stage(new P3(new Vector3f(height, 0.01f, 1), q, new Vector3f(0, height / 2, 0)), Math.max(1, ttl - grow)));
        }
    }

    /** Eight vertical hex panels in a ring (shield dome wall), facing the centre. */
    public void domeWall(Location c, int rgb, float radius, float height, int ttl, int delay) {
        for (int i = 0; i < 8; i++) {
            double th = i * Math.PI / 4; float w = (float) (2 * radius * Math.sin(Math.PI / 8) * 1.06), yaw = 90f - (float) Math.toDegrees(th);
            Location l = c.clone().add(Math.cos(th) * radius, 0, Math.sin(th) * radius);
            play(l, "hex", rgb, false, P3.of(w, 0.05f, 1, 0, yaw, 0, 0, height / 2, 0), delay + (i % 2), new Stage(P3.of(w, height, 1, 0, yaw, 0, 0, height / 2, 0), 3), new Stage(P3.of(w, 0.01f, 1, 0, yaw, 0, 0, height / 2, 0), Math.max(1, ttl - 3)));
        }
    }

    // ------------------------------------------------------------------------------------------- feedback: hit + numbers
    public void hit(LivingEntity t, int rgb, double dmg) {
        if (!enabled()) return; Location l = t.getLocation().add(0, t.getHeight() * 0.6, 0);
        if (room()) { flare(l, rgb, 1.3f, 8, 0); ring(t.getLocation(), rgb, 0.3f, 1.2f, 8, 0, 0.1f); }
        if (mod.cfg.damageNumbers) number(t, dmg >= 0.5 ? String.valueOf(Math.round(dmg)) : "0", dmg >= 0.5 ? rgb : 0xAAAAAA);
    }
    public void blocked(LivingEntity t) { if (enabled() && mod.cfg.damageNumbers) number(t, "BLOCKED", 0xFF3030); }

    public void number(LivingEntity t, String text, int rgb) {
        if (!enabled() || castBudget <= -30 || live.size() >= mod.cfg.maxFx + 60) return; castBudget--;
        ThreadLocalRandom r = ThreadLocalRandom.current(); Location l = t.getLocation().add(r.nextDouble(-0.35, 0.35), t.getHeight() + 0.25, r.nextDouble(-0.35, 0.35)); World w = l.getWorld(); if (w == null) return;
        TextDisplay d = w.spawn(l, TextDisplay.class, e -> {
            e.setPersistent(false); e.setInvulnerable(true); e.setGravity(false); e.addScoreboardTag(TAG); e.setViewRange(0.5f); e.setBillboard(Display.Billboard.CENTER);
            e.text(Component.text(text, TextColor.color(rgb & 0xFFFFFF))); e.setShadowed(true); e.setDefaultBackground(false); e.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            e.setBrightness(new Display.Brightness(15, 15)); e.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.5f), new Quaternionf()));
        });
        live.add(d);
        mod.tasks.later(1, () -> { if (!d.isValid()) return; d.setInterpolationDelay(0); d.setInterpolationDuration(14); d.setTransformation(new Transformation(new Vector3f(0, 1.1f, 0), new Quaternionf(), new Vector3f(1.1f), new Quaternionf())); });
        mod.tasks.later(15, () -> { if (!d.isValid()) return; d.setInterpolationDelay(0); d.setInterpolationDuration(6); d.setTransformation(new Transformation(new Vector3f(0, 1.5f, 0), new Quaternionf(), new Vector3f(0.05f), new Quaternionf())); });
        mod.tasks.later(23, () -> { live.remove(d); if (d.isValid()) d.remove(); });
    }

    // ------------------------------------------------------------------------------------------------------ lifecycle
    public int purgeAll() { int n = 0; for (World w : org.bukkit.Bukkit.getWorlds()) for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(TAG)) { e.remove(); n++; } live.clear(); return n; }
}
