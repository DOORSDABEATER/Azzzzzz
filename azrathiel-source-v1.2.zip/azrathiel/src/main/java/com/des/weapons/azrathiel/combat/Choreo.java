package com.des.weapons.azrathiel.combat;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.core.Eidolon;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Choreographed visuals per Eidolon / event. Pure presentation: every call is made inside Fx.safe and after the damage code has already run. */
final class Choreo {
    private Choreo() {}
    private static Location up(Location l, double y) { return l.clone().add(0, y, 0); }
    private static Location lerp(Location a, Location b, double t) { return a.clone().add(b.toVector().subtract(a.toVector()).multiply(t)); }
    private static Location polar(Location c, double r, double a, double y) { return c.clone().add(Math.cos(a) * r, y, Math.sin(a) * r); }

    // ---- VIGOR: a hammer of light falls, the ground cracks, shockwaves roll out ----
    static void vigor(CastCtx c, Location f, double r) {
        Vfx v = c.mod.vfx; int col = Eidolon.VIGOR.rgb; float R = (float) r;
        v.flat(f, "rune", col, 0.6f, R, 3, 20, 60, 0.05f, 0);
        v.pillar(f, 0xFFD9A0, 10f, 2.2f, 7, 0, 8f);
        v.flat(f, "crack", 0xFFB070, 0.5f, R * 1.15f, 1, 26, 0, 0.04f, 4);
        v.ring(f, 0xFFFFFF, 0.5f, R * 1.3f, 9, 4, 0.1f); v.ring(f, col, 0.4f, R * 1.1f, 10, 6, 0.12f);
        v.flare(up(f, 0.6), 0xFFFFFF, R * 0.9f, 8, 4);
        for (int i = 0; i < 6; i++) v.flare(polar(f, R * 0.55, i * Math.PI / 3 + 0.3, 0.4 + ThreadLocalRandom.current().nextDouble(0.8)), 0xFFB070, 0.8f, 10, 5);
    }

    // ---- ABYSS: a spinning void opens, everything is drawn inward ----
    static void abyss(CastCtx c, Location f, double r, int pulse) {
        Vfx v = c.mod.vfx; int col = Eidolon.ABYSS.rgb; float R = (float) r;
        if (pulse == 0) { v.flat(f, "void", 0xA874FF, 0.4f, R * 1.1f, 4, 62, 260, 0.06f, 0); v.glow(up(f, 1.0), 0x3A0A88, 0.4f, R * 0.9f, 62, 0); v.glow(up(f, 1.0), 0xE8D8FF, 0.2f, 1.0f, 20, 0); }
        v.ring(f, col, R, 0.3f, 14, 0, 0.12f);
        for (int i = 0; i < 5; i++) v.flare(polar(f, R * 0.8, i * 1.256 + pulse, 0.5), 0xC9A8FF, 0.7f, 12, i);
    }

    // ---- FATE: an eye opens over each mark, a thread of light ties it, the verdict falls ----
    static void fateMark(CastCtx c, Location from, LivingEntity t) {
        Vfx v = c.mod.vfx; int col = Eidolon.FATE.rgb;
        v.sprite(t.getLocation().add(0, t.getHeight() + 0.9, 0), "eye", col, 1.6f, 26, 0, 20f);
        v.beam(from, t.getLocation().add(0, 1, 0), col, 0.25f, 7, 0);
        v.flat(t.getLocation(), "rune", col, 0.3f, 1.5f, 3, 14, 40, 0.05f, 0);
    }
    static void fateStrike(CastCtx c, LivingEntity t) {
        Vfx v = c.mod.vfx; Location l = t.getLocation(); int col = Eidolon.FATE.rgb;
        v.pillar(l, 0xFFFFFF, 9f, 1.2f, 6, 0, 6f); v.flare(up(l, 1), col, 1.9f, 8, 3); v.ring(l, col, 0.3f, 1.9f, 8, 2, 0.1f);
    }

    // ---- RUIN: a rotting sigil, cracks, red bursts every decay tick ----
    static void ruin(CastCtx c, Location f, double r) {
        Vfx v = c.mod.vfx; int col = Eidolon.RUIN.rgb; float R = (float) r;
        v.flat(f, "rune", col, 0.5f, R, 4, 46, 90, 0.05f, 0); v.flat(f, "crack", 0x701010, 0.5f, R * 1.05f, 2, 48, 0, 0.03f, 1);
        v.ring(f, col, 0.5f, R, 10, 0, 0.1f); v.glow(up(f, 0.8), col, 0.5f, 2.4f, 14, 0);
    }
    static void ruinPulse(CastCtx c, Location f, double r) {
        Vfx v = c.mod.vfx; int col = Eidolon.RUIN.rgb; v.ring(f, col, 0.4f, (float) r, 10, 0, 0.1f);
        for (int i = 0; i < 4; i++) v.glow(polar(f, r * 0.6, ThreadLocalRandom.current().nextDouble(6.28), 0.5), col, 0.3f, 1.2f, 10, i);
    }

    // ---- AEGIS: a ground seal and a wall of hex panels that refreshes while the barrier lasts ----
    static void aegis(CastCtx c, Location ctr, double r, boolean first) {
        Vfx v = c.mod.vfx; int col = Eidolon.AEGIS.rgb; float R = (float) r;
        v.domeWall(ctr, col, R * 0.98f, 3.6f, 26, 0);
        if (first) { v.flat(ctr, "rune", col, R * 0.3f, R, 6, 150, 180, 0.05f, 0); v.ring(ctr, 0xFFFFFF, 0.5f, R * 1.1f, 10, 0, 0.1f); v.flare(up(ctr, 1.2), col, 3f, 10, 0); }
        else v.ring(ctr, col, R * 0.6f, R, 12, 0, 0.08f);
    }
    static void aegisBlock(CastCtx c, Location at) { Vfx v = c.mod.vfx; v.flare(at, 0xBFD4FF, 1.4f, 8, 0); v.ring(at, Eidolon.AEGIS.rgb, 0.2f, 1.2f, 8, 0, 0f); }

    // ---- EVOLUTION: an analysis ring and three orbiting glyphs ----
    static void evolution(CastCtx c, Location ctr, double r) {
        Vfx v = c.mod.vfx; int col = Eidolon.EVOLUTION.rgb;
        v.ring(ctr, col, 0.5f, (float) r, 12, 0, 0.1f);
        for (int i = 0; i < 3; i++) { double a = i * 2.094; v.flat(polar(ctr, 1.6, a, 0.2), "rune", col, 0.2f, 0.7f, 3, 14, 90, 0.4f + i * 0.35f, i); v.sprite(polar(ctr, 1.6, a, 1.2), "spark", 0xCFFFE0, 0.9f, 14, i, 90f); }
    }

    // ---- WRAITH: a phase dash leaves crescents of cold light; souls rise from the struck ----
    static void wraith(CastCtx c, Location start, Location end, List<LivingEntity> hit) {
        Vfx v = c.mod.vfx; int col = Eidolon.WRAITH.rgb; double len = start.distance(end); int n = (int) Math.max(3, Math.min(8, len / 2.5));
        v.beam(start, end, 0xE8FFFF, 0.14f, 7, 0);
        for (int i = 0; i < n; i++) { Location p = lerp(start, end, (i + 0.5) / n); v.slash(p, col, 2.4f, i % 2 == 0 ? -30f : 30f, 9, i); v.glow(p, 0xFFFFFF, 0.3f, 1.3f, 8, i); }
        for (LivingEntity t : hit.subList(0, Math.min(5, hit.size()))) v.sprite(t.getLocation().add(0, 1.2, 0), "soul", col, 1.7f, 18, 4, 30f);
    }

    // ---- DOMINION: a gold seal unfurls, crowns descend on the subjects ----
    static void dominion(CastCtx c, Location ctr, double r, List<LivingEntity> targets) {
        Vfx v = c.mod.vfx; int col = Eidolon.DOMINION.rgb; float R = (float) r;
        v.flat(ctr, "rune", col, 0.5f, R, 6, 34, 90, 0.06f, 0); v.ring(ctr, col, 0.5f, R * 1.05f, 12, 2, 0.1f); v.ring(ctr, 0xFFFFFF, 0.5f, R * 0.7f, 10, 4, 0.12f);
        for (LivingEntity t : targets.subList(0, Math.min(6, targets.size()))) { v.sprite(t.getLocation().add(0, t.getHeight() + 0.8, 0), "crown", col, 1.5f, 26, 2, 0f); v.pillar(t.getLocation(), col, 6f, 0.7f, 10, 3, 3f); }
    }

    // ---- Convergence flourish: every participating Eidolon contributes a ring in its own colour ----
    static void convergence(CastCtx c, Location f, double r) {
        Vfx v = c.mod.vfx; List<Eidolon> o = c.spec.order(); v.flat(f, "rune", o.get(0).rgb, 0.5f, (float) r, 4, 28, 120, 0.05f, 0);
        for (int i = 0; i < o.size(); i++) { v.ring(f, o.get(i).rgb, 0.3f, (float) (r * (0.8 + 0.12 * i)), 10, 2 * i, 0.1f + 0.03f * i); v.flare(up(f, 0.8 + 0.3 * i), o.get(i).rgb, 1.3f, 10, 2 * i); }
    }
    static void gravity(CastCtx c, Location f) { Vfx v = c.mod.vfx; v.glow(up(f, 1.2), 0x3A0A88, 0.5f, 3.5f, 14, 0); for (int k = 0; k < 3; k++) v.ring(f, 0xFF6A1F, 5f, 0.3f, 10, k * 3, 0.1f); v.flare(up(f, 0.5), 0xFFFFFF, 3f, 8, 8); }
    static void impact(CastCtx c, LivingEntity t) { Vfx v = c.mod.vfx; Location l = t.getLocation(); v.pillar(l, 0xFFD9A0, 10f, 1.6f, 7, 0, 8f); v.ring(l, 0xFF6A1F, 0.3f, 2.2f, 9, 3, 0.1f); v.flare(up(l, 1), 0x7FDBFF, 1.8f, 8, 3); }
    static void prophecyResolve(CastCtx c, LivingEntity t) { Vfx v = c.mod.vfx; Location l = t.getLocation(); v.pillar(l, 0xC9F4F0, 12f, 2f, 9, 0, 8f); v.sprite(up(l, 2), "soul", 0x7FDBFF, 2.4f, 20, 3, 40f); v.ring(l, 0x7FDBFF, 0.3f, 4f, 12, 3, 0.1f); }
    static void devourerCollapse(CastCtx c, Location f, double r) { Vfx v = c.mod.vfx; for (int k = 0; k < 4; k++) v.ring(f, k % 2 == 0 ? 0xB31217 : 0x6A1BFF, 0.5f, (float) r * 1.3f, 12, k * 2, 0.1f); v.flare(up(f, 1), 0xFFFFFF, (float) r * 0.8f, 12, 0); v.glow(up(f, 1), 0xB31217, 1f, (float) r * 0.7f, 14, 0); }
    static void rewrite(CastCtx c, Location at) { Vfx v = c.mod.vfx; int[] cols = {0x7FDBFF, 0x39E06B, 0xC9F4F0}; for (int i = 0; i < 3; i++) v.ring(at, cols[i], 4f, 0.4f, 12, i * 3, 0.1f + 0.05f * i); v.flat(at, "rune", 0x7FDBFF, 0.3f, 2.4f, 4, 22, -180, 0.05f, 0); }
    static void sovereign(CastCtx c, Location at) { Vfx v = c.mod.vfx; v.domeWall(at, 0xFFC83D, 6f, 3.6f, 30, 0); v.sprite(up(at, 3.2), "crown", 0xFFC83D, 2.4f, 30, 0, 0f); v.ring(at, 0x2E6FFF, 0.5f, 6f, 12, 2, 0.1f); }

    // ---- EIGHTFOLD APOCALYPSE ----
    static void ultAwaken(CastCtx c, Location mc) {
        Vfx v = c.mod.vfx; v.flat(mc, "rune", 0xFFC83D, 0.5f, 14f, 8, 60, 200, 0.06f, 0);
        for (int i = 0; i < 8; i++) { Location p = polar(mc, 6.5, i * Math.PI / 4, 0); v.pillar(p, Eidolon.values()[i].rgb, 16f, 1.5f, 44, i * 2, 0); v.flare(up(p, 0.8), Eidolon.values()[i].rgb, 2f, 14, i * 2); }
        for (int k = 0; k < 3; k++) v.ring(mc, 0xFFC83D, 0.5f, 12f + k * 4, 14, k * 4, 0.1f);
    }
    static void ultManifest(CastCtx c, Eidolon e, Location focus) { Vfx v = c.mod.vfx; v.flare(up(focus, 1), e.rgb, 3f, 12, 0); v.ring(focus, e.rgb, 0.4f, 5f, 12, 0, 0.1f); }
    static void ultDomination(CastCtx c, Location mc, double r) { Vfx v = c.mod.vfx; v.ring(mc, 0xFFC83D, 1f, (float) r, 16, 0, 0.1f); v.ring(mc, 0xFFFFFF, 1f, (float) r * 0.6f, 12, 3, 0.15f); v.flat(mc, "rune", 0xFFC83D, 4f, 9f, 4, 18, 60, 0.07f, 0); }
    static void ultMain(CastCtx c, Location from, List<LivingEntity> enemies, Location mc) {
        Vfx v = c.mod.vfx; for (int i = 0; i < 8; i++) {
            Eidolon e = Eidolon.values()[i]; Location to = enemies.isEmpty() ? polar(mc, 14, i * Math.PI / 4, 1) : enemies.get(i % enemies.size()).getLocation().add(0, 1, 0);
            v.beam(from, to, e.rgb, 0.7f, 9, i); v.pillar(to.clone().add(0, -1, 0), e.rgb, 14f, 2f, 10, i, 10f); v.flare(to, 0xFFFFFF, 2.6f, 9, i + 2);
        }
        v.glow(up(from, 0), 0xFFFFFF, 1f, 6f, 10, 0);
    }
    static void ultImpact(CastCtx c, Location mc, double r) {
        Vfx v = c.mod.vfx; for (int k = 0; k < 5; k++) v.ring(mc, k % 2 == 0 ? 0xFFFFFF : 0xFFC83D, 1f, (float) r * (0.7f + 0.1f * k), 12 + k * 2, k * 2, 0.1f + 0.03f * k);
        v.flare(up(mc, 1), 0xFFFFFF, 12f, 14, 0); v.glow(up(mc, 1), 0xFFC83D, 2f, 16f, 18, 0); v.flat(mc, "crack", 0xFFE08A, 1f, (float) r * 0.5f, 3, 36, 0, 0.04f, 0);
    }

    // ---- LAST GUARDIAN ----
    static void guardSeal(AzrathielModule mod, Location center, double r) {
        mod.fx.begin(); Vfx v = mod.vfx; int col = Eidolon.AEGIS.rgb; v.flat(center, "rune", col, 1f, (float) r, 10, 150, 120, 0.05f, 0);
        v.domeWall(center, col, (float) r * 0.95f, 5f, 40, 0); v.ring(center, 0xFFFFFF, 1f, (float) r, 14, 0, 0.1f); v.pillar(center, col, 18f, 2f, 50, 0, 0);
    }
    static void guardPulse(AzrathielModule mod, Location center, double r) { mod.fx.begin(); mod.vfx.ring(center, Eidolon.AEGIS.rgb, (float) r * 0.4f, (float) r, 14, 0, 0.1f); mod.vfx.pillar(center, Eidolon.AEGIS.rgb, 12f, 1.2f, 20, 0, 0); }
    static void guardShock(AzrathielModule mod, Location center, double r) {
        mod.fx.begin(); Vfx v = mod.vfx; for (int k = 0; k < 4; k++) v.ring(center, k % 2 == 0 ? 0xFFFFFF : Eidolon.AEGIS.rgb, 1f, (float) r * (0.8f + 0.1f * k), 12 + k * 2, k * 2, 0.1f); v.flare(up(center, 1), 0xFFFFFF, 9f, 12, 0);
    }

    // ---- small events ----
    static void strike(CastCtx c, Location target, int rgb) {
        Vfx v = c.mod.vfx; boolean flip = ThreadLocalRandom.current().nextBoolean(); v.slash(up(target, 1.1), rgb, 2.3f, flip ? -25f : 25f, 8, 0); v.flare(up(target, 1.0), 0xFFFFFF, 1.1f, 6, 1);
    }
    static void summon(AzrathielModule mod, Location l, int rgb) {
        mod.fx.begin(); Vfx v = mod.vfx; v.flat(l, "rune", rgb, 0.3f, 2.4f, 5, 26, 90, -1.2f, 0); v.pillar(up(l, -1.4), rgb, 4f, 0.8f, 16, 0, 0); v.glow(l, rgb, 0.2f, 2.2f, 14, 0); v.ring(up(l, -1.4), rgb, 0.3f, 2.6f, 12, 2, 0.05f);
    }
    static void transform(AzrathielModule mod, Location l, int rgb, boolean big) {
        mod.fx.begin(); Vfx v = mod.vfx; float s = big ? 2f : 1f; for (int k = 0; k < 3; k++) v.ring(up(l, -1.2), k == 1 ? 0xFFFFFF : rgb, 0.4f, (3f + k) * s, 12, k * 3, 0.05f);
        v.flare(l, 0xFFFFFF, 3f * s, 10, 0); v.glow(l, rgb, 0.5f, 5f * s, 16, 0); if (big) v.flat(up(l, -1.2), "rune", rgb, 1f, 6f, 6, 30, 120, 0.05f, 2);
    }
}
