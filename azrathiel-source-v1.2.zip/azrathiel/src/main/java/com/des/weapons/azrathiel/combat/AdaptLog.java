package com.des.weapons.azrathiel.combat;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.*;

/** Short-term memory about what is hurting each master: feeds EVOLUTION, PvP-defence rules, FUTURE//REWRITE and immunities. */
public final class AdaptLog {
    public record Hit(long ms, String cause, String attackerType, double dmg) {}
    public record Snap(long ms, double health, Location loc) {}
    private record Immunity(String cause, long until) {}

    private final Map<UUID, ArrayDeque<Hit>> hits = new HashMap<>();
    private final Map<UUID, ArrayDeque<Snap>> snaps = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> pvpAttackers = new HashMap<>();
    private final Map<UUID, Immunity> immunity = new HashMap<>();

    public void record(Player p, EntityDamageEvent e) {
        long now = System.currentTimeMillis(); String type = "";
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity d = be.getDamager(); if (d instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Entity s) d = s;
            type = d.getType().name();
            if (d instanceof Player a && !a.equals(p)) pvpAttackers.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(a.getUniqueId(), now);
        }
        ArrayDeque<Hit> q = hits.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        q.addLast(new Hit(now, e.getCause().name(), type, e.getFinalDamage()));
        while (q.size() > 40 || (!q.isEmpty() && now - q.peekFirst().ms() > 60_000)) q.removeFirst();
    }

    public String dominantCause(UUID id, long windowMs) {
        Map<String, Double> w = new HashMap<>(); long now = System.currentTimeMillis();
        for (Hit h : hits.getOrDefault(id, new ArrayDeque<>())) if (now - h.ms() <= windowMs) w.merge(h.cause(), Math.max(1, h.dmg()), Double::sum);
        String best = ""; double bv = 0; for (var e : w.entrySet()) if (e.getValue() > bv) { bv = e.getValue(); best = e.getKey(); } return best;
    }
    public Set<String> attackerTypes(UUID id, long windowMs) {
        Set<String> s = new HashSet<>(); long now = System.currentTimeMillis();
        for (Hit h : hits.getOrDefault(id, new ArrayDeque<>())) if (now - h.ms() <= windowMs && !h.attackerType().isEmpty()) s.add(h.attackerType()); return s;
    }
    public double recentDamage(UUID id, long windowMs) {
        double d = 0; long now = System.currentTimeMillis(); for (Hit h : hits.getOrDefault(id, new ArrayDeque<>())) if (now - h.ms() <= windowMs) d += h.dmg(); return d;
    }
    public boolean recentPvpAttacker(UUID master, UUID attacker, long windowMs) {
        Long t = pvpAttackers.getOrDefault(master, Map.of()).get(attacker); return t != null && System.currentTimeMillis() - t <= windowMs;
    }

    /** Sampled about once a second; used to "rewrite" a few seconds of recent history. */
    public void sample(Player p) {
        ArrayDeque<Snap> q = snaps.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        q.addLast(new Snap(System.currentTimeMillis(), p.getHealth(), p.getLocation())); while (q.size() > 15) q.removeFirst();
    }
    public Snap snapshotAgo(UUID id, long agoMs) {
        long target = System.currentTimeMillis() - agoMs; Snap best = null;
        for (Snap s : snaps.getOrDefault(id, new ArrayDeque<>())) if (s.ms() <= target) best = s; return best;
    }

    public void grantImmunity(UUID id, String cause, long durationMs) { if (cause != null && !cause.isEmpty()) immunity.put(id, new Immunity(cause, System.currentTimeMillis() + durationMs)); }
    public boolean isImmune(UUID id, String cause) {
        Immunity i = immunity.get(id); if (i == null) return false;
        if (System.currentTimeMillis() > i.until()) { immunity.remove(id); return false; } return i.cause().equals(cause);
    }
    public void forget(UUID id) { hits.remove(id); snaps.remove(id); pvpAttackers.remove(id); immunity.remove(id); }
}
