package com.des.weapons.azrathiel.core;

/** The eight ancient authorities bound inside VAELZARION. Pure data, no server dependencies. */
public enum Eidolon {
    VIGOR("Vigor", "Authority of Strength", "Titan Breaker", "Titanic", "Breaker", 0xFF6A1F, "VI",
            "Aggressive, confident, dominant and battle-hungry", Shape.CONE_SLAM),
    ABYSS("Abyss", "Authority of the Void", "Void Consumption", "Abyssal", "Maw", 0x6A1BFF, "AB",
            "Mysterious, hollow, unsettling and unnaturally calm", Shape.VOID_PULL),
    FATE("Fate", "Authority of Destiny", "Inevitable Future", "Fated", "Verdict", 0x7FDBFF, "FA",
            "Calm, prophetic, calculated and emotionless", Shape.HOMING_MARK),
    RUIN("Ruin", "Authority of Destruction", "Decaying Judgement", "Ruinous", "Collapse", 0xB31217, "RU",
            "Harsh, threatening, merciless and destructive", Shape.DECAY_ZONE),
    AEGIS("Aegis", "Authority of Protection", "Absolute Bastion", "Bulwark", "Bastion", 0x2E6FFF, "AE",
            "Protective, commanding, reassuring and fiercely loyal", Shape.BARRIER),
    EVOLUTION("Evolution", "Authority of Adaptation", "Adaptive Response", "Adaptive", "Mutation", 0x39E06B, "EV",
            "Analytical, observant, intelligent and constantly learning", Shape.ADAPT),
    WRAITH("Wraith", "Authority of the Soul", "Spectral Execution", "Spectral", "Haunting", 0xC9F4F0, "WR",
            "Ghostly, distant, quiet and unsettling", Shape.PHASE_DASH),
    DOMINION("Dominion", "Authority of Command", "Sovereign Decree", "Sovereign", "Decree", 0xFFC83D, "DO",
            "Royal, authoritative, intimidating and absolute", Shape.COMMAND_FIELD);

    public enum Shape { CONE_SLAM, VOID_PULL, HOMING_MARK, DECAY_ZONE, BARRIER, ADAPT, PHASE_DASH, COMMAND_FIELD }

    public static final int FULL_MASK = 0xFF;
    public final String display, authority, signature, adjective, noun, code, personality;
    public final int rgb;
    public final Shape shape;

    Eidolon(String display, String authority, String signature, String adjective, String noun, int rgb, String code,
            String personality, Shape shape) {
        this.display = display; this.authority = authority; this.signature = signature; this.adjective = adjective;
        this.noun = noun; this.rgb = rgb; this.code = code; this.personality = personality; this.shape = shape;
    }

    public int bit() { return 1 << ordinal(); }
    public String id() { return name().toLowerCase(java.util.Locale.ROOT); }
    public String signatureUpper() { return signature.toUpperCase(java.util.Locale.ROOT); }

    public static Eidolon parse(String s) {
        if (s == null) return null;
        String t = s.trim().toUpperCase(java.util.Locale.ROOT);
        for (Eidolon e : values()) if (e.name().equals(t) || e.code.equals(t)) return e;
        return null;
    }
}
