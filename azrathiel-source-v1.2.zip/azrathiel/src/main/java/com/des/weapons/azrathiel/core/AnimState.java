package com.des.weapons.azrathiel.core;

/** The 25 required animation states. duration 0 = looping base state; otherwise a one-shot. */
public enum AnimState {
    IDLE_FLOAT(10, 0, 5), IDLE_LOOK_AROUND(10, 0, 5), IDLE_OBSERVE_MASTER(10, 0, 5), FOLLOW(25, 0, 6), FOLLOW_FAST(30, 0, 7),
    TURN(22, 0.6f, 8), HOVER_UP(20, 0.8f, 6), HOVER_DOWN(20, 0.8f, 6), COMBAT_IDLE(40, 0, 7), TARGET_LOCK(50, 0, 9),
    MELEE_ATTACK(65, 0.55f, 15), HEAVY_ATTACK(72, 1.1f, 14), RANGED_ATTACK(66, 0.7f, 13), ABILITY_CAST(70, 1.0f, 12),
    DEFEND(75, 0, 9), INTERCEPT(76, 0.6f, 14), DAMAGE_REACTION(60, 0.45f, 16), RECOVERY(45, 1.0f, 5), TRANSFORMATION(90, 2.2f, 4),
    RELEASED_IDLE(12, 0, 5), ULTIMATE_CHARGE(94, 0, 4), ULTIMATE_EXECUTION(95, 0, 8), LAST_GUARDIAN(100, 0, 5),
    DISMISS(80, 1.2f, 6), RETURN_TO_MASTER(55, 0, 7);

    public final int priority; public final float duration, rate;
    AnimState(int priority, float duration, float rate) { this.priority = priority; this.duration = duration; this.rate = rate; }
    public boolean loops() { return duration <= 0f; }
}
