package com.des.weapons.azrathiel.cmd;

import com.des.weapons.azrathiel.AzrathielModule;
import com.des.weapons.azrathiel.combat.SelfTest;
import com.des.weapons.azrathiel.core.*;
import com.des.weapons.azrathiel.data.BondData;
import com.des.weapons.azrathiel.entity.Vael;
import com.des.weapons.azrathiel.gui.Menus;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.*;

/** /azrathiel ... Every registered subcommand does real work; permissions are checked per subcommand. */
public final class AzrathielCommand extends Command {
    private static final List<String> SUBS = List.of("summon", "dismiss", "release", "ultimate", "follow", "stay", "defend", "attack", "return", "resume", "status", "eidolon",
            "convergence", "loadout", "voice", "personality", "customize", "animation", "reload", "admin");
    private static final List<String> ADMIN = List.of("give", "reassign", "unlock", "lock", "setessence", "reset", "info", "selftest", "trace", "vfxtest", "cleanup", "debug", "delete");
    private final AzrathielModule mod;

    public AzrathielCommand(AzrathielModule mod) { super("azrathiel", "AZRATHIEL - master of the Eightfold Sovereign", "/azrathiel [subcommand]", List.of("azr")); this.mod = mod; setPermission("des.azrathiel.use"); }

    private void say(CommandSender s, String mm) { s.sendMessage(mod.msg(mm)); }
    private boolean bad(CommandSender s, String err) { if (err != null) say(s, "<red>" + err); return true; }

    @Override
    public boolean execute(CommandSender s, String label, String[] a) {
        try {
            String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
            if (sub.equals("reload") || sub.equals("admin")) return admin(s, sub.equals("reload") ? new String[]{"reload"} : Arrays.copyOfRange(a, 1, a.length));
            if (!(s instanceof Player p)) { say(s, "<gray>Players only (administrators: /azrathiel admin ...)."); return true; }
            if (!p.hasPermission("des.azrathiel.use")) return bad(s, "You lack permission.");
            var act = mod.actions;
            switch (sub) {
                case "" -> { if (act.bond(p) == null) return bad(s, "Hold the AZRATHIEL vessel and right-click it to awaken your bond."); Menus.control(mod, p).open(); }
                case "summon" -> bad(s, act.summon(p));
                case "dismiss" -> bad(s, act.dismiss(p));
                case "release" -> bad(s, act.release(p, a.length > 1 && a[1].equalsIgnoreCase("dormant") ? Boolean.FALSE : Boolean.TRUE));
                case "ultimate" -> bad(s, act.ultimate(p));
                case "follow" -> bad(s, act.stance(p, Vael.Mode.FOLLOW));
                case "stay" -> bad(s, act.stance(p, Vael.Mode.STAY));
                case "defend" -> bad(s, act.stance(p, Vael.Mode.DEFEND));
                case "attack" -> bad(s, act.stance(p, Vael.Mode.ATTACK));
                case "return" -> bad(s, act.stance(p, Vael.Mode.RETURN));
                case "resume" -> bad(s, act.resume(p));
                case "status" -> status(p);
                case "eidolon" -> eidolon(p, a);
                case "convergence" -> convergence(p, a);
                case "loadout" -> loadout(p, a);
                case "voice" -> voice(p, a);
                case "personality" -> personality(p, a);
                case "customize" -> customize(p, a);
                case "animation" -> animation(p, a);
                default -> say(s, "<gray>Unknown subcommand. Try <white>/azrathiel</white> for the control panel.");
            }
        } catch (Throwable t) { say(s, "<red>Command failed: " + t.getMessage()); mod.plugin.getLogger().warning("command error: " + t); }
        return true;
    }

    private BondData bond(Player p) { BondData b = mod.actions.bond(p); if (b == null) say(p, "<red>No bond yet. Right-click the AZRATHIEL vessel."); return b; }
    private static Boolean flag(String s) { return s == null ? null : s.equalsIgnoreCase("on") || s.equalsIgnoreCase("true") ? Boolean.TRUE : s.equalsIgnoreCase("off") || s.equalsIgnoreCase("false") ? Boolean.FALSE : null; }
    private static double num(String s, double lo, double hi) { double v = Double.parseDouble(s); return Math.max(lo, Math.min(hi, v)); }

    private void status(Player p) {
        BondData b = bond(p); if (b == null) return; Vael v = mod.actions.vael(p);
        say(p, "<gold>VAELZARION</gold> <gray>- " + (v == null ? "not summoned" : v.diagnostics()));
        say(p, "<gray>Bond <white>" + b.bondId.toString().substring(0, 8) + "<gray> | kills <white>" + b.kills + "<gray> | loadout <white>" + b.activeLoadout + " (" + b.loadout().size() + ")<gray> | personality <white>" + b.personality);
    }

    private void eidolon(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return;
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) { for (Eidolon e : Eidolon.values()) say(p, String.format("<#%06X>%s</#%06X> <gray>%s - %s | %s", e.rgb, e.display, e.rgb, e.signature, !mod.unlocked(b, e) ? "<red>locked" : b.enabled.contains(e) ? "<green>awakened" : "<yellow>silenced")); return; }
        Eidolon e = Eidolon.parse(a[1]); if (e == null) { say(p, "<red>Unknown Eidolon."); return; }
        if (a.length > 2 && a[2].equalsIgnoreCase("cast")) { bad(p, mod.actions.cast(p, "C:" + e.bit())); return; }
        if (!mod.unlocked(b, e)) { say(p, "<red>" + e.display + " has not awakened yet."); return; }
        if (!b.enabled.remove(e)) b.enabled.add(e); b.touch(); Vael v = mod.actions.vael(p); if (v != null) v.restoreMarkMask(); say(p, e.display + " is now " + (b.enabled.contains(e) ? "<green>awakened" : "<yellow>silenced"));
    }

    private void convergence(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return; String m = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "list";
        switch (m) {
            case "list" -> { for (var e : Convergence.handcrafted().entrySet()) say(p, "<gold>" + e.getValue() + "<gray> = " + String.join(" + ", Convergence.fromMask(e.getKey()).stream().map(x -> x.display).toList()));
                for (BondData.Custom c : b.customs) say(p, "<aqua>" + c.name() + "<gray> = " + String.join(" > ", c.order().stream().map(x -> x.display).toList())); say(p, "<gray>Any of the 255 combinations works: <white>/azrathiel convergence cast vigor+abyss+fate"); }
            case "cast", "info" -> { if (a.length < 3) { say(p, "<red>Name or Eidolons required, e.g. vigor+abyss"); return; } String key = mod.actions.parseKey(b, String.join(" ", Arrays.copyOfRange(a, 2, a.length))); if (key == null) { say(p, "<red>Unknown combination."); return; }
                var spec = mod.executor.specFor(b, key); if (spec == null) { say(p, "<red>Unknown combination."); return; }
                if (m.equals("info")) say(p, "<gold>" + spec.name() + "<gray> | " + spec.order().size() + " Eidolons | " + spec.mode() + " | dmg " + (int) spec.damage() + " | cd " + spec.cooldownTicks() / 20 + "s | cost " + spec.cost());
                else bad(p, mod.actions.cast(p, key)); }
            default -> say(p, "<gray>/azrathiel convergence list | cast <expr> | info <expr>");
        }
    }

    private void loadout(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return; String m = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        if (m.isEmpty()) { Menus.loadout(mod, p).open(); return; }
        switch (m) {
            case "list" -> { for (String n : b.loadouts.keySet()) say(p, (n.equals(b.activeLoadout) ? "<green>> " : "<gray>  ") + "<white>" + n + "<gray> (" + b.loadouts.get(n).size() + ")"); var lo = b.loadout(); for (int i = 0; i < lo.size() && i < 20; i++) say(p, "<gray>" + i + ": <white>" + mod.actions.keyName(b, lo.get(i))); }
            case "use" -> { String n = a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)) : ""; if (!b.loadouts.containsKey(n)) { say(p, "<red>No such preset."); return; } b.activeLoadout = n; b.selected = 0; b.touch(); say(p, "<green>Loadout " + n + " active."); }
            case "save" -> { String n = a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)) : ""; if (n.isBlank() || n.length() > 24) { say(p, "<red>Give a name (max 24 chars)."); return; } b.loadouts.put(n, new ArrayList<>(b.loadout())); b.activeLoadout = n; b.touch(); say(p, "<green>Saved preset " + n); }
            case "delete" -> { String n = a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)) : ""; if (b.loadouts.size() <= 1 || b.loadouts.remove(n) == null) { say(p, "<red>Cannot delete that preset."); return; } if (n.equals(b.activeLoadout)) b.activeLoadout = b.loadouts.keySet().iterator().next(); b.touch(); say(p, "<green>Deleted."); }
            case "add" -> { String key = mod.actions.parseKey(b, a.length > 2 ? String.join(" ", Arrays.copyOfRange(a, 2, a.length)) : ""); if (key == null || mod.executor.specFor(b, key) == null) { say(p, "<red>Unknown ability."); return; } if (!b.loadout().contains(key)) b.loadout().add(key); b.touch(); say(p, "<green>Added " + mod.actions.keyName(b, key)); }
            case "remove" -> { int i = Integer.parseInt(a[2]); var lo = b.loadout(); if (i < 0 || i >= lo.size()) { say(p, "<red>Index out of range."); return; } say(p, "<green>Removed " + mod.actions.keyName(b, lo.remove(i))); b.touch(); }
            case "select" -> { int i = Integer.parseInt(a[2]); var lo = b.loadout(); if (i < 0 || i >= lo.size()) { say(p, "<red>Index out of range."); return; } b.selected = i; b.touch(); say(p, "<green>Selected " + mod.actions.keyName(b, lo.get(i))); }
            default -> say(p, "<gray>/azrathiel loadout [list|use|save|delete|add|remove|select]");
        }
    }

    private void voice(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return; String m = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : ""; Vael v = mod.actions.vael(p);
        if (m.isEmpty()) { say(p, "<gray>/azrathiel voice volume|frequency|pitch|reverb|layers <value> | silent [on|off] | subtitles <mode> | history | preview"); return; }
        switch (m) {
            case "volume" -> b.voiceVolume = num(a[2], 0, 200) / 100.0; case "frequency" -> b.voiceFrequency = num(a[2], 0, 100) / 100.0; case "pitch" -> b.pitch = num(a[2], 50, 200) / 100.0;
            case "reverb" -> b.reverb = num(a[2], 0, 100) / 100.0; case "layers" -> b.layerIntensity = num(a[2], 0, 100) / 100.0;
            case "silent" -> { Boolean f = a.length > 2 ? flag(a[2]) : null; b.silent = f != null ? f : !b.silent; }
            case "subtitles" -> { String md = a.length > 2 ? a[2].toUpperCase(Locale.ROOT) : ""; if (!List.of("ACTIONBAR", "CHAT", "BOTH", "OFF").contains(md)) { say(p, "<red>ACTIONBAR, CHAT, BOTH or OFF"); return; } b.subtitleMode = md; }
            case "history" -> { if (v == null) { say(p, "<gray>Summon VAELZARION first."); return; } var h = v.director.history().stream().filter(x -> x.line().category() != Category.SECRET).toList(); for (var x : h.subList(Math.max(0, h.size() - 10), h.size())) say(p, "<gray>" + x.line().text()); return; }
            case "preview" -> { if (v == null) { say(p, "<gray>Summon VAELZARION first."); return; } var pool = mod.voiceLib.all().stream().filter(x -> x.category() != Category.SECRET && x.sub() == null).toList(); mod.voice.sayLine(v, pool.get(new Random().nextInt(pool.size()))); if (!mod.cfg.recordingsInstalled) say(p, "<gray>No recordings installed: subtitle preview only."); return; }
            default -> { say(p, "<red>Unknown voice setting."); return; }
        }
        b.touch(); if (v != null) v.syncPrefs(); say(p, "<green>Voice updated.");
    }

    private void personality(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return;
        if (a.length < 2) { say(p, "<gray>Personality: <white>" + b.personality + "<gray>. Options: " + Arrays.toString(Personality.values())); return; }
        try { b.personality = Personality.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (IllegalArgumentException e) { say(p, "<red>Unknown personality."); return; }
        b.touch(); Vael v = mod.actions.vael(p); if (v != null) v.syncPrefs(); say(p, "<green>Personality set to " + b.personality + " (changes dialogue only, never damage).");
    }

    private void customize(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return; String m = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (m) {
            case "theme" -> { String t = a.length > 2 ? a[2].toUpperCase(Locale.ROOT) : ""; if (!BondData.THEMES.contains(t)) { say(p, "<red>Themes: " + BondData.THEMES); return; } b.theme = t; }
            case "color" -> { b.customColor = Integer.parseInt(a[2].replace("#", ""), 16) & 0xFFFFFF; b.theme = "CUSTOM"; }
            case "particles" -> b.particleIntensity = num(a[2], 0, 200) / 100.0;
            case "aura" -> b.aura = Objects.requireNonNullElse(flag(a.length > 2 ? a[2] : null), !b.aura); case "halo" -> b.showHalo = Objects.requireNonNullElse(flag(a.length > 2 ? a[2] : null), !b.showHalo);
            case "fragments" -> b.showFragments = Objects.requireNonNullElse(flag(a.length > 2 ? a[2] : null), !b.showFragments); case "markings" -> b.showMarkings = Objects.requireNonNullElse(flag(a.length > 2 ? a[2] : null), !b.showMarkings);
            default -> { say(p, "<gray>/azrathiel customize theme <name> | color <#hex> | particles <0-200> | aura|halo|fragments|markings [on|off]"); return; }
        }
        b.touch(); say(p, "<green>Visuals updated.");
    }

    private void animation(Player p, String[] a) {
        BondData b = bond(p); if (b == null) return; String m = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "info"; Vael v = mod.actions.vael(p);
        switch (m) {
            case "intensity" -> { b.animIntensity = num(a[2], 20, 150) / 100.0; b.touch(); if (v != null) v.syncPrefs(); say(p, "<green>Animation intensity " + (int) (b.animIntensity * 100) + "%"); }
            case "state" -> { if (v == null) { say(p, "<gray>Summon VAELZARION first."); return; } try { v.preview(AnimState.valueOf(a[2].toUpperCase(Locale.ROOT))); say(p, "<green>Previewing for 4 seconds."); } catch (IllegalArgumentException e) { say(p, "<red>States: " + Arrays.toString(AnimState.values())); } }
            default -> say(p, "<gray>" + (v == null ? "Not summoned." : v.diagnostics()) + " <dark_gray>| /azrathiel animation intensity <20-150> | state <NAME>");
        }
    }

    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("des.azrathiel.admin")) return bad(s, "You lack permission.");
        String m = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        try {
            switch (m) {
                case "reload" -> { var w = mod.reload(); say(s, "<green>Reloaded config and voice packs (" + mod.voiceLib.size() + " lines)." + (w.isEmpty() ? "" : " <yellow>" + w.size() + " warning(s): " + w.get(0))); }
                case "give" -> { Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player pl ? pl : null); if (t == null) return bad(s, "Player not found."); t.getInventory().addItem(mod.weapon.create(null)); say(s, "<green>Gave an unbound AZRATHIEL vessel to " + t.getName()); }
                case "reassign" -> { if (a.length < 3) return bad(s, "/azrathiel admin reassign <currentOwner> <newOwner>"); OfflinePlayer from = Bukkit.getOfflinePlayer(a[1]), to = Bukkit.getOfflinePlayer(a[2]);
                    BondData b = mod.store.byOwner(from.getUniqueId()); if (b == null) return bad(s, "That player has no bond."); mod.vaels.release(from.getUniqueId());
                    if (!mod.store.reassign(b, to.getUniqueId(), Objects.requireNonNullElse(to.getName(), a[2]))) return bad(s, "The new owner already has a bond."); mod.store.saveNow(b); say(s, "<green>Bond reassigned. Identity, progression, presets and voice were preserved."); }
                case "unlock", "lock" -> { if (a.length < 3) return bad(s, "/azrathiel admin " + m + " <player> <eidolon|all>"); OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]); BondData b = mod.store.byOwner(t.getUniqueId()); if (b == null) return bad(s, "That player has no bond.");
                    List<Eidolon> es = a[2].equalsIgnoreCase("all") ? List.of(Eidolon.values()) : (Eidolon.parse(a[2]) == null ? List.of() : List.of(Eidolon.parse(a[2]))); if (es.isEmpty()) return bad(s, "Unknown Eidolon.");
                    for (Eidolon e : es) { if (m.equals("unlock")) b.unlocked.add(e); else b.unlocked.remove(e); } b.touch(); Vael v = mod.vaels.of(t.getUniqueId()); if (v != null) v.restoreMarkMask(); say(s, "<green>Done (" + es.size() + ")." + (mod.cfg.fullAccess ? " <yellow>Note: full-access is ON, so locks have no effect until it is disabled." : "")); }
                case "setessence" -> { if (a.length < 3) return bad(s, "/azrathiel admin setessence <player> <amount>"); Vael v = mod.vaels.of(Bukkit.getOfflinePlayer(a[1]).getUniqueId()); if (v == null) return bad(s, "That player has no active VAELZARION."); v.essence.set(Double.parseDouble(a[2])); say(s, "<green>Essence set."); }
                case "reset" -> { if (a.length < 2) return bad(s, "/azrathiel admin reset <player>"); BondData b = mod.store.byOwner(Bukkit.getOfflinePlayer(a[1]).getUniqueId()); if (b == null) return bad(s, "No bond."); b.cooldownReadyAt.clear(); b.ultReadyAt = 0; b.lgReadyAt = 0; b.essence = -1; b.touch(); say(s, "<green>Cooldowns and essence reset."); }
                case "info" -> { if (a.length < 2) return bad(s, "/azrathiel admin info <player>"); OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]); BondData b = mod.store.byOwner(t.getUniqueId()); if (b == null) return bad(s, "No bond."); Vael v = mod.vaels.of(t.getUniqueId());
                    say(s, "<gray>Bond " + b.bondId + " owner " + b.owner + " kills " + b.kills + " unlocked " + b.unlocked + " " + (v == null ? "(not summoned)" : v.diagnostics())); }
                case "selftest" -> SelfTest.run(mod, s, a.length > 1 && a[1].equalsIgnoreCase("cosmetics-off") || a.length <= 1);
                case "trace" -> { if (!(s instanceof Player pl)) return bad(s, "In-game only."); trace(pl, a.length > 1 && a[1].equalsIgnoreCase("hit")); }
                case "vfxtest" -> { if (!(s instanceof Player pl)) return bad(s, "In-game only."); String err = com.des.weapons.azrathiel.combat.ChoreoBridge.demo(mod, pl, a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "all"); if (err != null) return bad(s, err); say(s, "<green>Playing at your crosshair (no damage). Mode: " + mod.cfg.vfxMode + (mod.cfg.vfxMode.equals("MODELS") ? " - if you see purple/black cubes the fx models are missing from your resource pack." : "")); }
                case "cleanup" -> say(s, "<green>Removed " + (mod.vaels.purgeOrphans() + mod.vfx.purgeAll()) + " stray rig/effect entities.");
                case "debug" -> { mod.debug = !mod.debug; say(s, "Debug " + (mod.debug ? "<green>ON" : "<red>OFF")); }
                case "delete" -> { if (a.length < 2) return bad(s, "/azrathiel admin delete <player>"); OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]); BondData b = mod.store.byOwner(t.getUniqueId()); if (b == null) return bad(s, "No bond."); mod.vaels.release(t.getUniqueId()); mod.store.delete(b); say(s, "<green>Bond deleted."); }
                default -> say(s, "<gray>/azrathiel admin " + String.join("|", ADMIN) + "  |  /azrathiel reload");
            }
        } catch (Throwable t) { say(s, "<red>Failed: " + t.getMessage()); }
        return true;
    }

    /** Explains, step by step, why an ability would or would not hit: who is a valid target, what the crosshair sees, and (with "hit") whether another plugin cancels our damage. */
    private void trace(Player p, boolean doHit) {
        BondData b = mod.actions.bond(p); Vael v = mod.actions.vael(p);
        say(p, "<gold>TRACE <gray>weapon in hand: <white>" + mod.weapon.is(p.getInventory().getItemInMainHand()) + "<gray> | bond: <white>" + (b != null) + "<gray> | " + (v == null ? "<red>VAELZARION not summoned" : "<white>" + v.diagnostics()));
        if (b != null && !b.loadout().isEmpty()) { String key = b.loadout().get(Math.floorMod(b.selected, b.loadout().size())); say(p, "<gray>selected ability: <white>" + mod.actions.keyName(b, key) + "<gray> | cooldown left: <white>" + mod.executor.cooldownLeftMs(b, key) / 1000 + "s"); }
        say(p, "<gray>rules: pvp=<white>" + mod.cfg.pvpMode + "<gray> manual-aim-any-mob=<white>" + mod.cfg.manualAimAnyMob + "<gray> armor-stands=<white>" + mod.cfg.hitArmorStands + "<gray> vfx=<white>" + mod.cfg.vfxMode + "<gray> numbers=<white>" + mod.cfg.damageNumbers + "<gray> bypass-iframes=<white>" + mod.cfg.bypassIFrames);
        org.bukkit.entity.LivingEntity aim = mod.targeting.aimed(p, 30);
        say(p, "<gray>crosshair: <white>" + (aim == null ? "nothing targetable (look straight at a mob)" : aim.getType() + " at " + (int) aim.getLocation().distance(p.getLocation()) + " blocks"));
        int n = 0;
        for (org.bukkit.entity.Entity e : p.getNearbyEntities(12, 8, 12)) { if (!(e instanceof org.bukkit.entity.LivingEntity)) continue; if (n++ >= 10) { say(p, "<dark_gray>... more nearby"); break; }
            say(p, "<dark_gray>- <white>" + e.getType() + " <gray>" + (int) e.getLocation().distance(p.getLocation()) + "m: " + mod.targeting.explain(p, e)); }
        if (n == 0) say(p, "<yellow>no living entities within 12 blocks");
        if (doHit) {
            if (aim == null) { say(p, "<red>Aim at a mob first, then run: /azrathiel admin trace hit"); return; }
            var ctx = new com.des.weapons.azrathiel.combat.CastCtx(mod, p, null, true, p.getLocation(), aim.getLocation());
            double before = aim.getHealth(); double dealt = com.des.weapons.azrathiel.combat.Dmg.deal(ctx, 1, aim, 1.0, false, null);
            say(p, ctx.cancelled > 0 ? "<red>RESULT: damage was CANCELLED by another plugin/region protection (claims, WorldGuard flags, PvP/mob-damage rules). Our code worked; something else blocked it."
                    : dealt > 0 ? "<green>RESULT: dealt " + String.format("%.1f", dealt) + " (health " + String.format("%.1f", before) + " -> " + String.format("%.1f", aim.getHealth()) + "). Damage works here."
                    : "<yellow>RESULT: no health lost and not cancelled - the target absorbed it (invulnerable, absorption, or immunity).");
        } else say(p, "<gray>Run <white>/azrathiel admin trace hit<gray> to test one real point of damage on your crosshair target.");
    }

    @Override
    public List<String> tabComplete(CommandSender s, String alias, String[] a) {
        List<String> out = new ArrayList<>(); String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        if (a.length <= 1) { for (String x : SUBS) if (x.startsWith(last) && (!x.equals("admin") && !x.equals("reload") || s.hasPermission("des.azrathiel.admin"))) out.add(x); return out; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        List<String> opts = switch (sub) {
            case "release" -> List.of("dormant"); case "eidolon" -> a.length == 2 ? namesOf(Eidolon.values()) : List.of("cast");
            case "convergence" -> a.length == 2 ? List.of("list", "cast", "info") : eidolonExprs(s, a);
            case "loadout" -> a.length == 2 ? List.of("list", "use", "save", "delete", "add", "remove", "select") : List.of();
            case "voice" -> a.length == 2 ? List.of("volume", "frequency", "pitch", "reverb", "layers", "silent", "subtitles", "history", "preview") : a[1].equals("subtitles") ? List.of("ACTIONBAR", "CHAT", "BOTH", "OFF") : List.of("on", "off");
            case "personality" -> Arrays.stream(Personality.values()).map(x -> x.name().toLowerCase(Locale.ROOT)).toList();
            case "customize" -> a.length == 2 ? List.of("theme", "color", "particles", "aura", "halo", "fragments", "markings") : a[1].equals("theme") ? BondData.THEMES.stream().map(x -> x.toLowerCase(Locale.ROOT)).toList() : List.of("on", "off");
            case "animation" -> a.length == 2 ? List.of("intensity", "state", "info") : a[1].equals("state") ? Arrays.stream(AnimState.values()).map(Enum::name).toList() : List.of();
            case "admin" -> s.hasPermission("des.azrathiel.admin") ? (a.length == 2 ? ADMIN : a.length == 3 && a[1].equals("vfxtest") ? com.des.weapons.azrathiel.combat.ChoreoBridge.DEMOS : a.length == 3 && a[1].equals("trace") ? List.of("hit") : a.length == 3 ? Bukkit.getOnlinePlayers().stream().map(Player::getName).toList() : a.length == 4 && (a[1].equals("unlock") || a[1].equals("lock")) ? concat(namesOf(Eidolon.values()), List.of("all")) : List.of()) : List.of();
            default -> List.of();
        };
        for (String o : opts) if (o.toLowerCase(Locale.ROOT).startsWith(last)) out.add(o); return out;
    }
    private static List<String> namesOf(Eidolon[] es) { return Arrays.stream(es).map(Eidolon::id).toList(); }
    private static List<String> concat(List<String> a, List<String> b) { List<String> l = new ArrayList<>(a); l.addAll(b); return l; }
    private List<String> eidolonExprs(CommandSender s, String[] a) {
        List<String> l = new ArrayList<>(namesOf(Eidolon.values())); for (String n : Convergence.handcrafted().values()) l.add(n.toLowerCase(Locale.ROOT).replace(' ', '_'));
        if (s instanceof Player p) { BondData b = mod.actions.bond(p); if (b != null) for (BondData.Custom c : b.customs) l.add(c.name()); } return l;
    }
}
