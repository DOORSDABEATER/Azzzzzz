package com.des.weapons.azrathiel.core;

import java.util.HashMap;
import java.util.Map;

/** Remembers how well an ability worked on an enemy type so the AI stops spamming what does not work. */
public final class EffectivenessTracker {
    private record Entry(double ema, int samples) {}
    private final Map<String, Entry> map = new HashMap<>();
    private static String k(String ability, String type) { return ability + "|" + type; }

    /** dealt/maxHealth of the target: 0.05 (5% of its health) or more counts as fully effective. */
    public void record(String ability, String targetType, double dealt, double targetMaxHealth) {
        double eff = Math.min(1.0, (dealt / Math.max(1.0, targetMaxHealth)) / 0.05);
        map.merge(k(ability, targetType), new Entry(eff, 1), (o, n) -> new Entry(o.ema() * 0.6 + eff * 0.4, o.samples() + 1));
    }

    /** Multiplier 0.35..1.0 applied to an ability's score for that enemy type. Unknown = neutral. */
    public double factor(String ability, String targetType) {
        Entry e = map.get(k(ability, targetType));
        if (e == null || e.samples() < 2) return 1.0;
        return 0.35 + 0.65 * e.ema();
    }
    public void clear() { map.clear(); }
}
